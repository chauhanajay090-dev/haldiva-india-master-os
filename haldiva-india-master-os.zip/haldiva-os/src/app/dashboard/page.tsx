"use client";

import { useState, useEffect } from "react";
import { createBrowserClient } from "@/lib/supabase";
import { formatCurrency, formatNumber, formatDate, isExpiringWithin } from "@/lib/utils";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, BarChart, Bar, Legend
} from "recharts";
import {
  IndianRupee, ShoppingCart, AlertTriangle, Clock, Package,
  TrendingUp, Users, Megaphone, ExternalLink, ArrowUpRight,
  ArrowDownRight, Truck, Star
} from "lucide-react";

const CHART_COLORS = ["#1B5FD4", "#C9A84C", "#059669", "#DC2626", "#7C3AED", "#D97706"];

// Sample data (in production, fetched from Supabase)
const salesData = [
  { date: "Apr 28", online: 12400, offline: 4200, distributor: 8900, marketplace: 6100 },
  { date: "Apr 29", online: 15800, offline: 3800, distributor: 11200, marketplace: 7300 },
  { date: "Apr 30", online: 18200, offline: 5100, distributor: 9800, marketplace: 8400 },
  { date: "May 1", online: 22100, offline: 6300, distributor: 14500, marketplace: 9200 },
  { date: "May 2", online: 19600, offline: 4900, distributor: 12100, marketplace: 7800 },
  { date: "May 3", online: 24800, offline: 7200, distributor: 16800, marketplace: 10500 },
  { date: "May 4", online: 21300, offline: 5800, distributor: 13600, marketplace: 9100 },
];

const channelPieData = [
  { name: "D2C Shopify", value: 38, color: "#1B5FD4" },
  { name: "Amazon", value: 24, color: "#C9A84C" },
  { name: "Distributor", value: 20, color: "#059669" },
  { name: "Offline", value: 11, color: "#7C3AED" },
  { name: "Others", value: 7, color: "#D97706" },
];

const topProducts = [
  { name: "A2 Gir Cow Heritage Ghee", sales: 142, revenue: 56658, trend: +12 },
  { name: "Phool Ras Honey", sales: 208, revenue: 51792, trend: +8 },
  { name: "Shilajit Honey 150g", sales: 96, revenue: 36480, trend: +21 },
  { name: "Haldi Doodh Masala", sales: 185, revenue: 71225, trend: -3 },
  { name: "Royal Festive Gift Duo", sales: 34, revenue: 55386, trend: +45 },
];

const lowStockAlerts = [
  { sku: "HLD-O-001", name: "Black Mustard Oil — Wood Pressed", stock: 6, min: 30 },
  { sku: "HLD-H-003", name: "Amrit Honey — Turmeric 150ml", stock: 14, min: 40 },
  { sku: "HLD-HMP-002", name: "Complete Mini Wellness Box", stock: 16, min: 10 },
];

const expiringBatches = [
  { product: "Masala Tea — Authentic Chai", batch: "BATCH-2024-11", expDate: "2025-06-15", qty: 45 },
  { product: "Millet Coconut Cookies", batch: "BATCH-2024-12", expDate: "2025-07-01", qty: 82 },
];

const recentOrders = [
  { id: "HLD-20250504-1294", customer: "Rajesh Traders", amount: 29880, status: "dispatched", channel: "distributor" },
  { id: "HLD-20250504-1293", customer: "Online Customer", amount: 1629, status: "confirmed", channel: "shopify" },
  { id: "HLD-20250504-1292", customer: "Sharma & Co.", amount: 30400, status: "pending_payment", channel: "distributor" },
  { id: "HLD-20250504-1291", customer: "Amazon Order", amount: 2484, status: "packed", channel: "amazon" },
  { id: "HLD-20250504-1290", customer: "Walk-in Customer", amount: 780, status: "delivered", channel: "offline" },
];

const STATUS_CONFIG: Record<string, { label: string; color: string; bg: string }> = {
  new: { label: "New", color: "#1B5FD4", bg: "#EFF6FF" },
  confirmed: { label: "Confirmed", color: "#7C3AED", bg: "#F5F3FF" },
  packed: { label: "Packed", color: "#D97706", bg: "#FFFBEB" },
  dispatched: { label: "Dispatched", color: "#059669", bg: "#ECFDF5" },
  delivered: { label: "Delivered", color: "#15803D", bg: "#DCFCE7" },
  pending_payment: { label: "Pending Payment", color: "#DC2626", bg: "#FEF2F2" },
  cancelled: { label: "Cancelled", color: "#6B7280", bg: "#F9FAFB" },
};

export default function DashboardPage() {
  const [greeting, setGreeting] = useState("Good morning");
  const supabase = createBrowserClient();

  useEffect(() => {
    const h = new Date().getHours();
    if (h < 12) setGreeting("Good morning");
    else if (h < 17) setGreeting("Good afternoon");
    else setGreeting("Good evening");
  }, []);

  const metrics = [
    {
      label: "Today's Sales",
      value: formatCurrency(24800),
      sub: "+18.2% vs yesterday",
      trend: "up",
      icon: IndianRupee,
      color: "#059669",
      bg: "#ECFDF5",
    },
    {
      label: "Month Sales",
      value: formatCurrency(458600),
      sub: "₹6.2L target · 74% achieved",
      trend: "up",
      icon: TrendingUp,
      color: "#1B5FD4",
      bg: "#EFF6FF",
    },
    {
      label: "Pending Orders",
      value: "23",
      sub: "12 need dispatch today",
      trend: "neutral",
      icon: ShoppingCart,
      color: "#7C3AED",
      bg: "#F5F3FF",
    },
    {
      label: "Pending Payments",
      value: formatCurrency(86450),
      sub: "4 partners overdue",
      trend: "down",
      icon: Clock,
      color: "#DC2626",
      bg: "#FEF2F2",
    },
    {
      label: "Low Stock Items",
      value: "3",
      sub: "Urgent reorder needed",
      trend: "down",
      icon: AlertTriangle,
      color: "#D97706",
      bg: "#FFFBEB",
    },
    {
      label: "Expiring Soon",
      value: "2",
      sub: "Batches within 60 days",
      trend: "neutral",
      icon: Package,
      color: "#BE185D",
      bg: "#FDF2F8",
    },
    {
      label: "Team Present",
      value: "3/4",
      sub: "1 WFH today",
      trend: "up",
      icon: Users,
      color: "#059669",
      bg: "#ECFDF5",
    },
    {
      label: "Ad ROI",
      value: "3.4x",
      sub: "₹12.4K spend this month",
      trend: "up",
      icon: Megaphone,
      color: "#7C3AED",
      bg: "#F5F3FF",
    },
  ];

  return (
    <div className="p-6 space-y-6 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold text-navy-950">
            {greeting}, Vikram 👋
          </h1>
          <p className="text-slate-400 text-sm mt-1">
            {formatDate(new Date(), "EEEE, dd MMMM yyyy")} · Here's your company overview
          </p>
        </div>
        <div className="flex items-center gap-2">
          <a
            href="https://haldivaindia.com"
            target="_blank"
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-navy-950 text-white text-xs font-medium hover:bg-navy-900 transition-colors"
          >
            <ExternalLink className="w-3.5 h-3.5" />
            Website
          </a>
          <button className="btn-gold text-xs py-2">
            + New Order
          </button>
        </div>
      </div>

      {/* Metrics Grid */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {metrics.map((m, i) => (
          <div
            key={m.label}
            className={`stat-card animate-fade-in-up stagger-${Math.min(i + 1, 5)}`}
          >
            <div className="flex items-center justify-between mb-2">
              <p className="stat-label">{m.label}</p>
              <div className="w-8 h-8 rounded-lg flex items-center justify-center flex-shrink-0"
                style={{ background: m.bg }}>
                <m.icon className="w-4 h-4" style={{ color: m.color }} />
              </div>
            </div>
            <p className="stat-value">{m.value}</p>
            <div className="flex items-center gap-1 mt-1">
              {m.trend === "up" && <ArrowUpRight className="w-3 h-3 text-green-500" />}
              {m.trend === "down" && <ArrowDownRight className="w-3 h-3 text-red-500" />}
              <p className="stat-meta text-xs">{m.sub}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Charts row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Sales Area Chart */}
        <div className="premium-card p-5 lg:col-span-2">
          <div className="section-header">
            <div>
              <h3 className="section-title">Revenue by Channel</h3>
              <p className="section-sub">Last 7 days — all sales channels</p>
            </div>
            <select className="text-xs border border-slate-200 rounded-lg px-2 py-1.5 text-slate-600 focus:outline-none focus:ring-1 focus:ring-blue-500">
              <option>Last 7 days</option>
              <option>Last 30 days</option>
              <option>This month</option>
            </select>
          </div>
          <ResponsiveContainer width="100%" height={220}>
            <AreaChart data={salesData}>
              <defs>
                {["online", "offline", "distributor", "marketplace"].map((key, i) => (
                  <linearGradient key={key} id={`grad-${key}`} x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor={CHART_COLORS[i]} stopOpacity={0.15} />
                    <stop offset="95%" stopColor={CHART_COLORS[i]} stopOpacity={0} />
                  </linearGradient>
                ))}
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
              <XAxis dataKey="date" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
              <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false}
                tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
              <Tooltip
                contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0", fontSize: 12 }}
                formatter={(v: number) => [formatCurrency(v), ""]}
              />
              <Area type="monotone" dataKey="online" stroke="#1B5FD4" fill="url(#grad-online)" strokeWidth={2} name="Online" />
              <Area type="monotone" dataKey="distributor" stroke="#C9A84C" fill="url(#grad-distributor)" strokeWidth={2} name="Distributor" />
              <Area type="monotone" dataKey="marketplace" stroke="#059669" fill="url(#grad-marketplace)" strokeWidth={2} name="Marketplace" />
              <Area type="monotone" dataKey="offline" stroke="#7C3AED" fill="url(#grad-offline)" strokeWidth={2} name="Offline" />
              <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11 }} />
            </AreaChart>
          </ResponsiveContainer>
        </div>

        {/* Channel Pie */}
        <div className="premium-card p-5">
          <div className="section-header">
            <div>
              <h3 className="section-title">Channel Mix</h3>
              <p className="section-sub">Revenue split this month</p>
            </div>
          </div>
          <ResponsiveContainer width="100%" height={160}>
            <PieChart>
              <Pie data={channelPieData} cx="50%" cy="50%" innerRadius={50} outerRadius={75}
                paddingAngle={2} dataKey="value">
                {channelPieData.map((entry, i) => (
                  <Cell key={i} fill={entry.color} />
                ))}
              </Pie>
              <Tooltip formatter={(v: number) => [`${v}%`, ""]} />
            </PieChart>
          </ResponsiveContainer>
          <div className="space-y-2 mt-2">
            {channelPieData.map((c) => (
              <div key={c.name} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-2.5 h-2.5 rounded-full" style={{ background: c.color }} />
                  <span className="text-xs text-slate-600">{c.name}</span>
                </div>
                <span className="text-xs font-semibold text-navy-950">{c.value}%</span>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom row */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
        {/* Recent Orders */}
        <div className="premium-card p-5 lg:col-span-2">
          <div className="section-header">
            <div>
              <h3 className="section-title">Recent Orders</h3>
              <p className="section-sub">Latest activity across all channels</p>
            </div>
            <a href="/orders" className="text-xs text-blue-600 hover:text-blue-700 font-medium flex items-center gap-1">
              View all <ArrowUpRight className="w-3 h-3" />
            </a>
          </div>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Order ID</th>
                  <th>Customer / Partner</th>
                  <th>Channel</th>
                  <th>Amount</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {recentOrders.map((o) => {
                  const sc = STATUS_CONFIG[o.status];
                  return (
                    <tr key={o.id} className="cursor-pointer">
                      <td className="font-mono text-xs text-slate-500">{o.id.split("-").slice(-1)[0]}</td>
                      <td className="font-medium text-sm">{o.customer}</td>
                      <td>
                        <span className="text-xs capitalize px-2 py-0.5 rounded-full bg-slate-100 text-slate-600">
                          {o.channel}
                        </span>
                      </td>
                      <td className="font-semibold text-sm">{formatCurrency(o.amount)}</td>
                      <td>
                        <span className="text-xs font-semibold px-2 py-0.5 rounded-full"
                          style={{ color: sc?.color, background: sc?.bg }}>
                          {sc?.label}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Alerts + Top Products */}
        <div className="space-y-5">
          {/* Low Stock Alerts */}
          {lowStockAlerts.length > 0 && (
            <div className="premium-card p-5">
              <div className="flex items-center gap-2 mb-3">
                <div className="w-6 h-6 rounded-lg bg-amber-100 flex items-center justify-center">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-600" />
                </div>
                <h3 className="text-sm font-semibold text-navy-950">Low Stock Alerts</h3>
              </div>
              <div className="space-y-2">
                {lowStockAlerts.map((a) => (
                  <div key={a.sku} className="flex items-center justify-between p-2 rounded-lg bg-amber-50 border border-amber-100">
                    <div className="min-w-0 flex-1">
                      <p className="text-xs font-semibold text-slate-700 truncate">{a.name}</p>
                      <p className="text-[10px] text-slate-400">{a.sku} · Min: {a.min}</p>
                    </div>
                    <span className="ml-2 text-xs font-bold text-amber-700 bg-amber-100 px-2 py-0.5 rounded-full flex-shrink-0">
                      {a.stock} left
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Top Products */}
          <div className="premium-card p-5">
            <div className="flex items-center gap-2 mb-3">
              <div className="w-6 h-6 rounded-lg bg-blue-100 flex items-center justify-center">
                <Star className="w-3.5 h-3.5 text-blue-600" />
              </div>
              <h3 className="text-sm font-semibold text-navy-950">Top Products</h3>
            </div>
            <div className="space-y-2.5">
              {topProducts.slice(0, 4).map((p, i) => (
                <div key={p.name} className="flex items-center gap-2">
                  <span className="w-5 text-xs text-slate-400 font-mono">#{i + 1}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-xs font-semibold text-slate-700 truncate">{p.name}</p>
                    <p className="text-[10px] text-slate-400">{p.sales} units · {formatCurrency(p.revenue)}</p>
                  </div>
                  <span className={`text-[10px] font-semibold ${p.trend > 0 ? "text-green-600" : "text-red-500"}`}>
                    {p.trend > 0 ? "+" : ""}{p.trend}%
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Company info bar */}
      <div className="premium-card p-4 flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gold-500 to-gold-400 flex items-center justify-center">
            <span className="text-base font-display font-bold text-navy-950">H</span>
          </div>
          <div>
            <p className="text-sm font-display font-bold text-navy-950">HALDIVA INDIA</p>
            <p className="text-xs text-slate-400">FSSAI 22725441001672 · Gaur City Center, Greater Noida West 201306</p>
          </div>
        </div>
        <div className="flex items-center gap-4 text-xs text-slate-400">
          <a href="tel:01205163005" className="hover:text-blue-600 transition-colors">📞 0120 516 3005</a>
          <a href="mailto:care@haldivaindia.in" className="hover:text-blue-600 transition-colors">✉ care@haldivaindia.in</a>
          <a href="https://haldivaindia.com" target="_blank" className="hover:text-blue-600 transition-colors flex items-center gap-1">
            🌐 haldivaindia.com <ExternalLink className="w-3 h-3" />
          </a>
        </div>
      </div>
    </div>
  );
}
