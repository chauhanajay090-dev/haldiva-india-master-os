"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { createBrowserClient } from "@/lib/supabase";
import { getAccessibleModules, ALL_NAV_ITEMS, ROLE_LABELS } from "@/lib/rbac";
import { cn, getInitials } from "@/lib/utils";
import type { User, UserRole } from "@/types";
import {
  LayoutDashboard, Package, ShoppingCart, IndianRupee, Users, Megaphone,
  Store, Handshake, FolderOpen, FileBarChart, Settings, UserCog, Menu,
  X, Bell, Search, ChevronDown, LogOut, ChevronRight, Box, BarChart3,
  Layers, ArrowLeftRight, Upload, List, Plus, Truck, RotateCcw, PieChart,
  TrendingUp, TrendingDown, CreditCard, Clock, CheckSquare, UserCheck,
  Award, BarChart2, Share2, Target, ShoppingBag
} from "lucide-react";
import { toast } from "sonner";

const ICON_MAP: Record<string, React.ComponentType<{ className?: string }>> = {
  LayoutDashboard, Package, ShoppingCart, IndianRupee, Users, Megaphone,
  Store, Handshake, FolderOpen, FileBarChart, Settings, UserCog, Box,
  BarChart3, Layers, ArrowLeftRight, Upload, List, Plus, Truck, RotateCcw,
  PieChart, TrendingUp, TrendingDown, CreditCard, Clock, CheckSquare,
  UserCheck, Award, BarChart2, Share2, Target, ShoppingBag, Search,
};

export default function DashboardLayout({ children }: { children: React.ReactNode }) {
  const router = useRouter();
  const pathname = usePathname();
  const supabase = createBrowserClient();

  const [user, setUser] = useState<User | null>(null);
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [expandedItems, setExpandedItems] = useState<Set<string>>(new Set());
  const [notifications, setNotifications] = useState(3);

  useEffect(() => {
    async function loadUser() {
      const { data: { user: authUser } } = await supabase.auth.getUser();
      if (!authUser) { router.push("/auth/login"); return; }
      const { data } = await supabase.from("users").select("*").eq("id", authUser.id).single();
      if (data) setUser(data as User);
      else router.push("/auth/login");
    }
    loadUser();
  }, []);

  async function handleLogout() {
    await supabase.auth.signOut();
    toast.success("Signed out successfully");
    router.push("/auth/login");
  }

  const accessibleModules = user ? getAccessibleModules(user.role as UserRole) : [];
  const visibleNavItems = ALL_NAV_ITEMS.filter((item) =>
    accessibleModules.includes(item.module)
  );

  function toggleExpanded(href: string) {
    setExpandedItems((prev) => {
      const next = new Set(prev);
      if (next.has(href)) next.delete(href);
      else next.add(href);
      return next;
    });
  }

  function isActive(href: string) {
    return pathname === href || pathname.startsWith(href + "/");
  }

  if (!user) {
    return (
      <div className="min-h-screen bg-navy-gradient flex items-center justify-center">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-xl bg-gradient-to-br from-gold-500 to-gold-400 flex items-center justify-center animate-pulse">
            <span className="text-xl font-display font-bold text-navy-950">H</span>
          </div>
          <p className="text-slate-400 text-sm font-medium">Loading HALDIVA OS...</p>
        </div>
      </div>
    );
  }

  const roleInfo = ROLE_LABELS[user.role as UserRole];
  const isCEO = user.role === "ceo";

  return (
    <div className="h-screen flex bg-slate-50 overflow-hidden">
      {/* Mobile overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/60 z-40 lg:hidden backdrop-blur-sm"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* ── SIDEBAR ─────────────────────────────────────────────── */}
      <aside
        className={cn(
          "fixed top-0 bottom-0 left-0 z-50 w-64 flex flex-col bg-navy-gradient transition-transform duration-300",
          "lg:static lg:translate-x-0",
          sidebarOpen ? "translate-x-0" : "-translate-x-full"
        )}
      >
        {/* Brand */}
        <div className="px-5 py-5 border-b border-white/8 flex items-center justify-between flex-shrink-0">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-gold-500 to-gold-400 flex items-center justify-center flex-shrink-0"
              style={{ boxShadow: "0 2px 8px rgba(201,168,76,0.3)" }}>
              <span className="text-base font-display font-bold text-navy-950">H</span>
            </div>
            <div>
              <p className="text-gold-500 font-display font-bold text-base tracking-wider leading-none">HALDIVA</p>
              <p className="text-slate-500 text-[10px] tracking-[3px] uppercase leading-none mt-0.5">INDIA</p>
            </div>
          </div>
          <button onClick={() => setSidebarOpen(false)} className="lg:hidden text-slate-500 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* User pill */}
        <div className="mx-3 my-3 p-3 rounded-xl glass flex items-center gap-3 flex-shrink-0">
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gold-500 to-gold-400 flex items-center justify-center text-navy-950 font-bold text-xs flex-shrink-0">
            {getInitials(user.name)}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-white text-xs font-semibold truncate">{user.name}</p>
            <p className="text-slate-400 text-[10px] truncate">{roleInfo}</p>
          </div>
          {isCEO && (
            <div className="px-1.5 py-0.5 rounded-full text-[9px] font-bold tracking-wider"
              style={{ background: "rgba(201,168,76,0.2)", color: "#C9A84C" }}>CEO</div>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto no-scrollbar py-2 px-2">
          {visibleNavItems.map((item) => {
            const Icon = ICON_MAP[item.icon];
            const active = isActive(item.href);
            const hasChildren = item.children && item.children.length > 0;
            const isExpanded = expandedItems.has(item.href);

            return (
              <div key={item.href}>
                <div
                  onClick={() => {
                    if (hasChildren) {
                      toggleExpanded(item.href);
                    } else {
                      router.push(item.href);
                      setSidebarOpen(false);
                    }
                  }}
                  className={cn(
                    "sidebar-item group",
                    active && !hasChildren && "active"
                  )}
                >
                  {Icon && <Icon className="icon" />}
                  <span className="flex-1 text-sm">{item.label}</span>
                  {hasChildren && (
                    <ChevronRight
                      className={cn(
                        "w-4 h-4 text-slate-500 transition-transform duration-200",
                        isExpanded && "rotate-90"
                      )}
                    />
                  )}
                </div>

                {/* Sub-items */}
                {hasChildren && isExpanded && (
                  <div className="ml-4 pl-3 border-l border-white/10 mt-1 space-y-0.5">
                    {item.children!
                      .filter((child) => accessibleModules.includes(child.module))
                      .map((child) => {
                        const ChildIcon = ICON_MAP[child.icon];
                        const childActive = isActive(child.href);
                        return (
                          <Link
                            key={child.href}
                            href={child.href}
                            onClick={() => setSidebarOpen(false)}
                            className={cn(
                              "flex items-center gap-2.5 px-2.5 py-2 rounded-lg text-xs font-medium transition-all duration-150",
                              childActive
                                ? "text-white bg-white/10"
                                : "text-slate-500 hover:text-slate-300 hover:bg-white/5"
                            )}
                          >
                            {ChildIcon && <ChildIcon className="w-3.5 h-3.5" />}
                            {child.label}
                          </Link>
                        );
                      })}
                  </div>
                )}
              </div>
            );
          })}
        </nav>

        {/* Sidebar footer */}
        <div className="flex-shrink-0 p-3 border-t border-white/8">
          <button
            onClick={handleLogout}
            className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg text-slate-500 hover:text-red-400 hover:bg-red-500/10 transition-all duration-150 text-sm"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
          <p className="text-[10px] text-slate-700 text-center mt-2 leading-relaxed">
            FSSAI 22725441001672<br />
            HALDIVA INDIA OS v3.0
          </p>
        </div>
      </aside>

      {/* ── MAIN CONTENT ─────────────────────────────────────────── */}
      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        {/* Top bar */}
        <header className="h-15 bg-white border-b border-slate-100 flex items-center px-4 lg:px-6 gap-4 flex-shrink-0"
          style={{ boxShadow: "0 1px 3px rgba(0,0,0,0.05)" }}>
          <button
            onClick={() => setSidebarOpen(true)}
            className="lg:hidden p-2 rounded-lg text-slate-500 hover:bg-slate-100 transition-colors"
          >
            <Menu className="w-5 h-5" />
          </button>

          {/* Search */}
          <div className="hidden md:flex items-center gap-2 flex-1 max-w-md">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input
                type="text"
                placeholder="Search products, orders, customers..."
                className="w-full pl-9 pr-4 py-2 rounded-lg bg-slate-50 border border-slate-200 text-sm text-slate-700 placeholder:text-slate-400 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
              />
            </div>
          </div>

          <div className="flex-1 md:hidden" />

          {/* Right actions */}
          <div className="flex items-center gap-2">
            {/* Notifications */}
            <button className="relative p-2 rounded-lg text-slate-500 hover:bg-slate-100 transition-colors">
              <Bell className="w-5 h-5" />
              {notifications > 0 && (
                <span className="absolute top-1.5 right-1.5 w-2 h-2 bg-red-500 rounded-full animate-pulse" />
              )}
            </button>

            {/* User menu */}
            <div className="flex items-center gap-2 pl-2 border-l border-slate-100">
              <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-gold-500 to-gold-400 flex items-center justify-center text-navy-950 font-bold text-xs">
                {getInitials(user.name)}
              </div>
              <div className="hidden md:block">
                <p className="text-xs font-semibold text-navy-950 leading-none">{user.name}</p>
                <p className="text-[10px] text-slate-400 leading-none mt-0.5">{roleInfo}</p>
              </div>
            </div>
          </div>
        </header>

        {/* Page content */}
        <main className="flex-1 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
}
