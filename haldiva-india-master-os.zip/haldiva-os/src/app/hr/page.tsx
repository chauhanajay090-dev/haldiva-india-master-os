"use client";

import { useState } from "react";
import {
  Clock, CheckSquare, Users, Award, Plus, Calendar,
  Check, X, Edit2, MessageSquare, TrendingUp, AlertCircle
} from "lucide-react";
import { formatDate, formatCurrency } from "@/lib/utils";

const TEAM = [
  { id: "1", name: "Mrs. Kriti Gupta", role: "Senior Executive", dept: "Office Operations", ini: "KG", color: "#1B5FD4" },
  { id: "2", name: "Mr. Deepender Jaiswal", role: "Data Executive", dept: "Data & Support", ini: "DJ", color: "#7C3AED" },
  { id: "3", name: "Mr. Sayan", role: "Digital Marketing Lead", dept: "Digital Marketing", ini: "SY", color: "#059669" },
];

const today = new Date().toISOString().split("T")[0];

type AttStatus = "present" | "absent" | "late" | "wfh" | "leave" | "half_day";

const ATTENDANCE: Record<string, { status: AttStatus; checkIn?: string; checkOut?: string }> = {
  "1": { status: "present", checkIn: "09:12 AM", checkOut: "" },
  "2": { status: "wfh", checkIn: "09:45 AM", checkOut: "" },
  "3": { status: "present", checkIn: "10:02 AM", checkOut: "" },
};

const STATUS_CFG: Record<AttStatus, { label: string; color: string; bg: string }> = {
  present: { label: "Present", color: "#059669", bg: "#DCFCE7" },
  absent: { label: "Absent", color: "#DC2626", bg: "#FEE2E2" },
  late: { label: "Late", color: "#D97706", bg: "#FEF3C7" },
  wfh: { label: "WFH", color: "#1B5FD4", bg: "#EFF6FF" },
  leave: { label: "On Leave", color: "#6B7280", bg: "#F3F4F6" },
  half_day: { label: "Half Day", color: "#7C3AED", bg: "#F5F3FF" },
};

const TASKS = [
  { id: "t1", title: "Update product listings on Shopify", assignedTo: "1", assignedBy: "CEO", priority: "high", status: "in_progress", progress: 65, deadline: "2025-05-06", description: "Add new combo products and update descriptions" },
  { id: "t2", title: "Prepare monthly inventory report", assignedTo: "2", assignedBy: "CEO", priority: "high", status: "todo", progress: 0, deadline: "2025-05-05", description: "Full stock audit and movement report" },
  { id: "t3", title: "Run Instagram content campaign — Honey range", assignedTo: "3", assignedBy: "CEO", priority: "medium", status: "in_progress", progress: 40, deadline: "2025-05-08", description: "5 posts + 3 reels for honey product range" },
  { id: "t4", title: "Update Amazon listings for new SKUs", assignedTo: "3", assignedBy: "CEO", priority: "urgent", status: "todo", progress: 0, deadline: "2025-05-05", description: "Add HLD-H-005 and HLD-G-002 to Amazon catalog" },
  { id: "t5", title: "Coordinate dispatch for ORD-2502", assignedTo: "1", assignedBy: "CEO", priority: "urgent", status: "done", progress: 100, deadline: "2025-05-04", description: "Dispatch ghee order to Rajesh Traders" },
];

const PRIORITY_CFG: Record<string, { label: string; color: string; bg: string }> = {
  low: { label: "Low", color: "#6B7280", bg: "#F3F4F6" },
  medium: { label: "Medium", color: "#1B5FD4", bg: "#EFF6FF" },
  high: { label: "High", color: "#D97706", bg: "#FEF3C7" },
  urgent: { label: "Urgent", color: "#DC2626", bg: "#FEE2E2" },
};

const TASK_STATUS_CFG: Record<string, { label: string; color: string; bg: string }> = {
  todo: { label: "To Do", color: "#6B7280", bg: "#F3F4F6" },
  in_progress: { label: "In Progress", color: "#1B5FD4", bg: "#EFF6FF" },
  review: { label: "In Review", color: "#7C3AED", bg: "#F5F3FF" },
  done: { label: "Done", color: "#059669", bg: "#DCFCE7" },
  cancelled: { label: "Cancelled", color: "#DC2626", bg: "#FEE2E2" },
};

export default function HRPage() {
  const [activeTab, setActiveTab] = useState<"attendance" | "tasks" | "team" | "performance">("attendance");
  const [selectedDate, setSelectedDate] = useState(today);

  const present = Object.values(ATTENDANCE).filter(a => a.status === "present" || a.status === "wfh").length;
  const absent = Object.values(ATTENDANCE).filter(a => a.status === "absent").length;
  const pendingTasks = TASKS.filter(t => t.status !== "done" && t.status !== "cancelled").length;
  const overdueTasks = TASKS.filter(t => t.deadline && new Date(t.deadline) < new Date() && t.status !== "done").length;

  return (
    <div className="p-6 space-y-5 max-w-[1400px] mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold text-navy-950">HR & Team Management</h1>
          <p className="text-slate-400 text-sm mt-1">
            {formatDate(new Date(), "EEEE, dd MMMM yyyy")} · {present}/{TEAM.length} present today
          </p>
        </div>
        <button className="btn-gold text-xs py-2">
          <Plus className="w-3.5 h-3.5" /> Assign Task
        </button>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Present Today", value: `${present}/${TEAM.length}`, sub: "Including WFH", color: "#059669", bg: "#DCFCE7", icon: Users },
          { label: "Absent", value: absent, sub: absent > 0 ? "Follow up required" : "Full team active", color: absent > 0 ? "#DC2626" : "#059669", bg: absent > 0 ? "#FEE2E2" : "#DCFCE7", icon: X },
          { label: "Pending Tasks", value: pendingTasks, sub: `${overdueTasks} overdue`, color: "#D97706", bg: "#FEF3C7", icon: CheckSquare },
          { label: "Team Performance", value: "87%", sub: "This week avg", color: "#1B5FD4", bg: "#EFF6FF", icon: Award },
        ].map((m) => (
          <div key={m.label} className="stat-card">
            <div className="flex items-center justify-between mb-2">
              <p className="stat-label">{m.label}</p>
              <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0" style={{ background: m.bg }}>
                <m.icon className="w-3.5 h-3.5" style={{ color: m.color }} />
              </div>
            </div>
            <p className="stat-value" style={{ color: m.color }}>{m.value}</p>
            <p className="stat-meta">{m.sub}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-slate-100 rounded-xl w-fit">
        {[
          { key: "attendance", label: "Attendance", icon: Clock },
          { key: "tasks", label: "Tasks", icon: CheckSquare },
          { key: "team", label: "Team", icon: Users },
          { key: "performance", label: "Performance", icon: Award },
        ].map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => setActiveTab(key as typeof activeTab)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === key ? "bg-white text-navy-950 shadow-sm" : "text-slate-500 hover:text-slate-700"
            }`}>
            <Icon className="w-4 h-4" /> {label}
          </button>
        ))}
      </div>

      {/* ATTENDANCE */}
      {activeTab === "attendance" && (
        <div className="space-y-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-slate-400" />
              <input type="date" value={selectedDate} onChange={e => setSelectedDate(e.target.value)}
                className="form-input py-2 text-sm w-auto" />
            </div>
            <button className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 text-xs font-medium text-slate-600 hover:bg-slate-50">
              <Plus className="w-3.5 h-3.5" /> Mark Attendance
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {TEAM.map((member) => {
              const att = ATTENDANCE[member.id];
              const sc = att ? STATUS_CFG[att.status] : STATUS_CFG.absent;
              return (
                <div key={member.id} className="premium-card p-5">
                  <div className="flex items-center gap-3 mb-4">
                    <div className="w-10 h-10 rounded-xl flex items-center justify-center text-white font-bold text-sm flex-shrink-0"
                      style={{ background: member.color }}>
                      {member.ini}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-semibold text-sm text-navy-950">{member.name}</p>
                      <p className="text-xs text-slate-400">{member.role}</p>
                    </div>
                    <span className="text-xs font-semibold px-2 py-0.5 rounded-full"
                      style={{ color: sc.color, background: sc.bg }}>
                      {sc.label}
                    </span>
                  </div>

                  {att && (
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-2.5 bg-green-50 rounded-lg">
                        <p className="text-[10px] text-green-600 font-semibold uppercase tracking-wider mb-1">Check-In</p>
                        <p className="text-sm font-bold text-green-700">{att.checkIn || "—"}</p>
                      </div>
                      <div className="p-2.5 bg-slate-50 rounded-lg">
                        <p className="text-[10px] text-slate-500 font-semibold uppercase tracking-wider mb-1">Check-Out</p>
                        <p className="text-sm font-bold text-slate-600">{att.checkOut || "Active"}</p>
                      </div>
                    </div>
                  )}

                  <div className="flex gap-2 mt-3">
                    {(["present", "wfh", "leave", "absent"] as AttStatus[]).map(s => (
                      <button key={s} className="flex-1 py-1.5 rounded-lg text-[10px] font-semibold transition-all"
                        style={att?.status === s
                          ? { background: STATUS_CFG[s].bg, color: STATUS_CFG[s].color, border: `1px solid ${STATUS_CFG[s].color}20` }
                          : { background: "#F8FAFC", color: "#94A3B8" }}>
                        {STATUS_CFG[s].label}
                      </button>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* TASKS */}
      {activeTab === "tasks" && (
        <div className="space-y-4">
          {overdueTasks > 0 && (
            <div className="alert-danger">
              <AlertCircle className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-sm">Overdue Tasks</p>
                <p className="text-sm">{overdueTasks} task{overdueTasks !== 1 ? "s" : ""} past deadline — immediate action required</p>
              </div>
            </div>
          )}

          <div className="premium-card">
            <div className="p-4 border-b border-slate-100">
              <div className="flex items-center gap-3">
                <span className="text-sm font-semibold text-slate-700">All Tasks</span>
                <div className="flex gap-2 ml-auto">
                  {Object.entries(TASK_STATUS_CFG).map(([k, v]) => (
                    <span key={k} className="text-xs px-2 py-0.5 rounded-full font-medium"
                      style={{ color: v.color, background: v.bg }}>
                      {TASKS.filter(t => t.status === k).length} {v.label}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            <div className="divide-y divide-slate-50">
              {TASKS.map((task) => {
                const assignee = TEAM.find(t => t.id === task.assignedTo);
                const pc = PRIORITY_CFG[task.priority];
                const tc = TASK_STATUS_CFG[task.status];
                const isOverdue = task.deadline && new Date(task.deadline) < new Date() && task.status !== "done";

                return (
                  <div key={task.id} className={`p-4 hover:bg-slate-50/80 transition-colors ${isOverdue ? "bg-red-50/30" : ""}`}>
                    <div className="flex items-start gap-3">
                      <div className={`w-5 h-5 rounded-full border-2 flex-shrink-0 mt-0.5 flex items-center justify-center ${
                        task.status === "done" ? "bg-green-500 border-green-500" : "border-slate-300"
                      }`}>
                        {task.status === "done" && <Check className="w-3 h-3 text-white" />}
                      </div>

                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className={`text-sm font-semibold ${task.status === "done" ? "line-through text-slate-400" : "text-navy-950"}`}>
                            {task.title}
                          </p>
                          <span className="text-xs px-1.5 py-0.5 rounded-full font-semibold"
                            style={{ color: pc.color, background: pc.bg }}>{pc.label}</span>
                          <span className="text-xs px-1.5 py-0.5 rounded-full font-semibold"
                            style={{ color: tc.color, background: tc.bg }}>{tc.label}</span>
                          {isOverdue && (
                            <span className="text-xs px-1.5 py-0.5 rounded-full bg-red-100 text-red-700 font-semibold">⚠ Overdue</span>
                          )}
                        </div>
                        <p className="text-xs text-slate-400 mt-1">{task.description}</p>

                        {task.status !== "done" && (
                          <div className="mt-2">
                            <div className="flex items-center justify-between mb-1">
                              <span className="text-xs text-slate-400">Progress</span>
                              <span className="text-xs font-semibold text-slate-600">{task.progress}%</span>
                            </div>
                            <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                              <div className="h-full rounded-full transition-all duration-500"
                                style={{
                                  width: `${task.progress}%`,
                                  background: task.progress >= 75 ? "#059669" : task.progress >= 40 ? "#1B5FD4" : "#D97706"
                                }} />
                            </div>
                          </div>
                        )}
                      </div>

                      <div className="flex flex-col items-end gap-2 flex-shrink-0">
                        {assignee && (
                          <div className="flex items-center gap-1.5">
                            <div className="w-5 h-5 rounded-full text-white text-[9px] font-bold flex items-center justify-center"
                              style={{ background: assignee.color }}>
                              {assignee.ini}
                            </div>
                            <span className="text-xs text-slate-400">{assignee.name.split(" ")[1]}</span>
                          </div>
                        )}
                        {task.deadline && (
                          <span className={`text-xs ${isOverdue ? "text-red-600 font-semibold" : "text-slate-400"}`}>
                            Due: {formatDate(task.deadline, "dd MMM")}
                          </span>
                        )}
                        <div className="flex gap-1">
                          <button className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors">
                            <Edit2 className="w-3 h-3" />
                          </button>
                          <button className="p-1 rounded hover:bg-slate-100 text-slate-400 hover:text-slate-600 transition-colors">
                            <MessageSquare className="w-3 h-3" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* TEAM */}
      {activeTab === "team" && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {TEAM.map((member) => {
            const att = ATTENDANCE[member.id];
            const memberTasks = TASKS.filter(t => t.assignedTo === member.id);
            const doneTasks = memberTasks.filter(t => t.status === "done").length;
            const score = memberTasks.length > 0 ? Math.round((doneTasks / memberTasks.length) * 100) : 0;

            return (
              <div key={member.id} className="premium-card p-5">
                <div className="flex items-center gap-3 mb-4">
                  <div className="w-12 h-12 rounded-xl flex items-center justify-center text-white font-bold text-lg"
                    style={{ background: member.color }}>
                    {member.ini}
                  </div>
                  <div>
                    <p className="font-bold text-navy-950">{member.name}</p>
                    <p className="text-xs text-slate-400">{member.role}</p>
                    <p className="text-xs text-slate-300">{member.dept}</p>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3 mb-4">
                  <div className="p-2.5 bg-slate-50 rounded-lg text-center">
                    <p className="text-[10px] text-slate-400 uppercase tracking-wider">Tasks</p>
                    <p className="text-lg font-bold text-navy-950">{memberTasks.length}</p>
                  </div>
                  <div className="p-2.5 bg-green-50 rounded-lg text-center">
                    <p className="text-[10px] text-green-600 uppercase tracking-wider">Done</p>
                    <p className="text-lg font-bold text-green-700">{doneTasks}</p>
                  </div>
                </div>

                <div>
                  <div className="flex justify-between mb-1">
                    <span className="text-xs text-slate-400">Performance Score</span>
                    <span className="text-xs font-bold text-slate-700">{score}%</span>
                  </div>
                  <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700"
                      style={{ width: `${score}%`, background: member.color }} />
                  </div>
                </div>

                {att && (
                  <div className="mt-3 flex items-center gap-2">
                    <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full"
                      style={{ color: STATUS_CFG[att.status].color, background: STATUS_CFG[att.status].bg }}>
                      {STATUS_CFG[att.status].label}
                    </span>
                    {att.checkIn && <span className="text-xs text-slate-400">In: {att.checkIn}</span>}
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
