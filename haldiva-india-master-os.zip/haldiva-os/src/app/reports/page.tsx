"use client";

import { useState } from "react";
import {
  FileBarChart, Download, Printer, Package, Users, IndianRupee,
  AlertTriangle, Clock, Truck, TrendingUp, Calendar, Filter
} from "lucide-react";
import { formatCurrency, formatDate, downloadCSV } from "@/lib/utils";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, PieChart, Pie, Cell
} from "recharts";

const REPORT_TYPES = [
  { id: "daily_sales", label: "Daily Sales Report", icon: TrendingUp, color: "#059669", bg: "#DCFCE7", desc: "Sales by channel, product, and team" },
  { id: "inventory", label: "Inventory Report", icon: Package, color: "#1B5FD4", bg: "#EFF6FF", desc: "Full stock status across all types" },
  { id: "low_stock", label: "Low Stock Report", icon: AlertTriangle, color: "#D97706", bg: "#FEF3C7", desc: "Products below reorder level" },
  { id: "expiry", label: "Expiry Report", icon: Clock, color: "#DC2626", bg: "#FEE2E2", desc: "Batches expiring within 90 days" },
  { id: "expense", label: "Expense Report", icon: IndianRupee, color: "#7C3AED", bg: "#F5F3FF", desc: "All expenses by category and vendor" },
  { id: "payment_due", label: "Payment Due Report", icon: CreditCard, color: "#BE185D", bg: "#FDF2F8", desc: "Outstanding payments from partners" },
  { id: "team_performance", label: "Team Performance", icon: Users, color: "#0891B2", bg: "#CFFAFE", desc: "Attendance, tasks, productivity scores" },
  { id: "marketing", label: "Marketing Report", icon: TrendingUp, color: "#D97706", bg: "#FEF3C7", desc: "Campaigns, SEO rankings, social reach" },
  { id: "distributor", label: "Distributor Report", icon: Truck, color: "#059669", bg: "#DCFCE7", desc: "Partner orders, payments, stock" },
];

// Sample data for reports
const DAILY_SALES = [
  { channel: "Shopify", orders: 8, revenue: 14200, units: 24 },
  { channel: "Amazon", orders: 5, revenue: 9800, units: 16 },
  { channel: "Walk-in", orders: 3, revenue: 2400, units: 8 },
  { channel: "WhatsApp Direct", orders: 4, revenue: 5600, units: 12 },
  { channel: "Distributor", orders: 2, revenue: 28600, units: 80 },
];

const INVENTORY_SUMMARY = [
  { category: "Honey", skus: 5, totalStock: 680, value: 174200, lowStock: 1 },
  { category: "Ghee", skus: 2, totalStock: 286, value: 198460, lowStock: 0 },
  { category: "Spices", skus: 3, totalStock: 505, value: 188425, lowStock: 0 },
  { category: "Oils", skus: 1, totalStock: 12, value: 1380, lowStock: 1 },
  { category: "Cookies", skus: 1, totalStock: 210, value: 37800, lowStock: 0 },
  { category: "Combos", skus: 2, totalStock: 92, value: 127428, lowStock: 0 },
  { category: "Hampers", skus: 3, totalStock: 100, value: 136100, lowStock: 0 },
];

const EXPIRING_BATCHES = [
  { product: "Masala Tea — Authentic Chai 80g", batch: "BATCH-2024-11", expDate: "2025-06-15", qty: 45, daysLeft: 42 },
  { product: "Millet Coconut Cookies", batch: "BATCH-2024-12", expDate: "2025-07-01", qty: 82, daysLeft: 58 },
  { product: "Phool Ras Honey 100% Pure Raw", batch: "BATCH-2025-01", expDate: "2026-02-28", qty: 120, daysLeft: 300 },
];

const TEAM_PERFORMANCE = [
  { name: "Mrs. Kriti Gupta", role: "Senior Executive", attendance: 95, tasksCompleted: 18, tasksPending: 2, score: 92 },
  { name: "Mr. Deepender Jaiswal", role: "Data Executive", attendance: 88, tasksCompleted: 22, tasksPending: 3, score: 85 },
  { name: "Mr. Sayan", role: "Digital Marketing", attendance: 92, tasksCompleted: 15, tasksPending: 4, score: 78 },
];

const CHANNEL_PIE = [
  { name: "Shopify", value: 142000, color: "#1B5FD4" },
  { name: "Amazon", value: 86000, color: "#DC2626" },
  { name: "Distributor", value: 98000, color: "#C9A84C" },
  { name: "Offline", value: 56000, color: "#059669" },
  { name: "Corporate", value: 34600, color: "#7C3AED" },
];

// Fix missing icon import
function CreditCard({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <rect x="1" y="4" width="22" height="16" rx="2" ry="2" />
      <line x1="1" y1="10" x2="23" y2="10" />
    </svg>
  );
}

export default function ReportsPage() {
  const [activeReport, setActiveReport] = useState<string>("daily_sales");
  const [dateFrom, setDateFrom] = useState("2025-05-01");
  const [dateTo, setDateTo] = useState("2025-05-04");

  function handleExportCSV() {
    if (activeReport === "daily_sales") downloadCSV(DAILY_SALES, "daily-sales");
    else if (activeReport === "inventory") downloadCSV(INVENTORY_SUMMARY, "inventory");
    else if (activeReport === "team_performance") downloadCSV(TEAM_PERFORMANCE, "team-performance");
  }

  return (
    <div className="p-6 space-y-5 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold text-navy-950">Reports & Analytics</h1>
          <p className="text-slate-400 text-sm mt-1">Generate, view, and export comprehensive business reports</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 text-xs font-medium text-slate-600 hover:bg-slate-50">
            <Download className="w-3.5 h-3.5" /> Export CSV
          </button>
          <button className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-navy-950 text-white text-xs font-medium hover:bg-navy-900">
            <Printer className="w-3.5 h-3.5" /> Print
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-5">
        {/* Report Selector */}
        <div className="lg:col-span-1 space-y-2">
          <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider px-1 mb-3">Report Type</p>
          {REPORT_TYPES.map((rt) => (
            <button
              key={rt.id}
              onClick={() => setActiveReport(rt.id)}
              className={`w-full flex items-center gap-3 px-3 py-3 rounded-xl text-left transition-all duration-150 ${
                activeReport === rt.id
                  ? "shadow-sm"
                  : "hover:bg-slate-50 border border-transparent"
              }`}
              style={activeReport === rt.id ? { background: rt.bg, border: `1px solid ${rt.color}25` } : {}}
            >
              <div className="w-7 h-7 rounded-lg flex items-center justify-center flex-shrink-0"
                style={{ background: activeReport === rt.id ? rt.color : "#F1F5F9" }}>
                <rt.icon className="w-3.5 h-3.5" style={{ color: activeReport === rt.id ? "#fff" : "#94a3b8" }} />
              </div>
              <div className="min-w-0">
                <p className={`text-xs font-semibold leading-tight ${activeReport === rt.id ? "text-navy-950" : "text-slate-600"}`}>
                  {rt.label}
                </p>
              </div>
            </button>
          ))}
        </div>

        {/* Report Content */}
        <div className="lg:col-span-3 space-y-5">
          {/* Date Range */}
          <div className="premium-card p-4 flex flex-wrap gap-3 items-center">
            <Calendar className="w-4 h-4 text-slate-400" />
            <input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="form-input w-auto py-2 text-sm" />
            <span className="text-slate-400 text-sm">to</span>
            <input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="form-input w-auto py-2 text-sm" />
            <button className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-navy-950 text-white text-xs font-medium ml-auto">
              <Filter className="w-3 h-3" /> Apply Filter
            </button>
          </div>

          {/* DAILY SALES REPORT */}
          {activeReport === "daily_sales" && (
            <div className="space-y-5">
              <div className="grid grid-cols-3 gap-4">
                {[
                  { label: "Total Revenue", value: formatCurrency(DAILY_SALES.reduce((s, d) => s + d.revenue, 0)), color: "#059669" },
                  { label: "Total Orders", value: DAILY_SALES.reduce((s, d) => s + d.orders, 0), color: "#1B5FD4" },
                  { label: "Units Sold", value: DAILY_SALES.reduce((s, d) => s + d.units, 0), color: "#7C3AED" },
                ].map((m) => (
                  <div key={m.label} className="stat-card">
                    <p className="stat-label">{m.label}</p>
                    <p className="stat-value text-xl" style={{ color: m.color }}>{m.value}</p>
                  </div>
                ))}
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
                <div className="premium-card p-5">
                  <h3 className="section-title mb-4">Sales by Channel</h3>
                  <ResponsiveContainer width="100%" height={200}>
                    <BarChart data={DAILY_SALES}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                      <XAxis dataKey="channel" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                      <YAxis tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false}
                        tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                      <Tooltip formatter={(v: number) => [formatCurrency(v), "Revenue"]} contentStyle={{ borderRadius: 8, fontSize: 11 }} />
                      <Bar dataKey="revenue" fill="#1B5FD4" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>

                <div className="premium-card p-5">
                  <h3 className="section-title mb-3">Channel Breakdown</h3>
                  <div className="flex items-center justify-between mb-2">
                    <span className="text-xs text-slate-400">Channel Mix (This Month)</span>
                  </div>
                  <ResponsiveContainer width="100%" height={160}>
                    <PieChart>
                      <Pie data={CHANNEL_PIE} cx="50%" cy="50%" innerRadius={40} outerRadius={70} paddingAngle={2} dataKey="value">
                        {CHANNEL_PIE.map((e, i) => <Cell key={i} fill={e.color} />)}
                      </Pie>
                      <Tooltip formatter={(v: number) => [formatCurrency(v), ""]} contentStyle={{ borderRadius: 8, fontSize: 11 }} />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className="grid grid-cols-2 gap-1.5 mt-2">
                    {CHANNEL_PIE.map((c) => (
                      <div key={c.name} className="flex items-center gap-1.5 text-xs text-slate-500">
                        <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: c.color }} />
                        <span>{c.name}: {formatCurrency(c.value)}</span>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              <div className="premium-card overflow-hidden">
                <div className="p-4 border-b border-slate-100">
                  <h3 className="text-sm font-semibold">Detailed Sales Table</h3>
                </div>
                <div className="overflow-x-auto">
                  <table className="data-table">
                    <thead>
                      <tr><th>Channel</th><th>Orders</th><th>Units Sold</th><th>Revenue</th><th>Avg Order Value</th></tr>
                    </thead>
                    <tbody>
                      {DAILY_SALES.map((d) => (
                        <tr key={d.channel}>
                          <td className="font-semibold">{d.channel}</td>
                          <td>{d.orders}</td>
                          <td>{d.units}</td>
                          <td className="font-semibold text-green-700">{formatCurrency(d.revenue)}</td>
                          <td>{formatCurrency(Math.round(d.revenue / d.orders))}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot>
                      <tr className="bg-slate-50 font-bold">
                        <td className="px-4 py-3">Total</td>
                        <td className="px-4 py-3">{DAILY_SALES.reduce((s, d) => s + d.orders, 0)}</td>
                        <td className="px-4 py-3">{DAILY_SALES.reduce((s, d) => s + d.units, 0)}</td>
                        <td className="px-4 py-3 text-green-700">{formatCurrency(DAILY_SALES.reduce((s, d) => s + d.revenue, 0))}</td>
                        <td className="px-4 py-3">—</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* INVENTORY REPORT */}
          {activeReport === "inventory" && (
            <div className="premium-card overflow-hidden">
              <div className="p-4 border-b border-slate-100">
                <h3 className="text-sm font-semibold">Inventory Summary by Category</h3>
              </div>
              <div className="overflow-x-auto">
                <table className="data-table">
                  <thead>
                    <tr><th>Category</th><th>SKUs</th><th>Total Stock</th><th>Inventory Value</th><th>Low Stock</th></tr>
                  </thead>
                  <tbody>
                    {INVENTORY_SUMMARY.map((row) => (
                      <tr key={row.category}>
                        <td className="font-semibold">{row.category}</td>
                        <td>{row.skus}</td>
                        <td className="font-semibold">{row.totalStock.toLocaleString("en-IN")}</td>
                        <td className="font-semibold text-green-700">{formatCurrency(row.value)}</td>
                        <td>
                          {row.lowStock > 0
                            ? <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-red-100 text-red-700">{row.lowStock} alert</span>
                            : <span className="text-xs text-green-600 font-medium">✓ OK</span>}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                  <tfoot>
                    <tr className="bg-slate-50 font-bold">
                      <td className="px-4 py-3">Total</td>
                      <td className="px-4 py-3">{INVENTORY_SUMMARY.reduce((s, r) => s + r.skus, 0)}</td>
                      <td className="px-4 py-3">{INVENTORY_SUMMARY.reduce((s, r) => s + r.totalStock, 0).toLocaleString("en-IN")}</td>
                      <td className="px-4 py-3 text-green-700">{formatCurrency(INVENTORY_SUMMARY.reduce((s, r) => s + r.value, 0))}</td>
                      <td className="px-4 py-3">{INVENTORY_SUMMARY.reduce((s, r) => s + r.lowStock, 0)} alerts</td>
                    </tr>
                  </tfoot>
                </table>
              </div>
            </div>
          )}

          {/* EXPIRY REPORT */}
          {activeReport === "expiry" && (
            <div className="space-y-4">
              <div className="alert-warning">
                <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
                <p className="text-sm">
                  <strong>{EXPIRING_BATCHES.filter(b => b.daysLeft <= 60).length} batches</strong> expiring within 60 days — action required to prevent losses.
                </p>
              </div>
              <div className="premium-card overflow-hidden">
                <div className="p-4 border-b border-slate-100"><h3 className="text-sm font-semibold">Expiring Batches</h3></div>
                <div className="overflow-x-auto">
                  <table className="data-table">
                    <thead>
                      <tr><th>Product</th><th>Batch</th><th>Expiry Date</th><th>Qty Remaining</th><th>Days Left</th><th>Action</th></tr>
                    </thead>
                    <tbody>
                      {EXPIRING_BATCHES.map((b) => (
                        <tr key={b.batch}>
                          <td className="font-semibold text-sm">{b.product}</td>
                          <td className="font-mono text-xs text-slate-500">{b.batch}</td>
                          <td>{formatDate(b.expDate)}</td>
                          <td className="font-semibold">{b.qty} units</td>
                          <td>
                            <span className={`font-bold text-sm ${b.daysLeft <= 30 ? "text-red-600" : b.daysLeft <= 60 ? "text-amber-600" : "text-green-600"}`}>
                              {b.daysLeft} days
                            </span>
                          </td>
                          <td>
                            <button className="text-xs px-3 py-1 rounded-lg bg-amber-100 text-amber-700 hover:bg-amber-200 transition-colors font-medium">
                              Create Offer
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TEAM PERFORMANCE REPORT */}
          {activeReport === "team_performance" && (
            <div className="space-y-4">
              <div className="premium-card overflow-hidden">
                <div className="p-4 border-b border-slate-100"><h3 className="text-sm font-semibold">Team Performance — May 2025</h3></div>
                <div className="overflow-x-auto">
                  <table className="data-table">
                    <thead>
                      <tr><th>Team Member</th><th>Role</th><th>Attendance %</th><th>Tasks Done</th><th>Tasks Pending</th><th>Performance Score</th></tr>
                    </thead>
                    <tbody>
                      {TEAM_PERFORMANCE.map((t) => (
                        <tr key={t.name}>
                          <td className="font-semibold">{t.name}</td>
                          <td className="text-slate-500 text-sm">{t.role}</td>
                          <td>
                            <div className="flex items-center gap-2">
                              <div className="h-1.5 w-20 bg-slate-100 rounded-full overflow-hidden">
                                <div className="h-full rounded-full bg-green-500" style={{ width: `${t.attendance}%` }} />
                              </div>
                              <span className="text-sm font-semibold">{t.attendance}%</span>
                            </div>
                          </td>
                          <td className="font-semibold text-green-700">{t.tasksCompleted}</td>
                          <td className={t.tasksPending > 3 ? "font-semibold text-red-600" : "font-semibold text-amber-600"}>{t.tasksPending}</td>
                          <td>
                            <div className="flex items-center gap-2">
                              <div className="h-2 w-24 bg-slate-100 rounded-full overflow-hidden">
                                <div className="h-full rounded-full"
                                  style={{ width: `${t.score}%`, background: t.score >= 90 ? "#059669" : t.score >= 75 ? "#1B5FD4" : "#D97706" }} />
                              </div>
                              <span className="font-bold text-sm"
                                style={{ color: t.score >= 90 ? "#059669" : t.score >= 75 ? "#1B5FD4" : "#D97706" }}>
                                {t.score}%
                              </span>
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Default for other reports */}
          {!["daily_sales", "inventory", "expiry", "team_performance"].includes(activeReport) && (
            <div className="premium-card p-12 text-center">
              <FileBarChart className="w-12 h-12 text-slate-200 mx-auto mb-4" />
              <h3 className="text-lg font-display font-bold text-navy-950 mb-2">
                {REPORT_TYPES.find(r => r.id === activeReport)?.label}
              </h3>
              <p className="text-slate-400 text-sm mb-6">
                {REPORT_TYPES.find(r => r.id === activeReport)?.desc}
              </p>
              <button className="btn-gold inline-flex">
                <Download className="w-4 h-4" /> Generate Report
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
