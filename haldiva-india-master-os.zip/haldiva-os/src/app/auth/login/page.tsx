"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { createBrowserClient } from "@/lib/supabase";
import { toast } from "sonner";
import { Eye, EyeOff, Lock, Mail, AlertCircle, Loader2 } from "lucide-react";

const DEMO_USERS = [
  { label: "CEO / Founder", email: "ceo@haldiva.com", password: "HALDIVA@CEO2026", role: "ceo", color: "#C9A84C" },
  { label: "Kriti Gupta – Senior Executive", email: "kriti@haldiva.com", password: "Kriti@2026", role: "senior_executive", color: "#1B5FD4" },
  { label: "Deepender – Data Executive", email: "deepender@haldiva.com", password: "Deep@2026", role: "data_executive", color: "#059669" },
  { label: "Sayan – Digital Marketing", email: "sayan@haldiva.com", password: "Sayan@2026", role: "digital_marketing", color: "#7C3AED" },
  { label: "S.S. Enterprises – Distributor", email: "dist@sse.com", password: "Dist@2026", role: "distributor", color: "#D97706" },
  { label: "Nutrition Mantra 360 – Reseller", email: "reseller@nm360.com", password: "Resell@2026", role: "reseller", color: "#BE185D" },
];

export default function LoginPage() {
  const router = useRouter();
  const supabase = createBrowserClient();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [attempts, setAttempts] = useState(0);

  async function handleLogin(e: React.FormEvent) {
    e.preventDefault();
    if (!email || !password) {
      setError("Please enter your email and password.");
      return;
    }
    if (attempts >= 5) {
      setError("Too many failed attempts. Please contact your administrator.");
      return;
    }

    setLoading(true);
    setError("");

    try {
      const { data, error: authError } = await supabase.auth.signInWithPassword({
        email: email.toLowerCase().trim(),
        password,
      });

      if (authError) {
        setAttempts((prev) => prev + 1);
        setError("Invalid email or password. Please try again.");
        setLoading(false);
        return;
      }

      if (data.user) {
        // Update last login
        await supabase
          .from("users")
          .update({ last_login: new Date().toISOString() })
          .eq("id", data.user.id);

        toast.success(`Welcome back! Redirecting to your dashboard...`);
        router.push("/dashboard");
        router.refresh();
      }
    } catch {
      setError("An unexpected error occurred. Please try again.");
      setLoading(false);
    }
  }

  function fillCredentials(u: (typeof DEMO_USERS)[0]) {
    setEmail(u.email);
    setPassword(u.password);
    setError("");
  }

  return (
    <div className="min-h-screen bg-navy-gradient flex items-center justify-center p-4 relative overflow-hidden">
      {/* Background effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute -top-64 -left-64 w-[600px] h-[600px] rounded-full opacity-10"
          style={{ background: "radial-gradient(circle, #C9A84C, transparent)" }} />
        <div className="absolute -bottom-64 -right-64 w-[600px] h-[600px] rounded-full opacity-10"
          style={{ background: "radial-gradient(circle, #1B5FD4, transparent)" }} />
        <div className="absolute inset-0"
          style={{
            backgroundImage: `linear-gradient(rgba(255,255,255,0.02) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.02) 1px, transparent 1px)`,
            backgroundSize: "52px 52px"
          }} />
      </div>

      <div className="w-full max-w-md relative z-10 animate-fade-in-up">
        {/* Logo */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl mb-4"
            style={{ background: "linear-gradient(135deg, #C9A84C, #E2BC5E)" }}>
            <span className="text-2xl font-display font-bold text-navy-950">H</span>
          </div>
          <h1 className="text-3xl font-display font-bold text-gold-500 tracking-widest uppercase">
            HALDIVA INDIA
          </h1>
          <div className="w-14 h-px mx-auto my-3"
            style={{ background: "linear-gradient(90deg, transparent, #C9A84C, transparent)" }} />
          <p className="text-xs text-slate-400 tracking-[4px] uppercase">
            Operations Hub · Secure Access
          </p>
        </div>

        {/* Login Card */}
        <div className="glass rounded-2xl p-8">
          <h2 className="text-white font-semibold text-lg mb-1">Sign in to your workspace</h2>
          <p className="text-slate-400 text-sm mb-6">
            Your access is role-restricted to your assigned modules only.
          </p>

          <form onSubmit={handleLogin} className="space-y-4">
            {/* Email */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Email Address
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="your@email.com"
                  className="w-full pl-10 pr-4 py-3 rounded-lg text-sm text-white placeholder:text-slate-600 outline-none transition-all duration-150"
                  style={{
                    background: "rgba(255,255,255,0.07)",
                    border: "1px solid rgba(255,255,255,0.12)",
                  }}
                  onFocus={(e) => (e.target.style.borderColor = "#C9A84C")}
                  onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
                  autoComplete="email"
                  disabled={loading}
                />
              </div>
            </div>

            {/* Password */}
            <div>
              <label className="block text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">
                Password
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                <input
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter your password"
                  className="w-full pl-10 pr-12 py-3 rounded-lg text-sm text-white placeholder:text-slate-600 outline-none transition-all duration-150"
                  style={{
                    background: "rgba(255,255,255,0.07)",
                    border: "1px solid rgba(255,255,255,0.12)",
                  }}
                  onFocus={(e) => (e.target.style.borderColor = "#C9A84C")}
                  onBlur={(e) => (e.target.style.borderColor = "rgba(255,255,255,0.12)")}
                  autoComplete="current-password"
                  disabled={loading}
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-slate-300 transition-colors"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Error */}
            {error && (
              <div className="flex items-center gap-2 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm animate-fade-in">
                <AlertCircle className="w-4 h-4 flex-shrink-0" />
                {error}
              </div>
            )}

            {/* Attempts warning */}
            {attempts > 2 && attempts < 5 && (
              <div className="text-amber-400 text-xs text-center">
                ⚠ {5 - attempts} attempt{5 - attempts !== 1 ? "s" : ""} remaining before lockout
              </div>
            )}

            {/* Submit */}
            <button
              type="submit"
              disabled={loading}
              className="w-full py-3 rounded-lg font-semibold text-sm text-navy-950 transition-all duration-150 flex items-center justify-center gap-2 mt-2 disabled:opacity-60 disabled:cursor-not-allowed"
              style={{
                background: loading ? "#8A6A28" : "linear-gradient(135deg, #C9A84C, #E2BC5E)",
                boxShadow: "0 4px 20px rgba(201,168,76,0.3)",
              }}
            >
              {loading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Authenticating...
                </>
              ) : (
                "Sign In Securely"
              )}
            </button>
          </form>

          {/* Demo credentials */}
          <div className="mt-6 pt-5 border-t border-white/8">
            <p className="text-xs text-slate-500 uppercase tracking-[2px] text-center mb-3">
              Demo Access
            </p>
            <div className="grid grid-cols-1 gap-1.5">
              {DEMO_USERS.map((u) => (
                <button
                  key={u.email}
                  onClick={() => fillCredentials(u)}
                  className="flex items-center gap-3 px-3 py-2 rounded-lg text-left transition-all duration-150 hover:bg-white/5 group"
                >
                  <div
                    className="w-2 h-2 rounded-full flex-shrink-0"
                    style={{ background: u.color }}
                  />
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-slate-300 group-hover:text-white transition-colors truncate">
                      {u.label}
                    </p>
                    <p className="text-xs text-slate-600 truncate">{u.email}</p>
                  </div>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Footer */}
        <p className="text-center text-xs text-slate-600 mt-6">
          HALDIVA INDIA Operations Hub · FSSAI 22725441001672
          <br />
          Gaur City Center, Greater Noida (West) — 201306
        </p>
      </div>
    </div>
  );
}
