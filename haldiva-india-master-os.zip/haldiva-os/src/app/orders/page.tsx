"use client";

import { useState } from "react";
import {
  ShoppingCart, Plus, Search, Filter, Download, Truck, Eye,
  CheckCircle, XCircle, Package, Clock, AlertCircle, RefreshCw,
  QrCode, FileText, MapPin, Phone, CreditCard
} from "lucide-react";
import { formatCurrency, formatDate, downloadCSV } from "@/lib/utils";

type OrderStatus = "new" | "confirmed" | "packed" | "dispatched" | "delivered" | "pending_payment" | "cancelled" | "returned";
type OrderType = "b2c_online" | "b2c_offline" | "distributor" | "reseller" | "corporate_gifting" | "bulk" | "marketplace";

interface Order {
  id: string;
  orderNumber: string;
  type: OrderType;
  channel: string;
  customerName: string;
  customerPhone: string;
  items: { name: string; qty: number; price: number }[];
  subtotal: number;
  gst: number;
  shipping: number;
  total: number;
  amountPaid: number;
  status: OrderStatus;
  paymentStatus: "pending" | "partial" | "paid";
  courier?: string;
  trackingId?: string;
  dispatchDate?: string;
  date: string;
  notes?: string;
}

const ORDERS: Order[] = [
  { id: "1", orderNumber: "HLD-20250504-1294", type: "distributor", channel: "distributor", customerName: "S.S. Enterprises (Rajesh Traders)", customerPhone: "9876543210", items: [{ name: "Phool Ras Honey", qty: 120, price: 210 }], subtotal: 25200, gst: 0, shipping: 0, total: 25200, amountPaid: 0, status: "dispatched", paymentStatus: "pending", courier: "DTDC", trackingId: "DTDC1234567890", dispatchDate: "2025-04-12", date: "2025-04-10" },
  { id: "2", orderNumber: "HLD-20250504-1293", type: "b2c_online", channel: "shopify", customerName: "Priya Sharma", customerPhone: "9811223344", items: [{ name: "Royal Festive Gift Duo", qty: 1, price: 1629 }], subtotal: 1629, gst: 81, shipping: 0, total: 1710, amountPaid: 1710, status: "confirmed", paymentStatus: "paid", date: "2025-05-04" },
  { id: "3", orderNumber: "HLD-20250504-1292", type: "distributor", channel: "distributor", customerName: "Sharma & Co.", customerPhone: "9765432198", items: [{ name: "Shilajit Honey", qty: 80, price: 320 }, { name: "Turmeric Powder", qty: 40, price: 290 }], subtotal: 37200, gst: 0, shipping: 0, total: 37200, amountPaid: 0, status: "pending_payment", paymentStatus: "pending", date: "2025-04-28" },
  { id: "4", orderNumber: "HLD-20250504-1291", type: "marketplace", channel: "amazon", customerName: "Amazon Customer #A123", customerPhone: "N/A", items: [{ name: "Haldi Doodh Masala", qty: 2, price: 365 }, { name: "Masala Tea", qty: 2, price: 385 }], subtotal: 1500, gst: 75, shipping: 0, total: 1575, amountPaid: 1575, status: "packed", paymentStatus: "paid", date: "2025-05-04" },
  { id: "5", orderNumber: "HLD-20250504-1290", type: "b2c_offline", channel: "walkin", customerName: "Ramesh Kumar", customerPhone: "9123456789", items: [{ name: "A2 Gir Cow Ghee", qty: 2, price: 399 }], subtotal: 798, gst: 40, shipping: 0, total: 838, amountPaid: 838, status: "delivered", paymentStatus: "paid", date: "2025-05-03" },
  { id: "6", orderNumber: "HLD-20250504-1289", type: "corporate_gifting", channel: "corporate", customerName: "TCS Employee Welfare", customerPhone: "9000011111", items: [{ name: "Complete Mini Wellness Box", qty: 25, price: 650 }], subtotal: 16250, gst: 813, shipping: 500, total: 17563, amountPaid: 8781, status: "confirmed", paymentStatus: "partial", date: "2025-05-02" },
  { id: "7", orderNumber: "HLD-20250504-1288", type: "reseller", channel: "reseller", customerName: "Nutrition Mantra 360", customerPhone: "9123456789", items: [{ name: "Daily Wellness Duo", qty: 15, price: 540 }], subtotal: 8100, gst: 405, shipping: 0, total: 8505, amountPaid: 8505, status: "dispatched", paymentStatus: "paid", courier: "BlueDart", trackingId: "BD9876543", date: "2025-04-25" },
];

const STATUS_CFG: Record<OrderStatus, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  new: { label: "New", color: "#1B5FD4", bg: "#EFF6FF", icon: Plus },
  confirmed: { label: "Confirmed", color: "#7C3AED", bg: "#F5F3FF", icon: CheckCircle },
  packed: { label: "Packed", color: "#0891B2", bg: "#CFFAFE", icon: Package },
  dispatched: { label: "Dispatched", color: "#D97706", bg: "#FEF3C7", icon: Truck },
  delivered: { label: "Delivered", color: "#059669", bg: "#DCFCE7", icon: CheckCircle },
  pending_payment: { label: "Pending Payment", color: "#DC2626", bg: "#FEE2E2", icon: Clock },
  cancelled: { label: "Cancelled", color: "#6B7280", bg: "#F3F4F6", icon: XCircle },
  returned: { label: "Returned", color: "#BE185D", bg: "#FDF2F8", icon: RefreshCw },
};

const TYPE_CFG: Record<OrderType, { label: string; color: string }> = {
  b2c_online: { label: "B2C Online", color: "#1B5FD4" },
  b2c_offline: { label: "B2C Offline", color: "#059669" },
  distributor: { label: "Distributor", color: "#D97706" },
  reseller: { label: "Reseller", color: "#7C3AED" },
  corporate_gifting: { label: "Corporate", color: "#BE185D" },
  bulk: { label: "Bulk", color: "#0891B2" },
  marketplace: { label: "Marketplace", color: "#DC2626" },
};

const STATUS_FLOW: Partial<Record<OrderStatus, OrderStatus>> = {
  new: "confirmed",
  confirmed: "packed",
  packed: "dispatched",
  dispatched: "delivered",
};

export default function OrdersPage() {
  const [orders, setOrders] = useState<Order[]>(ORDERS);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [selectedOrder, setSelectedOrder] = useState<Order | null>(null);
  const [showNewOrder, setShowNewOrder] = useState(false);

  const filtered = orders.filter((o) => {
    const matchSearch =
      o.orderNumber.toLowerCase().includes(search.toLowerCase()) ||
      o.customerName.toLowerCase().includes(search.toLowerCase()) ||
      o.channel.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === "all" || o.status === statusFilter;
    const matchType = typeFilter === "all" || o.type === typeFilter;
    return matchSearch && matchStatus && matchType;
  });

  const totals = {
    today: orders.filter((o) => o.date === new Date().toISOString().split("T")[0]).reduce((s, o) => s + o.total, 0),
    pending: orders.filter((o) => ["new", "confirmed", "packed"].includes(o.status)).length,
    paymentDue: orders.filter((o) => o.paymentStatus === "pending" || o.paymentStatus === "partial").reduce((s, o) => s + (o.total - o.amountPaid), 0),
    dispatched: orders.filter((o) => o.status === "dispatched").length,
  };

  function advanceStatus(orderId: string) {
    setOrders((prev) =>
      prev.map((o) => {
        if (o.id !== orderId) return o;
        const next = STATUS_FLOW[o.status];
        return next ? { ...o, status: next } : o;
      })
    );
  }

  return (
    <div className="p-6 space-y-5 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div>
          <h1 className="text-2xl font-display font-bold text-navy-950">Orders & Dispatch</h1>
          <p className="text-slate-400 text-sm mt-1">
            {orders.length} total orders · {totals.pending} pending action · {formatCurrency(totals.paymentDue)} payment due
          </p>
        </div>
        <div className="flex items-center gap-2 flex-wrap">
          <button
            onClick={() => downloadCSV(orders.map((o) => ({ id: o.orderNumber, customer: o.customerName, total: o.total, status: o.status })), "orders")}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 text-slate-600 text-xs font-medium hover:bg-slate-50"
          >
            <Download className="w-3.5 h-3.5" /> Export
          </button>
          <button
            onClick={() => setShowNewOrder(true)}
            className="btn-gold text-xs py-2"
          >
            <Plus className="w-3.5 h-3.5" /> New Order
          </button>
        </div>
      </div>

      {/* Metric Cards */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Today's Orders", value: orders.filter((o) => o.date === "2025-05-04").length, sub: `${formatCurrency(orders.filter((o) => o.date === "2025-05-04").reduce((s, o) => s + o.total, 0))} revenue`, color: "#1B5FD4", bg: "#EFF6FF" },
          { label: "Pending Action", value: totals.pending, sub: "Need confirmation / packing / dispatch", color: "#7C3AED", bg: "#F5F3FF" },
          { label: "Payment Due", value: formatCurrency(totals.paymentDue), sub: `${orders.filter((o) => o.paymentStatus !== "paid").length} orders unpaid`, color: "#DC2626", bg: "#FEE2E2" },
          { label: "In Transit", value: totals.dispatched, sub: "Orders dispatched", color: "#D97706", bg: "#FEF3C7" },
        ].map((m) => (
          <div key={m.label} className="stat-card">
            <p className="stat-label">{m.label}</p>
            <p className="stat-value text-xl" style={{ color: m.color }}>{m.value}</p>
            <p className="stat-meta">{m.sub}</p>
          </div>
        ))}
      </div>

      {/* Filters */}
      <div className="premium-card p-4 flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-[180px] max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input
            type="text"
            placeholder="Search orders..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="form-input pl-9 py-2 text-sm"
          />
        </div>
        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          className="form-input w-auto py-2 text-sm"
        >
          <option value="all">All Statuses</option>
          {Object.entries(STATUS_CFG).map(([k, v]) => (
            <option key={k} value={k}>{v.label}</option>
          ))}
        </select>
        <select
          value={typeFilter}
          onChange={(e) => setTypeFilter(e.target.value)}
          className="form-input w-auto py-2 text-sm"
        >
          <option value="all">All Types</option>
          {Object.entries(TYPE_CFG).map(([k, v]) => (
            <option key={k} value={k}>{v.label}</option>
          ))}
        </select>
        <span className="text-sm text-slate-400 ml-auto">{filtered.length} orders</span>
      </div>

      {/* Status Pipeline */}
      <div className="grid grid-cols-4 md:grid-cols-8 gap-2">
        {Object.entries(STATUS_CFG).map(([status, cfg]) => {
          const count = orders.filter((o) => o.status === status).length;
          return (
            <button
              key={status}
              onClick={() => setStatusFilter(statusFilter === status ? "all" : status)}
              className={`p-3 rounded-xl border text-center transition-all duration-150 ${statusFilter === status ? "border-2 shadow-md" : "border-slate-100 hover:border-slate-200"}`}
              style={statusFilter === status ? { borderColor: cfg.color, background: cfg.bg } : { background: "#fff" }}
            >
              <p className="text-xl font-display font-bold" style={{ color: cfg.color }}>{count}</p>
              <p className="text-[10px] font-medium text-slate-500 mt-0.5 leading-tight">{cfg.label}</p>
            </button>
          );
        })}
      </div>

      {/* Orders Table */}
      <div className="premium-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>Order ID</th>
                <th>Customer / Partner</th>
                <th>Type</th>
                <th>Channel</th>
                <th>Items</th>
                <th>Total</th>
                <th>Payment</th>
                <th>Status</th>
                <th>Date</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((order) => {
                const sc = STATUS_CFG[order.status];
                const tc = TYPE_CFG[order.type];
                const nextStatus = STATUS_FLOW[order.status];
                const nextLabel = nextStatus ? STATUS_CFG[nextStatus]?.label : null;

                return (
                  <tr key={order.id} className="cursor-pointer" onClick={() => setSelectedOrder(order)}>
                    <td>
                      <p className="font-mono text-xs font-semibold text-navy-950">{order.orderNumber.split("-").slice(-1)[0]}</p>
                      <p className="font-mono text-[10px] text-slate-300">{order.orderNumber}</p>
                    </td>
                    <td>
                      <p className="font-semibold text-sm">{order.customerName}</p>
                      <p className="text-xs text-slate-400">{order.customerPhone}</p>
                    </td>
                    <td>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-full"
                        style={{ color: tc.color, background: tc.color + "18" }}>
                        {tc.label}
                      </span>
                    </td>
                    <td>
                      <span className="text-xs capitalize text-slate-500 bg-slate-100 px-2 py-0.5 rounded-full font-medium">
                        {order.channel}
                      </span>
                    </td>
                    <td>
                      <p className="text-xs text-slate-600">{order.items.length} item{order.items.length !== 1 ? "s" : ""}</p>
                      <p className="text-[10px] text-slate-400 truncate max-w-[120px]">
                        {order.items.map((i) => i.name).join(", ")}
                      </p>
                    </td>
                    <td className="font-semibold text-navy-950">{formatCurrency(order.total)}</td>
                    <td>
                      <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${
                        order.paymentStatus === "paid" ? "bg-green-100 text-green-700" :
                        order.paymentStatus === "partial" ? "bg-amber-100 text-amber-700" :
                        "bg-red-100 text-red-700"}`}>
                        {order.paymentStatus === "paid" ? "Paid" : order.paymentStatus === "partial" ? `Partial (${formatCurrency(order.total - order.amountPaid)} due)` : `Due ${formatCurrency(order.total)}`}
                      </span>
                    </td>
                    <td onClick={(e) => e.stopPropagation()}>
                      <span className="flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full w-fit"
                        style={{ color: sc.color, background: sc.bg }}>
                        <sc.icon className="w-3 h-3" />
                        {sc.label}
                      </span>
                      {nextLabel && (
                        <button
                          onClick={(e) => { e.stopPropagation(); advanceStatus(order.id); }}
                          className="text-[10px] mt-1 px-2 py-0.5 rounded bg-slate-100 text-slate-500 hover:bg-slate-200 transition-colors font-medium"
                        >
                          → {nextLabel}
                        </button>
                      )}
                    </td>
                    <td className="text-xs text-slate-400">{formatDate(order.date, "dd MMM")}</td>
                    <td onClick={(e) => e.stopPropagation()}>
                      <div className="flex gap-1">
                        <button className="p-1.5 rounded hover:bg-slate-100 text-slate-400 hover:text-navy-950 transition-colors" title="View">
                          <Eye className="w-3.5 h-3.5" />
                        </button>
                        <button className="p-1.5 rounded hover:bg-slate-100 text-slate-400 hover:text-navy-950 transition-colors" title="Invoice">
                          <FileText className="w-3.5 h-3.5" />
                        </button>
                        {order.trackingId && (
                          <button className="p-1.5 rounded hover:bg-slate-100 text-slate-400 hover:text-blue-600 transition-colors" title="Track">
                            <MapPin className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
        {filtered.length === 0 && (
          <div className="py-16 text-center">
            <ShoppingCart className="w-10 h-10 text-slate-200 mx-auto mb-3" />
            <p className="text-slate-400 font-medium">No orders found</p>
            <p className="text-slate-300 text-sm mt-1">Try changing your search or filters</p>
          </div>
        )}
      </div>

      {/* Order Detail Modal */}
      {selectedOrder && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setSelectedOrder(null)}>
          <div className="bg-white rounded-2xl w-full max-w-2xl max-h-[90vh] overflow-y-auto shadow-2xl animate-scale-in" onClick={(e) => e.stopPropagation()}>
            {/* Modal Header */}
            <div className="p-6 border-b border-slate-100 flex items-start justify-between">
              <div>
                <div className="flex items-center gap-2 mb-1">
                  <h2 className="text-lg font-display font-bold text-navy-950">{selectedOrder.orderNumber}</h2>
                  <span className="text-xs font-semibold px-2 py-0.5 rounded-full"
                    style={{ color: STATUS_CFG[selectedOrder.status].color, background: STATUS_CFG[selectedOrder.status].bg }}>
                    {STATUS_CFG[selectedOrder.status].label}
                  </span>
                </div>
                <p className="text-sm text-slate-400">{formatDate(selectedOrder.date)} · {TYPE_CFG[selectedOrder.type].label} · {selectedOrder.channel}</p>
              </div>
              <button onClick={() => setSelectedOrder(null)} className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 transition-colors">
                <XCircle className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-5">
              {/* Customer */}
              <div className="flex items-start gap-3 p-4 bg-slate-50 rounded-xl">
                <div className="w-10 h-10 rounded-xl bg-navy-950 text-gold-500 flex items-center justify-center font-display font-bold text-lg flex-shrink-0">
                  {selectedOrder.customerName[0]}
                </div>
                <div>
                  <p className="font-semibold text-navy-950">{selectedOrder.customerName}</p>
                  <div className="flex items-center gap-3 mt-1 text-xs text-slate-500">
                    <span className="flex items-center gap-1"><Phone className="w-3 h-3" />{selectedOrder.customerPhone}</span>
                  </div>
                </div>
              </div>

              {/* Items */}
              <div>
                <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-2">Order Items</p>
                <div className="space-y-2">
                  {selectedOrder.items.map((item, i) => (
                    <div key={i} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                      <div>
                        <p className="text-sm font-semibold text-navy-950">{item.name}</p>
                        <p className="text-xs text-slate-400">Qty: {item.qty} × {formatCurrency(item.price)}</p>
                      </div>
                      <p className="font-bold text-navy-950">{formatCurrency(item.qty * item.price)}</p>
                    </div>
                  ))}
                </div>
              </div>

              {/* Totals */}
              <div className="border-t border-slate-100 pt-4 space-y-2 text-sm">
                <div className="flex justify-between text-slate-500"><span>Subtotal</span><span>{formatCurrency(selectedOrder.subtotal)}</span></div>
                {selectedOrder.gst > 0 && <div className="flex justify-between text-slate-500"><span>GST</span><span>{formatCurrency(selectedOrder.gst)}</span></div>}
                {selectedOrder.shipping > 0 && <div className="flex justify-between text-slate-500"><span>Shipping</span><span>{formatCurrency(selectedOrder.shipping)}</span></div>}
                <div className="flex justify-between font-bold text-navy-950 text-base pt-2 border-t border-slate-100">
                  <span>Total</span><span>{formatCurrency(selectedOrder.total)}</span>
                </div>
                <div className="flex justify-between text-green-700 font-semibold"><span>Paid</span><span>{formatCurrency(selectedOrder.amountPaid)}</span></div>
                {selectedOrder.total - selectedOrder.amountPaid > 0 && (
                  <div className="flex justify-between text-red-600 font-semibold">
                    <span>Due</span><span>{formatCurrency(selectedOrder.total - selectedOrder.amountPaid)}</span>
                  </div>
                )}
              </div>

              {/* Dispatch Info */}
              {selectedOrder.trackingId && (
                <div className="p-4 bg-blue-50 rounded-xl border border-blue-100">
                  <p className="text-xs font-semibold text-blue-600 uppercase tracking-wider mb-2">Dispatch Details</p>
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div><p className="text-slate-400 text-xs">Courier</p><p className="font-semibold">{selectedOrder.courier}</p></div>
                    <div><p className="text-slate-400 text-xs">Tracking ID</p><p className="font-mono font-semibold text-blue-600">{selectedOrder.trackingId}</p></div>
                    {selectedOrder.dispatchDate && <div><p className="text-slate-400 text-xs">Dispatch Date</p><p className="font-semibold">{formatDate(selectedOrder.dispatchDate)}</p></div>}
                  </div>
                </div>
              )}

              {/* Action Buttons */}
              <div className="flex gap-2 pt-2">
                {STATUS_FLOW[selectedOrder.status] && (
                  <button
                    onClick={() => { advanceStatus(selectedOrder.id); setSelectedOrder(null); }}
                    className="flex-1 btn-navy text-sm py-2.5 justify-center"
                  >
                    Move to {STATUS_CFG[STATUS_FLOW[selectedOrder.status]!].label}
                  </button>
                )}
                <button className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50">
                  <FileText className="w-4 h-4" /> Generate Invoice
                </button>
                <button className="flex-1 flex items-center justify-center gap-1.5 py-2.5 rounded-lg border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50">
                  <CreditCard className="w-4 h-4" /> Record Payment
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
