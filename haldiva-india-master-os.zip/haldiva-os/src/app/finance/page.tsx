"use client";

import { useState } from "react";
import {
  IndianRupee, TrendingUp, TrendingDown, Plus, Download,
  PieChart, BarChart2, CreditCard, FileText, Calendar
} from "lucide-react";
import {
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, BarChart, Bar, PieChart as RPieChart,
  Pie, Cell, Legend
} from "recharts";
import { formatCurrency, formatDate, downloadCSV } from "@/lib/utils";

const MONTHLY_DATA = [
  { month: "Nov '24", revenue: 84000, expenses: 38000, profit: 46000 },
  { month: "Dec '24", revenue: 142000, expenses: 58000, profit: 84000 },
  { month: "Jan '25", revenue: 118000, expenses: 47000, profit: 71000 },
  { month: "Feb '25", revenue: 165000, expenses: 62000, profit: 103000 },
  { month: "Mar '25", revenue: 198000, expenses: 74000, profit: 124000 },
  { month: "Apr '25", revenue: 312000, expenses: 108000, profit: 204000 },
  { month: "May '25", revenue: 458600, expenses: 142000, profit: 316600 },
];

const EXPENSE_CATEGORIES = [
  { name: "Purchase/COGS", amount: 68000, color: "#1B5FD4" },
  { name: "Packaging", amount: 18000, color: "#7C3AED" },
  { name: "Courier/Shipping", amount: 14000, color: "#059669" },
  { name: "Digital Ads", amount: 12400, color: "#D97706" },
  { name: "Salaries", amount: 18000, color: "#BE185D" },
  { name: "Rent/Utilities", amount: 6000, color: "#0891B2" },
  { name: "Misc", amount: 5600, color: "#6B7280" },
];

const CHANNEL_REVENUE = [
  { channel: "Shopify D2C", revenue: 142000, color: "#1B5FD4" },
  { channel: "Distributor", revenue: 98000, color: "#C9A84C" },
  { channel: "Amazon", revenue: 86000, color: "#DC2626" },
  { channel: "Flipkart", revenue: 42000, color: "#F97316" },
  { channel: "Offline", revenue: 56000, color: "#059669" },
  { channel: "Corporate", revenue: 34600, color: "#7C3AED" },
];

const EXPENSES = [
  { id: "e1", category: "Purchase", description: "Raw honey procurement — April batch", amount: 42000, vendor: "Himalayan Honey Farms", date: "2025-04-05", invoice: "INV-2025-041" },
  { id: "e2", category: "Packaging", description: "Glass jars + labels — 500 units", amount: 12500, vendor: "Packfast India", date: "2025-04-08", invoice: "PF-2025-089" },
  { id: "e3", category: "Ads", description: "Meta Ads — Honey product campaign", amount: 8400, vendor: "Meta Platforms", date: "2025-04-15", invoice: "META-2025-04" },
  { id: "e4", category: "Courier", description: "DTDC bulk dispatch — 60 orders", amount: 6800, vendor: "DTDC Express", date: "2025-04-18", invoice: "DTDC-0418" },
  { id: "e5", category: "Salary", description: "April team salaries", amount: 18000, vendor: "Internal", date: "2025-04-30", invoice: "SAL-APR-25" },
  { id: "e6", category: "Lab Testing", description: "COA lab test — Honey batch B025", amount: 3200, vendor: "Fssai Lab Pvt Ltd", date: "2025-04-12", invoice: "LAB-2025-044" },
];

const PENDING_PAYMENTS = [
  { partner: "S.S. Enterprises", amount: 60750, dueDate: "2025-05-10", overdue: false, orders: 3 },
  { partner: "Sharma & Co.", amount: 37200, dueDate: "2025-05-02", overdue: true, orders: 1 },
  { partner: "TCS Corporate", amount: 8781, dueDate: "2025-05-15", overdue: false, orders: 1 },
];

const EXPENSE_CAT_COLORS: Record<string, string> = {
  Purchase: "#1B5FD4", Packaging: "#7C3AED", Courier: "#059669",
  Ads: "#D97706", Salary: "#BE185D", "Lab Testing": "#0891B2", Misc: "#6B7280",
};

export default function FinancePage() {
  const [activeTab, setActiveTab] = useState<"overview" | "income" | "expenses" | "payments">("overview");
  const [showAddExpense, setShowAddExpense] = useState(false);

  const totalRevenue = MONTHLY_DATA[MONTHLY_DATA.length - 1].revenue;
  const totalExpenses = MONTHLY_DATA[MONTHLY_DATA.length - 1].expenses;
  const grossProfit = totalRevenue - totalExpenses;
  const grossMargin = Math.round((grossProfit / totalRevenue) * 100);
  const pendingDue = PENDING_PAYMENTS.reduce((s, p) => s + p.amount, 0);

  return (
    <div className="p-6 space-y-5 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold text-navy-950">Finance & Accounts</h1>
          <p className="text-slate-400 text-sm mt-1">May 2025 · Gross margin {grossMargin}% · {formatCurrency(pendingDue)} pending recovery</p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => downloadCSV(EXPENSES.map((e) => ({ ...e })), "expenses")}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 text-xs font-medium text-slate-600 hover:bg-slate-50">
            <Download className="w-3.5 h-3.5" /> Export
          </button>
          <button onClick={() => setShowAddExpense(true)} className="btn-gold text-xs py-2">
            <Plus className="w-3.5 h-3.5" /> Add Expense
          </button>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Month Revenue", value: formatCurrency(totalRevenue), sub: "+47% vs last month", trend: "up", color: "#059669", bg: "#DCFCE7", icon: TrendingUp },
          { label: "Month Expenses", value: formatCurrency(totalExpenses), sub: "Within budget", trend: "neutral", color: "#DC2626", bg: "#FEE2E2", icon: TrendingDown },
          { label: "Gross Profit", value: formatCurrency(grossProfit), sub: `${grossMargin}% margin`, trend: "up", color: "#1B5FD4", bg: "#EFF6FF", icon: IndianRupee },
          { label: "Pending Recovery", value: formatCurrency(pendingDue), sub: `${PENDING_PAYMENTS.filter(p => p.overdue).length} overdue`, trend: "down", color: "#D97706", bg: "#FEF3C7", icon: CreditCard },
        ].map((m) => (
          <div key={m.label} className="stat-card">
            <div className="flex items-center justify-between mb-2">
              <p className="stat-label">{m.label}</p>
              <div className="w-7 h-7 rounded-lg flex items-center justify-center" style={{ background: m.bg }}>
                <m.icon className="w-3.5 h-3.5" style={{ color: m.color }} />
              </div>
            </div>
            <p className="stat-value text-xl" style={{ color: m.color }}>{m.value}</p>
            <p className="stat-meta">{m.sub}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-slate-100 rounded-xl w-fit">
        {[
          { key: "overview", label: "P&L Overview" },
          { key: "income", label: "Income" },
          { key: "expenses", label: "Expenses" },
          { key: "payments", label: "Payments Due" },
        ].map(({ key, label }) => (
          <button key={key} onClick={() => setActiveTab(key as typeof activeTab)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === key ? "bg-white text-navy-950 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
            {label}
          </button>
        ))}
      </div>

      {/* OVERVIEW TAB */}
      {activeTab === "overview" && (
        <div className="space-y-5">
          {/* P&L Chart */}
          <div className="premium-card p-5">
            <div className="section-header">
              <div>
                <h3 className="section-title">Profit & Loss — Last 7 Months</h3>
                <p className="section-sub">Revenue vs expenses vs gross profit</p>
              </div>
            </div>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={MONTHLY_DATA}>
                <defs>
                  {[{ key: "revenue", color: "#059669" }, { key: "expenses", color: "#DC2626" }, { key: "profit", color: "#1B5FD4" }].map(({ key, color }) => (
                    <linearGradient key={key} id={`g-${key}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor={color} stopOpacity={0.15} />
                      <stop offset="95%" stopColor={color} stopOpacity={0.01} />
                    </linearGradient>
                  ))}
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" />
                <XAxis dataKey="month" tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                <YAxis tick={{ fontSize: 11, fill: "#94a3b8" }} axisLine={false} tickLine={false}
                  tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                <Tooltip formatter={(v: number) => [formatCurrency(v), ""]}
                  contentStyle={{ borderRadius: 8, border: "1px solid #e2e8f0", fontSize: 12 }} />
                <Area type="monotone" dataKey="revenue" stroke="#059669" fill="url(#g-revenue)" strokeWidth={2.5} name="Revenue" />
                <Area type="monotone" dataKey="profit" stroke="#1B5FD4" fill="url(#g-profit)" strokeWidth={2.5} name="Gross Profit" />
                <Area type="monotone" dataKey="expenses" stroke="#DC2626" fill="url(#g-expenses)" strokeWidth={2} name="Expenses" />
                <Legend iconType="circle" iconSize={8} wrapperStyle={{ fontSize: 11 }} />
              </AreaChart>
            </ResponsiveContainer>
          </div>

          {/* Channel Revenue + Expense Breakdown */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
            <div className="premium-card p-5">
              <h3 className="section-title mb-4">Revenue by Channel</h3>
              <ResponsiveContainer width="100%" height={220}>
                <BarChart data={CHANNEL_REVENUE} layout="vertical">
                  <XAxis type="number" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false}
                    tickFormatter={(v) => `₹${(v / 1000).toFixed(0)}k`} />
                  <YAxis type="category" dataKey="channel" tick={{ fontSize: 11, fill: "#64748b" }} axisLine={false} tickLine={false} width={100} />
                  <Tooltip formatter={(v: number) => [formatCurrency(v), "Revenue"]} contentStyle={{ borderRadius: 8, fontSize: 12 }} />
                  <Bar dataKey="revenue" radius={[0, 4, 4, 0]}>
                    {CHANNEL_REVENUE.map((entry, i) => <Cell key={i} fill={entry.color} />)}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </div>

            <div className="premium-card p-5">
              <h3 className="section-title mb-4">Expense Breakdown</h3>
              <div className="flex items-center gap-4">
                <ResponsiveContainer width={140} height={140}>
                  <RPieChart>
                    <Pie data={EXPENSE_CATEGORIES} cx="50%" cy="50%" innerRadius={40} outerRadius={65} paddingAngle={2} dataKey="amount">
                      {EXPENSE_CATEGORIES.map((e, i) => <Cell key={i} fill={e.color} />)}
                    </Pie>
                  </RPieChart>
                </ResponsiveContainer>
                <div className="flex-1 space-y-1.5">
                  {EXPENSE_CATEGORIES.map((e) => (
                    <div key={e.name} className="flex items-center gap-2">
                      <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: e.color }} />
                      <span className="text-xs text-slate-500 flex-1">{e.name}</span>
                      <span className="text-xs font-semibold text-navy-950">{formatCurrency(e.amount)}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* EXPENSES TAB */}
      {activeTab === "expenses" && (
        <div className="premium-card overflow-hidden">
          <div className="p-4 border-b border-slate-100">
            <h3 className="text-sm font-semibold text-navy-950">All Expenses</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Date</th>
                  <th>Category</th>
                  <th>Description</th>
                  <th>Vendor</th>
                  <th>Invoice</th>
                  <th>Amount</th>
                </tr>
              </thead>
              <tbody>
                {EXPENSES.map((e) => (
                  <tr key={e.id}>
                    <td className="text-sm text-slate-500">{formatDate(e.date, "dd MMM yyyy")}</td>
                    <td>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-full"
                        style={{ color: EXPENSE_CAT_COLORS[e.category] || "#6B7280", background: (EXPENSE_CAT_COLORS[e.category] || "#6B7280") + "18" }}>
                        {e.category}
                      </span>
                    </td>
                    <td className="font-medium text-sm text-navy-950">{e.description}</td>
                    <td className="text-sm text-slate-500">{e.vendor}</td>
                    <td className="font-mono text-xs text-slate-400">{e.invoice}</td>
                    <td className="font-bold text-red-700">{formatCurrency(e.amount)}</td>
                  </tr>
                ))}
              </tbody>
              <tfoot>
                <tr className="bg-slate-50">
                  <td colSpan={5} className="px-4 py-3 text-sm font-bold text-navy-950">Total</td>
                  <td className="px-4 py-3 font-bold text-red-700 text-base">
                    {formatCurrency(EXPENSES.reduce((s, e) => s + e.amount, 0))}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* PAYMENTS DUE TAB */}
      {activeTab === "payments" && (
        <div className="space-y-4">
          {PENDING_PAYMENTS.filter(p => p.overdue).length > 0 && (
            <div className="alert-danger">
              <TrendingDown className="w-4 h-4 flex-shrink-0 mt-0.5" />
              <div>
                <p className="font-semibold text-sm">Overdue Payments</p>
                <p className="text-sm">{PENDING_PAYMENTS.filter(p => p.overdue).map(p => p.partner).join(", ")} — immediate follow-up required</p>
              </div>
            </div>
          )}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {PENDING_PAYMENTS.map((p) => (
              <div key={p.partner} className={`premium-card p-5 ${p.overdue ? "border-red-200 bg-red-50/30" : ""}`}>
                <div className="flex items-center justify-between mb-3">
                  <p className="font-bold text-navy-950">{p.partner}</p>
                  <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${p.overdue ? "bg-red-100 text-red-700" : "bg-amber-100 text-amber-700"}`}>
                    {p.overdue ? "OVERDUE" : "Due Soon"}
                  </span>
                </div>
                <p className="text-2xl font-display font-bold mb-1" style={{ color: p.overdue ? "#DC2626" : "#D97706" }}>
                  {formatCurrency(p.amount)}
                </p>
                <p className="text-xs text-slate-400">{p.orders} order{p.orders !== 1 ? "s" : ""} · Due: {formatDate(p.dueDate)}</p>
                <div className="flex gap-2 mt-4">
                  <button className="flex-1 py-2 rounded-lg bg-navy-950 text-white text-xs font-medium hover:bg-navy-900 transition-colors">
                    Record Payment
                  </button>
                  <button className="flex-1 py-2 rounded-lg border border-slate-200 text-slate-600 text-xs font-medium hover:bg-slate-50 transition-colors">
                    Send Reminder
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Add Expense Modal */}
      {showAddExpense && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setShowAddExpense(false)}>
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="p-6 border-b border-slate-100">
              <h2 className="text-lg font-display font-bold text-navy-950">Add Expense</h2>
              <p className="text-sm text-slate-400 mt-1">Record a new business expense</p>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="form-group">
                  <label className="form-label">Category</label>
                  <select className="form-input">
                    <option>Purchase</option><option>Packaging</option><option>Courier</option>
                    <option>Ads</option><option>Salary</option><option>Rent</option>
                    <option>Lab Testing</option><option>Misc</option>
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Amount (₹)</label>
                  <input type="number" className="form-input" placeholder="0.00" />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Description</label>
                <input type="text" className="form-input" placeholder="Expense description" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="form-group">
                  <label className="form-label">Vendor</label>
                  <input type="text" className="form-input" placeholder="Vendor name" />
                </div>
                <div className="form-group">
                  <label className="form-label">Date</label>
                  <input type="date" className="form-input" defaultValue={new Date().toISOString().split("T")[0]} />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="form-group">
                  <label className="form-label">Invoice Number</label>
                  <input type="text" className="form-input" placeholder="INV-XXXX" />
                </div>
                <div className="form-group">
                  <label className="form-label">GST Amount (₹)</label>
                  <input type="number" className="form-input" placeholder="0.00" />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Upload Receipt (Optional)</label>
                <div className="border-2 border-dashed border-slate-200 rounded-xl p-4 text-center cursor-pointer hover:border-blue-300 hover:bg-blue-50 transition-all">
                  <FileText className="w-5 h-5 text-slate-300 mx-auto mb-1" />
                  <p className="text-xs text-slate-400">Click to attach receipt or invoice</p>
                </div>
              </div>
            </div>
            <div className="p-6 pt-0 flex gap-3">
              <button onClick={() => setShowAddExpense(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50">Cancel</button>
              <button className="flex-1 btn-gold justify-center py-2.5">Save Expense</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
