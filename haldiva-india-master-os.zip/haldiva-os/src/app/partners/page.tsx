"use client";

import { useState } from "react";
import {
  Truck, Store, Package, IndianRupee, ShoppingCart,
  Phone, Mail, MapPin, Clock, CheckCircle, AlertCircle,
  RefreshCw, Plus, Eye, Download
} from "lucide-react";
import { formatCurrency, formatDate } from "@/lib/utils";

const PARTNERS = [
  {
    id: "p1", type: "distributor", company: "S.S. Enterprises", contactPerson: "Mr. Sudeep Dubey",
    secondaryContact: "Mr. Awdhesh Tripathi", phone: "9876543210", email: "dist@sse.com",
    city: "Lucknow", state: "Uttar Pradesh", creditLimit: 500000, creditDays: 30,
    outstanding: 86450, totalOrders: 24, totalValue: 842600, isActive: true
  },
  {
    id: "p2", type: "reseller", company: "Nutrition Mantra 360", contactPerson: "Dt. Parul Tripathi",
    secondaryContact: "", phone: "9123456789", email: "reseller@nm360.com",
    city: "Delhi", state: "Delhi", creditLimit: 100000, creditDays: 15,
    outstanding: 18200, totalOrders: 12, totalValue: 156800, isActive: true
  },
];

const PARTNER_ORDERS = [
  { id: "ORD-2501", partnerID: "p1", product: "Phool Ras Honey", qty: 120, amount: 29880, status: "dispatched", date: "2025-04-10", tracking: "DTDC1234567890" },
  { id: "ORD-2502", partnerID: "p1", product: "A2 Gir Cow Heritage Ghee", qty: 50, amount: 19950, status: "processing", date: "2025-04-20", tracking: "" },
  { id: "ORD-2503", partnerID: "p1", product: "Royal Festive Gift Duo", qty: 25, amount: 40725, status: "pending", date: "2025-04-30", tracking: "" },
  { id: "ORD-2504", partnerID: "p2", product: "Haldi Doodh Masala", qty: 40, amount: 15400, status: "delivered", date: "2025-04-15", tracking: "DTDC9876543210" },
  { id: "ORD-2505", partnerID: "p2", product: "Daily Wellness Duo", qty: 15, amount: 9720, status: "dispatched", date: "2025-04-25", tracking: "DTDC5556667778" },
];

const STATUS_CFG: Record<string, { label: string; color: string; bg: string }> = {
  pending: { label: "Pending", color: "#D97706", bg: "#FEF3C7" },
  processing: { label: "Processing", color: "#7C3AED", bg: "#F5F3FF" },
  dispatched: { label: "Dispatched", color: "#1B5FD4", bg: "#EFF6FF" },
  delivered: { label: "Delivered", color: "#059669", bg: "#DCFCE7" },
  cancelled: { label: "Cancelled", color: "#DC2626", bg: "#FEE2E2" },
};

const CATALOG = [
  { sku: "HLD-H-001", name: "Phool Ras Honey 100% Pure Raw", mrp: 299, distPrice: 210, rslrPrice: 225, stock: 180 },
  { sku: "HLD-G-001", name: "A2 Gir Cow Heritage Ghee", mrp: 499, distPrice: 340, rslrPrice: 360, stock: 60 },
  { sku: "HLD-G-002", name: "Sahiwal Desi Ghee A2 Bilona", mrp: 899, distPrice: 630, rslrPrice: 665, stock: 35 },
  { sku: "HLD-S-001", name: "Turmeric Powder 100g", mrp: 449, distPrice: 290, rslrPrice: 310, stock: 150 },
  { sku: "HLD-CB-001", name: "Royal Festive Gift Duo", mrp: 1999, distPrice: 1350, rslrPrice: 1450, stock: 20 },
];

export default function PartnersPage() {
  const [activeTab, setActiveTab] = useState<"overview" | "orders" | "catalog" | "payments">("overview");
  const [selectedPartner, setSelectedPartner] = useState<string>("all");

  const filteredOrders = selectedPartner === "all"
    ? PARTNER_ORDERS
    : PARTNER_ORDERS.filter(o => o.partnerID === selectedPartner);

  return (
    <div className="p-6 space-y-5 max-w-[1400px] mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold text-navy-950">Partner Portal</h1>
          <p className="text-slate-400 text-sm mt-1">
            {PARTNERS.length} active partners · {PARTNER_ORDERS.filter(o => o.status === "pending").length} pending orders
          </p>
        </div>
        <button className="btn-gold text-xs py-2"><Plus className="w-3.5 h-3.5" /> Add Partner</button>
      </div>

      {/* Partner Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
        {PARTNERS.map((partner) => {
          const partnerOrders = PARTNER_ORDERS.filter(o => o.partnerID === partner.id);
          const pendingAmt = partnerOrders.filter(o => o.status === "pending" || o.status === "processing").reduce((s, o) => s + o.amount, 0);
          const usedCredit = (partner.outstanding / partner.creditLimit) * 100;

          return (
            <div key={partner.id} className="premium-card overflow-hidden">
              {/* Card header */}
              <div className="p-5 border-b border-slate-100 flex items-start gap-4">
                <div className="w-12 h-12 rounded-xl flex items-center justify-center flex-shrink-0 text-white font-bold text-lg"
                  style={{ background: partner.type === "distributor" ? "#0A1628" : "#7C3AED" }}>
                  {partner.type === "distributor" ? <Truck className="w-6 h-6" /> : <Store className="w-6 h-6" />}
                </div>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-2">
                    <h3 className="font-bold text-navy-950">{partner.company}</h3>
                    <span className="text-xs px-2 py-0.5 rounded-full font-semibold capitalize"
                      style={{ background: partner.type === "distributor" ? "#EFF6FF" : "#F5F3FF", color: partner.type === "distributor" ? "#1B5FD4" : "#7C3AED" }}>
                      {partner.type}
                    </span>
                  </div>
                  <p className="text-sm text-slate-600 mt-0.5">{partner.contactPerson}</p>
                  {partner.secondaryContact && (
                    <p className="text-xs text-slate-400">{partner.secondaryContact}</p>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse" />
                  <span className="text-xs text-slate-400">Active</span>
                </div>
              </div>

              {/* Contact */}
              <div className="px-5 py-3 bg-slate-50 flex flex-wrap gap-4 text-xs text-slate-500">
                <div className="flex items-center gap-1.5"><Phone className="w-3.5 h-3.5" />{partner.phone}</div>
                <div className="flex items-center gap-1.5"><Mail className="w-3.5 h-3.5" />{partner.email}</div>
                <div className="flex items-center gap-1.5"><MapPin className="w-3.5 h-3.5" />{partner.city}, {partner.state}</div>
              </div>

              {/* Metrics */}
              <div className="p-5 grid grid-cols-3 gap-4">
                <div className="text-center">
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider mb-1">Total Orders</p>
                  <p className="text-xl font-display font-bold text-navy-950">{partner.totalOrders}</p>
                </div>
                <div className="text-center border-x border-slate-100">
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider mb-1">Total Value</p>
                  <p className="text-lg font-display font-bold text-green-700">{formatCurrency(partner.totalValue)}</p>
                </div>
                <div className="text-center">
                  <p className="text-[10px] text-slate-400 uppercase tracking-wider mb-1">Outstanding</p>
                  <p className="text-lg font-display font-bold text-amber-700">{formatCurrency(partner.outstanding)}</p>
                </div>
              </div>

              {/* Credit */}
              <div className="px-5 pb-5">
                <div className="flex justify-between text-xs mb-1.5">
                  <span className="text-slate-400">Credit Utilization</span>
                  <span className="font-semibold text-slate-600">
                    {formatCurrency(partner.outstanding)} / {formatCurrency(partner.creditLimit)}
                  </span>
                </div>
                <div className="h-2 bg-slate-100 rounded-full overflow-hidden">
                  <div className="h-full rounded-full transition-all duration-500"
                    style={{
                      width: `${Math.min(usedCredit, 100)}%`,
                      background: usedCredit > 80 ? "#DC2626" : usedCredit > 60 ? "#D97706" : "#059669"
                    }} />
                </div>
                <div className="flex items-center justify-between mt-2">
                  <span className="text-xs text-slate-400">{partner.creditDays} days credit</span>
                  <span className="text-xs font-semibold" style={{ color: usedCredit > 80 ? "#DC2626" : "#059669" }}>
                    {Math.round(usedCredit)}% used
                  </span>
                </div>
              </div>

              {/* Actions */}
              <div className="px-5 pb-5 flex gap-2">
                <button onClick={() => { setSelectedPartner(partner.id); setActiveTab("orders"); }}
                  className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg bg-navy-950 text-white text-xs font-medium hover:bg-navy-900 transition-colors">
                  <Eye className="w-3.5 h-3.5" /> View Orders
                </button>
                <button className="flex-1 flex items-center justify-center gap-1.5 py-2 rounded-lg border border-slate-200 text-slate-600 text-xs font-medium hover:bg-slate-50 transition-colors">
                  <ShoppingCart className="w-3.5 h-3.5" /> New Order
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-slate-100 rounded-xl w-fit">
        {[
          { key: "orders", label: "Orders" },
          { key: "catalog", label: "Product Catalog" },
          { key: "payments", label: "Payments" },
        ].map(({ key, label }) => (
          <button key={key} onClick={() => setActiveTab(key as typeof activeTab)}
            className={`px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === key ? "bg-white text-navy-950 shadow-sm" : "text-slate-500 hover:text-slate-700"
            }`}>
            {label}
          </button>
        ))}
      </div>

      {/* Orders Tab */}
      {activeTab === "orders" && (
        <div className="premium-card">
          <div className="p-4 border-b border-slate-100 flex items-center gap-3">
            <select value={selectedPartner} onChange={e => setSelectedPartner(e.target.value)}
              className="form-input w-auto py-2 text-sm">
              <option value="all">All Partners</option>
              {PARTNERS.map(p => <option key={p.id} value={p.id}>{p.company}</option>)}
            </select>
            <span className="text-sm text-slate-400">{filteredOrders.length} orders</span>
            <button className="ml-auto flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 text-xs font-medium text-slate-600">
              <Download className="w-3.5 h-3.5" /> Export
            </button>
          </div>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr><th>Order ID</th><th>Partner</th><th>Product</th><th>Qty</th><th>Amount</th><th>Status</th><th>Date</th><th>Tracking</th></tr>
              </thead>
              <tbody>
                {filteredOrders.map((o) => {
                  const partner = PARTNERS.find(p => p.id === o.partnerID);
                  const sc = STATUS_CFG[o.status];
                  return (
                    <tr key={o.id}>
                      <td className="font-mono text-xs text-slate-500">{o.id}</td>
                      <td className="font-medium text-sm">{partner?.company}</td>
                      <td>{o.product}</td>
                      <td>{o.qty}</td>
                      <td className="font-semibold">{formatCurrency(o.amount)}</td>
                      <td><span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ color: sc.color, background: sc.bg }}>{sc.label}</span></td>
                      <td className="text-sm text-slate-400">{formatDate(o.date)}</td>
                      <td>{o.tracking ? <span className="font-mono text-xs text-blue-600">{o.tracking}</span> : <span className="text-xs text-slate-300">—</span>}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Catalog Tab */}
      {activeTab === "catalog" && (
        <div className="premium-card">
          <div className="p-4 border-b border-slate-100">
            <h3 className="text-sm font-semibold text-navy-950">Product Catalog with Partner Pricing</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr><th>SKU</th><th>Product</th><th>MRP</th><th>Distributor Price</th><th>Reseller Price</th><th>Stock Available</th><th>Action</th></tr>
              </thead>
              <tbody>
                {CATALOG.map((p) => (
                  <tr key={p.sku}>
                    <td className="font-mono text-xs text-slate-400">{p.sku}</td>
                    <td className="font-semibold text-sm">{p.name}</td>
                    <td>{formatCurrency(p.mrp)}</td>
                    <td className="text-green-700 font-semibold">{formatCurrency(p.distPrice)}</td>
                    <td className="text-blue-700 font-semibold">{formatCurrency(p.rslrPrice)}</td>
                    <td>
                      <span className={`text-xs font-bold ${p.stock < 30 ? "text-red-600" : "text-green-700"}`}>
                        {p.stock} units
                      </span>
                    </td>
                    <td>
                      <button className="text-xs px-3 py-1 rounded-lg bg-navy-950 text-white hover:bg-navy-900 transition-colors font-medium">
                        Order
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}
