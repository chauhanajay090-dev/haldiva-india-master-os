"use client";

import { useState } from "react";
import {
  Search, Share2, Target, Plus, TrendingUp, TrendingDown,
  Minus, Calendar, Eye, ThumbsUp, MessageCircle, Users,
  ArrowUpRight, Globe, Instagram, Linkedin, Youtube
} from "lucide-react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  ResponsiveContainer, LineChart, Line, Legend
} from "recharts";
import { formatCurrency, formatDate } from "@/lib/utils";

const SEO_KEYWORDS = [
  { id: "k1", keyword: "pure raw honey India buy online", rank: 4, prevRank: 7, volume: 18000, difficulty: "Medium", url: "/products/honey", status: "improving" },
  { id: "k2", keyword: "haldiva india", rank: 1, prevRank: 1, volume: 2100, difficulty: "Low", url: "/", status: "achieved" },
  { id: "k3", keyword: "a2 gir cow ghee online", rank: 6, prevRank: 10, volume: 28000, difficulty: "High", url: "/products/ghee", status: "improving" },
  { id: "k4", keyword: "ashwagandha honey benefits", rank: 3, prevRank: 5, volume: 9400, difficulty: "Medium", url: "/products/honey", status: "improving" },
  { id: "k5", keyword: "haldi doodh masala powder", rank: 2, prevRank: 3, volume: 6800, difficulty: "Low", url: "/products/spices", status: "achieved" },
  { id: "k6", keyword: "cold pressed mustard oil buy", rank: 9, prevRank: 14, volume: 34000, difficulty: "High", url: "/products/oils", status: "improving" },
  { id: "k7", keyword: "shilajit honey online India", rank: 5, prevRank: 8, volume: 7200, difficulty: "Medium", url: "/products/honey", status: "improving" },
  { id: "k8", keyword: "bilona ghee sahiwal cow", rank: 2, prevRank: 4, volume: 4500, difficulty: "Low", url: "/products/ghee", status: "achieved" },
  { id: "k9", keyword: "buy organic honey delhi ncr", rank: 12, prevRank: 18, volume: 8900, difficulty: "Medium", url: "/products/honey", status: "improving" },
  { id: "k10", keyword: "makhana snacks online", rank: 14, prevRank: 20, volume: 22000, difficulty: "High", url: "/products/snacks", status: "improving" },
];

const SOCIAL_POSTS = [
  { id: "p1", platform: "instagram", caption: "🍯 Our Shilajit Honey is nature's power blend — pure honey + authentic shilajit for strength, stamina & immunity. Now available online!", hashtags: "#HaldivIndia #ShilajitHoney #OrganicHoney #PowerBlend #HealthyLiving", date: "2025-05-01", status: "published", reach: 4800, likes: 312, comments: 28, shares: 45, leads: 12 },
  { id: "p2", platform: "instagram", caption: "🥛 Start your mornings golden! Our Haldi Doodh Masala — packed with turmeric, black pepper, ginger & cardamom for a powerful start.", hashtags: "#HaldiMilk #TurmericMilk #GoldenMilk #HaldivIndia", date: "2025-05-03", status: "published", reach: 3200, likes: 248, comments: 19, shares: 32, leads: 8 },
  { id: "p3", platform: "linkedin", caption: "HALDIVA INDIA — bridging the gap between traditional wisdom and modern wellness. Our A2 Gir Cow Ghee is made using ancient Bilona method from grass-fed Gir cows.", hashtags: "#A2Ghee #BilonGhee #OrganicBusiness #WellnessIndia", date: "2025-05-02", status: "published", reach: 1800, likes: 94, comments: 11, shares: 28, leads: 5 },
  { id: "p4", platform: "instagram", caption: "✨ New Drop: Royal Festive Gift Duo — Honey + Ghee in premium packaging. Perfect for gifting, wellness, and celebrating health-conscious loved ones!", hashtags: "#HaldivGifts #FestiveGifting #PremiumOrganic", date: "2025-05-06", status: "scheduled", reach: 0, likes: 0, comments: 0, shares: 0, leads: 0 },
  { id: "p5", platform: "instagram", caption: "Behind the scenes: How our A2 Bilona Ghee is made using the traditional wooden churner — handcrafted, slow, sacred.", hashtags: "#BehindTheScenes #BilonProcess #TraditionalGhee #HaldivIndia", date: "2025-05-08", status: "draft", reach: 0, likes: 0, comments: 0, shares: 0, leads: 0 },
];

const CAMPAIGNS = [
  { id: "c1", name: "Honey Summer Campaign", platform: "Meta (FB+IG)", budget: 5000, spend: 4200, leads: 84, sales: 18400, roi: 338, status: "active" },
  { id: "c2", name: "Ghee Brand Awareness", platform: "Google Ads", budget: 3000, spend: 2800, leads: 42, sales: 11600, roi: 314, status: "active" },
  { id: "c3", name: "Diwali Gift Hampers", platform: "Meta (FB+IG)", budget: 8000, spend: 8000, leads: 210, sales: 68400, roi: 755, status: "completed" },
  { id: "c4", name: "Amazon PPC — Honey", platform: "Amazon Ads", budget: 2000, spend: 1640, leads: 0, sales: 9200, roi: 461, status: "active" },
];

const PLATFORM_ICONS: Record<string, React.ElementType> = {
  instagram: Instagram,
  linkedin: Linkedin,
  youtube: Youtube,
  facebook: Globe,
  twitter: Globe,
};

const PLATFORM_COLORS: Record<string, string> = {
  instagram: "#E1306C",
  linkedin: "#0077B5",
  youtube: "#FF0000",
  facebook: "#1877F2",
  twitter: "#1DA1F2",
};

const RANK_TREND_DATA = [
  { week: "W1", avgRank: 8.2 },
  { week: "W2", avgRank: 7.6 },
  { week: "W3", avgRank: 6.8 },
  { week: "W4", avgRank: 5.9 },
  { week: "W5", avgRank: 5.2 },
  { week: "W6", avgRank: 4.8 },
  { week: "W7", avgRank: 4.3 },
];

export default function MarketingPage() {
  const [activeTab, setActiveTab] = useState<"seo" | "social" | "campaigns" | "website">("seo");

  const page1Keywords = SEO_KEYWORDS.filter((k) => k.rank <= 10).length;
  const top3Keywords = SEO_KEYWORDS.filter((k) => k.rank <= 3).length;
  const totalReach = SOCIAL_POSTS.filter((p) => p.status === "published").reduce((s, p) => s + p.reach, 0);
  const totalLeads = SOCIAL_POSTS.reduce((s, p) => s + p.leads, 0) + CAMPAIGNS.reduce((s, c) => s + c.leads, 0);
  const totalAdROI = CAMPAIGNS.filter(c => c.status === "active").reduce((s, c) => s + c.roi, 0) / CAMPAIGNS.filter(c => c.status === "active").length;

  return (
    <div className="p-6 space-y-5 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold text-navy-950">Marketing & Growth</h1>
          <p className="text-slate-400 text-sm mt-1">
            SEO · Social Media · Campaigns · Website Performance
          </p>
        </div>
        <button className="btn-gold text-xs py-2"><Plus className="w-3.5 h-3.5" /> Schedule Post</button>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Page 1 Keywords", value: page1Keywords, sub: `${top3Keywords} in top 3`, color: "#059669", bg: "#DCFCE7" },
          { label: "Social Reach", value: `${(totalReach / 1000).toFixed(1)}K`, sub: "This month", color: "#E1306C", bg: "#FDF2F8" },
          { label: "Total Leads", value: totalLeads, sub: "Organic + Paid", color: "#1B5FD4", bg: "#EFF6FF" },
          { label: "Avg Ad ROI", value: `${Math.round(totalAdROI)}%`, sub: "Active campaigns", color: "#D97706", bg: "#FEF3C7" },
        ].map((m) => (
          <div key={m.label} className="stat-card">
            <p className="stat-label">{m.label}</p>
            <p className="stat-value text-xl" style={{ color: m.color }}>{m.value}</p>
            <p className="stat-meta">{m.sub}</p>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-slate-100 rounded-xl w-fit">
        {[
          { key: "seo", label: "SEO Tracker", icon: Search },
          { key: "social", label: "Social Media", icon: Share2 },
          { key: "campaigns", label: "Campaigns", icon: Target },
        ].map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => setActiveTab(key as typeof activeTab)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === key ? "bg-white text-navy-950 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
            <Icon className="w-4 h-4" />{label}
          </button>
        ))}
      </div>

      {/* SEO TAB */}
      {activeTab === "seo" && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            <div className="premium-card p-5 lg:col-span-2">
              <div className="section-header">
                <div>
                  <h3 className="section-title">Keyword Rankings</h3>
                  <p className="section-sub">{SEO_KEYWORDS.length} keywords tracked</p>
                </div>
                <button className="btn-navy text-xs py-2"><Plus className="w-3.5 h-3.5" /> Add Keyword</button>
              </div>
              <div className="space-y-1">
                {SEO_KEYWORDS.map((kw) => {
                  const change = kw.prevRank - kw.rank;
                  const rankColor = kw.rank <= 3 ? "#059669" : kw.rank <= 7 ? "#D97706" : "#DC2626";
                  const rankBg = kw.rank <= 3 ? "#DCFCE7" : kw.rank <= 7 ? "#FEF3C7" : "#FEE2E2";
                  return (
                    <div key={kw.id} className="flex items-center gap-3 p-3 rounded-xl hover:bg-slate-50 transition-colors">
                      <div className="w-10 h-10 rounded-xl flex items-center justify-center font-display font-bold text-lg flex-shrink-0"
                        style={{ color: rankColor, background: rankBg }}>
                        #{kw.rank}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-semibold text-navy-950 truncate">{kw.keyword}</p>
                        <div className="flex items-center gap-3 mt-0.5">
                          <span className="text-xs text-slate-400">{kw.volume.toLocaleString("en-IN")}/mo</span>
                          <span className={`text-xs px-1.5 py-0.5 rounded-full font-medium ${kw.difficulty === "Low" ? "bg-green-100 text-green-700" : kw.difficulty === "Medium" ? "bg-amber-100 text-amber-700" : "bg-red-100 text-red-700"}`}>
                            {kw.difficulty}
                          </span>
                          <span className="text-xs text-blue-500 truncate">{kw.url}</span>
                        </div>
                      </div>
                      <div className="flex items-center gap-1 flex-shrink-0">
                        {change > 0 ? (
                          <span className="flex items-center gap-1 text-xs font-bold text-green-600 bg-green-50 px-2 py-0.5 rounded-full">
                            <TrendingUp className="w-3 h-3" />↑{change}
                          </span>
                        ) : change < 0 ? (
                          <span className="flex items-center gap-1 text-xs font-bold text-red-600 bg-red-50 px-2 py-0.5 rounded-full">
                            <TrendingDown className="w-3 h-3" />↓{Math.abs(change)}
                          </span>
                        ) : (
                          <span className="text-xs text-slate-400 bg-slate-100 px-2 py-0.5 rounded-full">—</span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="space-y-5">
              <div className="premium-card p-5">
                <h3 className="section-title mb-4">Ranking Trend</h3>
                <ResponsiveContainer width="100%" height={150}>
                  <LineChart data={RANK_TREND_DATA}>
                    <XAxis dataKey="week" tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} />
                    <YAxis reversed tick={{ fontSize: 10, fill: "#94a3b8" }} axisLine={false} tickLine={false} domain={[1, 12]} />
                    <Tooltip formatter={(v: number) => [`Avg Rank #${v}`, ""]} contentStyle={{ borderRadius: 8, fontSize: 11 }} />
                    <Line type="monotone" dataKey="avgRank" stroke="#1B5FD4" strokeWidth={2.5} dot={{ r: 3, fill: "#1B5FD4" }} />
                  </LineChart>
                </ResponsiveContainer>
                <p className="text-xs text-center text-slate-400 mt-2">Average rank improving week over week ✓</p>
              </div>

              <div className="premium-card p-5">
                <h3 className="section-title mb-3">Distribution</h3>
                {[
                  { label: "Top 3 (Position 1-3)", count: top3Keywords, color: "#059669" },
                  { label: "Page 1 (Position 4-10)", count: SEO_KEYWORDS.filter(k => k.rank > 3 && k.rank <= 10).length, color: "#1B5FD4" },
                  { label: "Page 2+ (11+)", count: SEO_KEYWORDS.filter(k => k.rank > 10).length, color: "#D97706" },
                ].map((d) => (
                  <div key={d.label} className="flex items-center justify-between py-2.5 border-b border-slate-50 last:border-0">
                    <div className="flex items-center gap-2">
                      <div className="w-2.5 h-2.5 rounded-full" style={{ background: d.color }} />
                      <span className="text-xs text-slate-600">{d.label}</span>
                    </div>
                    <span className="text-sm font-bold" style={{ color: d.color }}>{d.count}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* SOCIAL TAB */}
      {activeTab === "social" && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-5">
            {/* Posts List */}
            <div className="premium-card lg:col-span-2">
              <div className="p-5 border-b border-slate-100 flex items-center justify-between">
                <div>
                  <h3 className="section-title">Content Calendar</h3>
                  <p className="section-sub">{SOCIAL_POSTS.filter(p => p.status === "published").length} published · {SOCIAL_POSTS.filter(p => p.status === "scheduled").length} scheduled</p>
                </div>
                <button className="btn-gold text-xs py-2"><Plus className="w-3.5 h-3.5" /> New Post</button>
              </div>
              <div className="divide-y divide-slate-50">
                {SOCIAL_POSTS.map((post) => {
                  const PlatformIcon = PLATFORM_ICONS[post.platform] || Globe;
                  const platformColor = PLATFORM_COLORS[post.platform] || "#6B7280";
                  return (
                    <div key={post.id} className="p-5 hover:bg-slate-50/50 transition-colors">
                      <div className="flex items-start gap-3">
                        <div className="w-9 h-9 rounded-xl flex items-center justify-center flex-shrink-0"
                          style={{ background: platformColor + "15" }}>
                          <PlatformIcon className="w-4.5 h-4.5" style={{ color: platformColor }} />
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <span className="text-xs font-semibold capitalize" style={{ color: platformColor }}>
                              {post.platform}
                            </span>
                            <span className="text-xs text-slate-400">{formatDate(post.date, "dd MMM yyyy")}</span>
                            <span className={`ml-auto text-xs font-semibold px-2 py-0.5 rounded-full ${
                              post.status === "published" ? "bg-green-100 text-green-700" :
                              post.status === "scheduled" ? "bg-blue-100 text-blue-700" :
                              "bg-slate-100 text-slate-500"}`}>
                              {post.status.charAt(0).toUpperCase() + post.status.slice(1)}
                            </span>
                          </div>
                          <p className="text-sm text-slate-700 leading-relaxed line-clamp-2">{post.caption}</p>
                          {post.status === "published" && (
                            <div className="flex items-center gap-4 mt-2">
                              {[
                                { icon: Eye, value: post.reach, label: "reach" },
                                { icon: ThumbsUp, value: post.likes, label: "likes" },
                                { icon: MessageCircle, value: post.comments, label: "comments" },
                                { icon: Users, value: post.leads, label: "leads" },
                              ].map(({ icon: Icon, value, label }) => (
                                <div key={label} className="flex items-center gap-1 text-xs text-slate-400">
                                  <Icon className="w-3 h-3" />
                                  <span className="font-semibold text-slate-600">{value.toLocaleString()}</span>
                                </div>
                              ))}
                            </div>
                          )}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Platform Stats */}
            <div className="space-y-4">
              {["instagram", "linkedin"].map((platform) => {
                const posts = SOCIAL_POSTS.filter((p) => p.platform === platform && p.status === "published");
                const totalReach = posts.reduce((s, p) => s + p.reach, 0);
                const totalLikes = posts.reduce((s, p) => s + p.likes, 0);
                const PlatformIcon = PLATFORM_ICONS[platform] || Globe;
                const color = PLATFORM_COLORS[platform];
                return (
                  <div key={platform} className="premium-card p-5">
                    <div className="flex items-center gap-2 mb-3">
                      <PlatformIcon className="w-5 h-5" style={{ color }} />
                      <h3 className="font-semibold capitalize text-navy-950">{platform}</h3>
                    </div>
                    <div className="grid grid-cols-2 gap-3">
                      <div className="p-2.5 rounded-lg bg-slate-50 text-center">
                        <p className="text-lg font-display font-bold" style={{ color }}>{totalReach.toLocaleString()}</p>
                        <p className="text-[10px] text-slate-400 uppercase tracking-wider">Reach</p>
                      </div>
                      <div className="p-2.5 rounded-lg bg-slate-50 text-center">
                        <p className="text-lg font-display font-bold text-navy-950">{totalLikes}</p>
                        <p className="text-[10px] text-slate-400 uppercase tracking-wider">Likes</p>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      )}

      {/* CAMPAIGNS TAB */}
      {activeTab === "campaigns" && (
        <div className="space-y-5">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {CAMPAIGNS.map((c) => (
              <div key={c.id} className="premium-card p-5">
                <div className="flex items-start justify-between mb-3">
                  <p className="font-semibold text-sm text-navy-950 leading-tight">{c.name}</p>
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full flex-shrink-0 ml-1 ${c.status === "active" ? "bg-green-100 text-green-700" : "bg-slate-100 text-slate-500"}`}>
                    {c.status.toUpperCase()}
                  </span>
                </div>
                <p className="text-xs text-slate-400 mb-3">{c.platform}</p>

                <div className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Budget</span>
                    <span className="font-semibold">{formatCurrency(c.budget)}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Spent</span>
                    <span className="font-semibold text-red-600">{formatCurrency(c.spend)}</span>
                  </div>
                  <div className="h-1.5 bg-slate-100 rounded-full overflow-hidden">
                    <div className="h-full rounded-full bg-gradient-to-r from-blue-500 to-blue-400"
                      style={{ width: `${Math.round((c.spend / c.budget) * 100)}%` }} />
                  </div>
                  {c.leads > 0 && <div className="flex justify-between"><span className="text-slate-400">Leads</span><span className="font-semibold text-purple-600">{c.leads}</span></div>}
                  <div className="flex justify-between"><span className="text-slate-400">Sales</span><span className="font-semibold text-green-700">{formatCurrency(c.sales)}</span></div>
                  <div className="pt-2 border-t border-slate-100 flex justify-between">
                    <span className="text-slate-400 font-semibold">ROI</span>
                    <span className="font-bold text-green-700 text-base">{c.roi}%</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
