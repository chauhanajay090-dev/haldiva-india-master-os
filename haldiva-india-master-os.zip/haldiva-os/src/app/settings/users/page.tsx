"use client";

import { useState } from "react";
import {
  UserCog, Shield, Plus, Edit2, Trash2, Lock, Unlock,
  Eye, EyeOff, CheckCircle, XCircle, Key, Activity,
  Users, Clock, AlertCircle
} from "lucide-react";
import { formatDate, ROLE_LABELS } from "@/lib/rbac";
import type { UserRole } from "@/types";

// Local formatDate for this page
function fmtDate(d: string) {
  return new Date(d).toLocaleDateString("en-IN", { day: "numeric", month: "short", year: "numeric" });
}

const ROLE_LABEL_MAP: Record<UserRole, { label: string; color: string; bg: string }> = {
  ceo: { label: "CEO / Founder", color: "#C9A84C", bg: "#FFFBEB" },
  senior_executive: { label: "Senior Executive", color: "#1B5FD4", bg: "#EFF6FF" },
  data_executive: { label: "Data Executive", color: "#059669", bg: "#DCFCE7" },
  digital_marketing: { label: "Digital Marketing Lead", color: "#7C3AED", bg: "#F5F3FF" },
  marketplace_agency: { label: "Marketplace Agency", color: "#D97706", bg: "#FEF3C7" },
  distributor: { label: "Distributor", color: "#BE185D", bg: "#FDF2F8" },
  reseller: { label: "Reseller", color: "#0891B2", bg: "#CFFAFE" },
};

const MODULE_ACCESS: Record<UserRole, string[]> = {
  ceo: ["Dashboard", "Inventory", "Orders", "Finance", "HR", "Marketing", "Partners", "Documents", "Reports", "Settings", "Users"],
  senior_executive: ["Dashboard", "Inventory", "Orders", "HR", "Documents", "Reports"],
  data_executive: ["Dashboard", "Inventory", "Orders", "Documents", "Reports"],
  digital_marketing: ["Dashboard", "Marketing", "SEO", "Social Media", "Reports"],
  marketplace_agency: ["Marketplace", "Inventory (View)", "Orders (View)", "Reports (Limited)"],
  distributor: ["Partner Portal", "My Orders", "Inventory (View)", "My Documents"],
  reseller: ["Partner Portal", "My Orders", "Product Catalog"],
};

const USERS = [
  { id: "u1", name: "Vikram Sharma", email: "ceo@haldiva.com", role: "ceo" as UserRole, department: "Executive", isActive: true, twoFa: true, lastLogin: "2025-05-04T09:12:00", createdAt: "2024-10-01" },
  { id: "u2", name: "Mrs. Kriti Gupta", email: "kriti@haldiva.com", role: "senior_executive" as UserRole, department: "Office Operations", isActive: true, twoFa: false, lastLogin: "2025-05-04T09:45:00", createdAt: "2024-11-15" },
  { id: "u3", name: "Mr. Deepender Jaiswal", email: "deepender@haldiva.com", role: "data_executive" as UserRole, department: "Data & Support", isActive: true, twoFa: false, lastLogin: "2025-05-03T17:30:00", createdAt: "2024-12-01" },
  { id: "u4", name: "Mr. Sayan", email: "sayan@haldiva.com", role: "digital_marketing" as UserRole, department: "Digital Marketing", isActive: true, twoFa: false, lastLogin: "2025-05-04T10:02:00", createdAt: "2024-12-10" },
  { id: "u5", name: "Marketplace Agency", email: "agency@haldiva.com", role: "marketplace_agency" as UserRole, department: "E-Commerce", isActive: true, twoFa: false, lastLogin: "2025-05-02T14:00:00", createdAt: "2025-01-15" },
  { id: "u6", name: "Mr. Sudeep Dubey", email: "dist@sse.com", role: "distributor" as UserRole, department: "S.S. Enterprises", isActive: true, twoFa: false, lastLogin: "2025-04-30T11:20:00", createdAt: "2025-01-20" },
  { id: "u7", name: "Dt. Parul Tripathi", email: "reseller@nm360.com", role: "reseller" as UserRole, department: "Nutrition Mantra 360", isActive: true, twoFa: false, lastLogin: "2025-04-28T16:15:00", createdAt: "2025-02-01" },
];

const ACTIVITY_LOGS = [
  { user: "Vikram Sharma", action: "Updated inventory — HLD-H-001 stock adjusted", time: "2025-05-04T09:30:00", type: "inventory" },
  { user: "Mrs. Kriti Gupta", action: "Marked attendance — checked in at 09:45", time: "2025-05-04T09:45:00", type: "hr" },
  { user: "Mr. Sayan", action: "Scheduled Instagram post — Shilajit Honey campaign", time: "2025-05-04T10:15:00", type: "marketing" },
  { user: "Mr. Deepender", action: "Exported inventory report (CSV)", time: "2025-05-03T17:00:00", type: "reports" },
  { user: "Vikram Sharma", action: "Approved order ORD-2502 for S.S. Enterprises", time: "2025-05-04T11:00:00", type: "orders" },
  { user: "Sudeep Dubey", action: "Viewed order status — ORD-2501", time: "2025-05-03T14:20:00", type: "partners" },
];

const LOG_COLORS: Record<string, string> = {
  inventory: "#1B5FD4", hr: "#059669", marketing: "#7C3AED",
  reports: "#D97706", orders: "#BE185D", partners: "#0891B2",
};

export default function UsersPage() {
  const [activeTab, setActiveTab] = useState<"users" | "roles" | "logs" | "security">("users");
  const [showAddUser, setShowAddUser] = useState(false);
  const [selectedUser, setSelectedUser] = useState<typeof USERS[0] | null>(null);

  return (
    <div className="p-6 space-y-5 max-w-[1400px] mx-auto">
      {/* Header - CEO Only Banner */}
      <div className="p-4 rounded-xl border flex items-center gap-3"
        style={{ background: "rgba(201,168,76,0.08)", borderColor: "rgba(201,168,76,0.25)" }}>
        <Shield className="w-5 h-5 text-gold-500 flex-shrink-0" />
        <div>
          <p className="text-sm font-semibold text-navy-950">CEO Master Control — Restricted Access</p>
          <p className="text-xs text-slate-400">Only the CEO can manage users, roles, and system security. All actions are logged.</p>
        </div>
      </div>

      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold text-navy-950">User Management & Security</h1>
          <p className="text-slate-400 text-sm mt-1">{USERS.length} users · {USERS.filter(u => u.isActive).length} active · {USERS.filter(u => u.twoFa).length} with 2FA</p>
        </div>
        <button onClick={() => setShowAddUser(true)} className="btn-gold text-xs py-2">
          <Plus className="w-3.5 h-3.5" /> Add User
        </button>
      </div>

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-slate-100 rounded-xl w-fit">
        {[
          { key: "users", label: "Users", icon: Users },
          { key: "roles", label: "Role Matrix", icon: Shield },
          { key: "logs", label: "Audit Logs", icon: Activity },
          { key: "security", label: "Security", icon: Lock },
        ].map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => setActiveTab(key as typeof activeTab)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${activeTab === key ? "bg-white text-navy-950 shadow-sm" : "text-slate-500 hover:text-slate-700"}`}>
            <Icon className="w-4 h-4" />{label}
          </button>
        ))}
      </div>

      {/* USERS TAB */}
      {activeTab === "users" && (
        <div className="premium-card overflow-hidden">
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>User</th>
                  <th>Role</th>
                  <th>Department</th>
                  <th>Last Login</th>
                  <th>2FA</th>
                  <th>Status</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {USERS.map((user) => {
                  const roleCfg = ROLE_LABEL_MAP[user.role];
                  return (
                    <tr key={user.id}>
                      <td>
                        <div className="flex items-center gap-2.5">
                          <div className="w-8 h-8 rounded-lg flex items-center justify-center text-white font-bold text-xs flex-shrink-0"
                            style={{ background: roleCfg.color }}>
                            {user.name.split(" ").map(n => n[0]).join("").slice(0, 2)}
                          </div>
                          <div>
                            <p className="font-semibold text-sm text-navy-950">{user.name}</p>
                            <p className="text-xs text-slate-400">{user.email}</p>
                          </div>
                        </div>
                      </td>
                      <td>
                        <span className="text-xs font-semibold px-2 py-0.5 rounded-full"
                          style={{ color: roleCfg.color, background: roleCfg.bg }}>
                          {roleCfg.label}
                        </span>
                      </td>
                      <td className="text-sm text-slate-500">{user.department}</td>
                      <td className="text-xs text-slate-400">
                        {new Date(user.lastLogin).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}{" "}
                        {new Date(user.lastLogin).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                      </td>
                      <td>
                        {user.twoFa
                          ? <span className="flex items-center gap-1 text-xs text-green-700 font-semibold"><CheckCircle className="w-3.5 h-3.5" />Enabled</span>
                          : <span className="flex items-center gap-1 text-xs text-slate-400"><XCircle className="w-3.5 h-3.5" />Disabled</span>}
                      </td>
                      <td>
                        <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${user.isActive ? "bg-green-100 text-green-700" : "bg-red-100 text-red-700"}`}>
                          {user.isActive ? "Active" : "Suspended"}
                        </span>
                      </td>
                      <td>
                        <div className="flex items-center gap-1">
                          <button onClick={() => setSelectedUser(user)}
                            className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-blue-600 transition-colors" title="Edit">
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-amber-600 transition-colors" title="Reset Password">
                            <Key className="w-3.5 h-3.5" />
                          </button>
                          {user.role !== "ceo" && (
                            <button className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-400 hover:text-red-600 transition-colors" title="Suspend">
                              <Lock className="w-3.5 h-3.5" />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* ROLE MATRIX TAB */}
      {activeTab === "roles" && (
        <div className="space-y-4">
          <div className="alert-info">
            <Shield className="w-4 h-4 flex-shrink-0 mt-0.5" />
            <p className="text-sm">Role permissions are enforced at both UI level (hidden modules) and database level (Row Level Security). Only CEO can modify roles.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
            {Object.entries(ROLE_LABEL_MAP).map(([role, cfg]) => (
              <div key={role} className="premium-card p-5" style={{ borderLeft: `3px solid ${cfg.color}` }}>
                <div className="flex items-center gap-2 mb-3">
                  <div className="w-8 h-8 rounded-lg flex items-center justify-center" style={{ background: cfg.bg }}>
                    <Shield className="w-4 h-4" style={{ color: cfg.color }} />
                  </div>
                  <div>
                    <p className="font-bold text-sm text-navy-950">{cfg.label}</p>
                    <p className="text-[10px] text-slate-400">{USERS.filter(u => u.role === role).length} user(s)</p>
                  </div>
                </div>
                <div className="space-y-1">
                  {(MODULE_ACCESS[role as UserRole] || []).map((module) => (
                    <div key={module} className="flex items-center gap-2 text-xs text-slate-600">
                      <CheckCircle className="w-3 h-3 flex-shrink-0" style={{ color: cfg.color }} />
                      {module}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* AUDIT LOGS TAB */}
      {activeTab === "logs" && (
        <div className="premium-card overflow-hidden">
          <div className="p-4 border-b border-slate-100 flex items-center justify-between">
            <h3 className="text-sm font-semibold">System Audit Logs</h3>
            <span className="text-xs text-slate-400">{ACTIVITY_LOGS.length} recent entries</span>
          </div>
          <div className="divide-y divide-slate-50">
            {ACTIVITY_LOGS.map((log, i) => (
              <div key={i} className="flex items-center gap-4 p-4 hover:bg-slate-50/50 transition-colors">
                <div className="w-2 h-2 rounded-full flex-shrink-0" style={{ background: LOG_COLORS[log.type] || "#94a3b8" }} />
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-navy-950">{log.user}</p>
                  <p className="text-xs text-slate-500">{log.action}</p>
                </div>
                <div className="text-right flex-shrink-0">
                  <p className="text-xs text-slate-400">
                    {new Date(log.time).toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })}
                  </p>
                  <p className="text-[10px] text-slate-300">
                    {new Date(log.time).toLocaleDateString("en-IN", { day: "numeric", month: "short" })}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* SECURITY TAB */}
      {activeTab === "security" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
            {/* Security Settings */}
            <div className="premium-card p-5">
              <h3 className="section-title mb-4">Security Settings</h3>
              <div className="space-y-4">
                {[
                  { label: "CEO Two-Factor Authentication", enabled: true, desc: "OTP required for CEO login" },
                  { label: "Session Timeout (30 min)", enabled: true, desc: "Auto-logout after inactivity" },
                  { label: "Login Rate Limiting", enabled: true, desc: "5 attempts then 15-min lockout" },
                  { label: "Activity Audit Logging", enabled: true, desc: "All actions logged with timestamp" },
                  { label: "Row-Level Security (RLS)", enabled: true, desc: "Database-level access isolation" },
                  { label: "Device Session Tracking", enabled: false, desc: "Track login devices (coming soon)" },
                ].map((setting) => (
                  <div key={setting.label} className="flex items-center justify-between py-3 border-b border-slate-50 last:border-0">
                    <div>
                      <p className="text-sm font-semibold text-navy-950">{setting.label}</p>
                      <p className="text-xs text-slate-400">{setting.desc}</p>
                    </div>
                    <div className={`w-10 h-5 rounded-full relative cursor-pointer transition-colors duration-200 flex-shrink-0 ${setting.enabled ? "bg-green-500" : "bg-slate-300"}`}>
                      <div className={`w-4 h-4 rounded-full bg-white absolute top-0.5 transition-transform duration-200 ${setting.enabled ? "translate-x-5" : "translate-x-0.5"}`} />
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Password Policy */}
            <div className="premium-card p-5">
              <h3 className="section-title mb-4">Password Policy</h3>
              <div className="space-y-3">
                {[
                  { rule: "Minimum 8 characters", active: true },
                  { rule: "At least one uppercase letter", active: true },
                  { rule: "At least one number", active: true },
                  { rule: "At least one special character", active: true },
                  { rule: "No reuse of last 5 passwords", active: false },
                  { rule: "Force reset every 90 days", active: false },
                ].map((r) => (
                  <div key={r.rule} className="flex items-center gap-2">
                    {r.active
                      ? <CheckCircle className="w-4 h-4 text-green-500 flex-shrink-0" />
                      : <XCircle className="w-4 h-4 text-slate-300 flex-shrink-0" />}
                    <span className={`text-sm ${r.active ? "text-slate-700" : "text-slate-400"}`}>{r.rule}</span>
                  </div>
                ))}
              </div>

              <div className="mt-5 p-4 bg-amber-50 rounded-xl border border-amber-100">
                <p className="text-xs font-semibold text-amber-800 flex items-center gap-2 mb-1">
                  <AlertCircle className="w-3.5 h-3.5" /> Recommendation
                </p>
                <p className="text-xs text-amber-700">Enable 2FA for all team accounts and force password reset every 90 days for enhanced security.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Add User Modal */}
      {showAddUser && (
        <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4 backdrop-blur-sm" onClick={() => setShowAddUser(false)}>
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl animate-scale-in" onClick={(e) => e.stopPropagation()}>
            <div className="p-6 border-b border-slate-100">
              <h2 className="text-lg font-display font-bold text-navy-950">Add New User</h2>
              <p className="text-sm text-slate-400 mt-1">User will receive login credentials via email</p>
            </div>
            <div className="p-6 space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div className="form-group">
                  <label className="form-label">Full Name</label>
                  <input type="text" className="form-input" placeholder="Full name" />
                </div>
                <div className="form-group">
                  <label className="form-label">Email</label>
                  <input type="email" className="form-input" placeholder="user@haldiva.com" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="form-group">
                  <label className="form-label">Role</label>
                  <select className="form-input">
                    {Object.entries(ROLE_LABEL_MAP).filter(([role]) => role !== "ceo").map(([role, cfg]) => (
                      <option key={role} value={role}>{cfg.label}</option>
                    ))}
                  </select>
                </div>
                <div className="form-group">
                  <label className="form-label">Department</label>
                  <input type="text" className="form-input" placeholder="Department" />
                </div>
              </div>
              <div className="form-group">
                <label className="form-label">Temporary Password</label>
                <input type="text" className="form-input" placeholder="Auto-generated" />
              </div>
            </div>
            <div className="p-6 pt-0 flex gap-3">
              <button onClick={() => setShowAddUser(false)}
                className="flex-1 py-2.5 rounded-xl border border-slate-200 text-slate-600 text-sm font-medium hover:bg-slate-50">Cancel</button>
              <button className="flex-1 btn-gold justify-center py-2.5">Create User</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
