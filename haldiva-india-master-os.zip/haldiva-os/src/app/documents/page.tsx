"use client";

import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import {
  FolderOpen, Upload, Search, Filter, File, FileText, Image,
  Download, Trash2, Eye, Link2, CheckCircle, AlertCircle, Plus
} from "lucide-react";
import { formatDate, formatFileSize } from "@/lib/utils";

type DocType = "invoice" | "coa" | "lab_report" | "courier_slip" | "product_image" | "agreement" | "expense_receipt" | "other";

interface Document {
  id: string;
  name: string;
  type: DocType;
  fileUrl: string;
  fileSize: number;
  mimeType: string;
  relatedTo?: string;
  uploadedBy: string;
  createdAt: string;
}

const SAMPLE_DOCS: Document[] = [
  { id: "d1", name: "FSSAI License — HALDIVA INDIA.pdf", type: "agreement", fileUrl: "#", fileSize: 284600, mimeType: "application/pdf", relatedTo: "Company", uploadedBy: "CEO", createdAt: "2024-10-01" },
  { id: "d2", name: "COA — Honey Batch B025 — Fssai Lab.pdf", type: "coa", fileUrl: "#", fileSize: 512000, mimeType: "application/pdf", relatedTo: "HLD-H-001 Batch B025", uploadedBy: "Deepender", createdAt: "2025-04-12" },
  { id: "d3", name: "Lab Report — A2 Ghee — March 2025.pdf", type: "lab_report", fileUrl: "#", fileSize: 634000, mimeType: "application/pdf", relatedTo: "HLD-G-001", uploadedBy: "Kriti", createdAt: "2025-03-18" },
  { id: "d4", name: "Invoice — ORD-2501 — S.S. Enterprises.pdf", type: "invoice", fileUrl: "#", fileSize: 128000, mimeType: "application/pdf", relatedTo: "ORD-2501", uploadedBy: "Kriti", createdAt: "2025-04-10" },
  { id: "d5", name: "Phool Ras Honey — Product Photo.jpg", type: "product_image", fileUrl: "https://haldivaindia.com/cdn/shop/files/honey.jpg", fileSize: 1240000, mimeType: "image/jpeg", relatedTo: "HLD-H-001", uploadedBy: "Sayan", createdAt: "2025-01-15" },
  { id: "d6", name: "DTDC Courier Slip — ORD-2501.pdf", type: "courier_slip", fileUrl: "#", fileSize: 86000, mimeType: "application/pdf", relatedTo: "ORD-2501", uploadedBy: "Kriti", createdAt: "2025-04-12" },
  { id: "d7", name: "Agreement — Nutrition Mantra 360.pdf", type: "agreement", fileUrl: "#", fileSize: 342000, mimeType: "application/pdf", relatedTo: "NM360", uploadedBy: "CEO", createdAt: "2025-02-01" },
  { id: "d8", name: "Expense Receipt — Meta Ads April.pdf", type: "expense_receipt", fileUrl: "#", fileSize: 64000, mimeType: "application/pdf", relatedTo: "April Ad Spend", uploadedBy: "Sayan", createdAt: "2025-04-30" },
];

const TYPE_CFG: Record<DocType, { label: string; color: string; bg: string; icon: React.ElementType }> = {
  invoice: { label: "Invoice", color: "#1B5FD4", bg: "#EFF6FF", icon: FileText },
  coa: { label: "COA", color: "#059669", bg: "#DCFCE7", icon: CheckCircle },
  lab_report: { label: "Lab Report", color: "#7C3AED", bg: "#F5F3FF", icon: File },
  courier_slip: { label: "Courier Slip", color: "#D97706", bg: "#FEF3C7", icon: FileText },
  product_image: { label: "Product Image", color: "#BE185D", bg: "#FDF2F8", icon: Image },
  agreement: { label: "Agreement", color: "#0891B2", bg: "#CFFAFE", icon: FileText },
  expense_receipt: { label: "Expense Receipt", color: "#6B7280", bg: "#F3F4F6", icon: FileText },
  other: { label: "Other", color: "#94a3b8", bg: "#F8FAFC", icon: File },
};

export default function DocumentsPage() {
  const [docs, setDocs] = useState<Document[]>(SAMPLE_DOCS);
  const [search, setSearch] = useState("");
  const [typeFilter, setTypeFilter] = useState<string>("all");
  const [uploading, setUploading] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    setUploading(true);
    // Simulate upload
    setTimeout(() => {
      const newDocs: Document[] = acceptedFiles.map((f) => ({
        id: Math.random().toString(36).slice(2),
        name: f.name,
        type: "other",
        fileUrl: URL.createObjectURL(f),
        fileSize: f.size,
        mimeType: f.type,
        uploadedBy: "Current User",
        createdAt: new Date().toISOString().split("T")[0],
      }));
      setDocs((prev) => [...newDocs, ...prev]);
      setUploading(false);
    }, 1500);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "application/pdf": [".pdf"],
      "image/*": [".jpg", ".jpeg", ".png", ".webp"],
      "application/vnd.ms-excel": [".xls"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"],
      "text/csv": [".csv"],
    },
    maxSize: 20 * 1024 * 1024, // 20MB
  });

  const filtered = docs.filter((d) => {
    const matchSearch = d.name.toLowerCase().includes(search.toLowerCase()) ||
      (d.relatedTo || "").toLowerCase().includes(search.toLowerCase());
    const matchType = typeFilter === "all" || d.type === typeFilter;
    return matchSearch && matchType;
  });

  function deleteDoc(id: string) {
    setDocs((prev) => prev.filter((d) => d.id !== id));
  }

  return (
    <div className="p-6 space-y-5 max-w-[1400px] mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold text-navy-950">Documents & Files</h1>
          <p className="text-slate-400 text-sm mt-1">
            {docs.length} documents · COAs, invoices, lab reports, product images & more
          </p>
        </div>
        <button className="btn-gold text-xs py-2"><Plus className="w-3.5 h-3.5" /> Upload Files</button>
      </div>

      {/* Upload Zone */}
      <div
        {...getRootProps()}
        className={`border-2 border-dashed rounded-2xl p-8 text-center cursor-pointer transition-all duration-200 ${isDragActive ? "border-blue-500 bg-blue-50 scale-[1.01]" : "border-slate-200 hover:border-blue-400 hover:bg-slate-50"}`}
      >
        <input {...getInputProps()} />
        {uploading ? (
          <div className="flex flex-col items-center gap-3">
            <div className="w-10 h-10 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
            <p className="text-sm font-medium text-blue-600">Uploading files...</p>
          </div>
        ) : (
          <div className="flex flex-col items-center gap-2">
            <div className="w-12 h-12 rounded-xl bg-blue-100 flex items-center justify-center mb-1">
              <Upload className="w-6 h-6 text-blue-500" />
            </div>
            <p className="text-sm font-semibold text-slate-700">
              {isDragActive ? "Drop files here..." : "Drag & drop files or click to upload"}
            </p>
            <p className="text-xs text-slate-400">Supports PDF, JPG, PNG, Excel, CSV · Max 20MB per file</p>
            <div className="flex gap-2 mt-2 flex-wrap justify-center">
              {["Invoice", "COA", "Lab Report", "Product Image", "Agreement", "Expense Receipt"].map((t) => (
                <span key={t} className="text-xs px-2 py-0.5 rounded-full bg-slate-100 text-slate-500 font-medium">{t}</span>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-[180px] max-w-xs">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
          <input type="text" placeholder="Search documents..."
            value={search} onChange={(e) => setSearch(e.target.value)}
            className="form-input pl-9 py-2 text-sm" />
        </div>
        <div className="flex gap-2 flex-wrap">
          <button onClick={() => setTypeFilter("all")}
            className={`text-xs px-3 py-1.5 rounded-full font-medium transition-all ${typeFilter === "all" ? "bg-navy-950 text-white" : "bg-slate-100 text-slate-600 hover:bg-slate-200"}`}>
            All
          </button>
          {Object.entries(TYPE_CFG).map(([type, cfg]) => (
            <button key={type} onClick={() => setTypeFilter(type === typeFilter ? "all" : type)}
              className="text-xs px-3 py-1.5 rounded-full font-medium transition-all"
              style={typeFilter === type ? { background: cfg.color, color: "#fff" } : { background: cfg.bg, color: cfg.color }}>
              {cfg.label}
            </button>
          ))}
        </div>
        <span className="text-sm text-slate-400 ml-auto">{filtered.length} files</span>
      </div>

      {/* Document Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
        {filtered.map((doc) => {
          const tc = TYPE_CFG[doc.type];
          const isImage = doc.mimeType.startsWith("image/");
          return (
            <div key={doc.id} className="premium-card overflow-hidden group hover:shadow-md transition-all duration-200">
              {/* Thumbnail */}
              <div className="relative h-32 flex items-center justify-center"
                style={{ background: isImage ? "#000" : tc.bg }}>
                {isImage ? (
                  <img src={doc.fileUrl} alt={doc.name} className="w-full h-full object-cover opacity-80" />
                ) : (
                  <tc.icon className="w-10 h-10" style={{ color: tc.color }} />
                )}
                {/* Hover actions */}
                <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2">
                  <button className="p-2 rounded-lg bg-white/20 hover:bg-white/30 text-white transition-colors" title="Preview">
                    <Eye className="w-4 h-4" />
                  </button>
                  <button className="p-2 rounded-lg bg-white/20 hover:bg-white/30 text-white transition-colors" title="Download">
                    <Download className="w-4 h-4" />
                  </button>
                  <button onClick={() => deleteDoc(doc.id)}
                    className="p-2 rounded-lg bg-red-500/60 hover:bg-red-500/80 text-white transition-colors" title="Delete">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
                {/* Type badge */}
                <span className="absolute top-2 left-2 text-[10px] font-bold px-1.5 py-0.5 rounded-full"
                  style={{ color: tc.color, background: "rgba(255,255,255,0.9)" }}>
                  {tc.label}
                </span>
              </div>

              {/* Info */}
              <div className="p-3">
                <p className="text-xs font-semibold text-navy-950 truncate" title={doc.name}>{doc.name}</p>
                {doc.relatedTo && (
                  <div className="flex items-center gap-1 mt-1">
                    <Link2 className="w-3 h-3 text-slate-400" />
                    <p className="text-[10px] text-slate-400 truncate">{doc.relatedTo}</p>
                  </div>
                )}
                <div className="flex items-center justify-between mt-2">
                  <span className="text-[10px] text-slate-400">{formatFileSize(doc.fileSize)}</span>
                  <span className="text-[10px] text-slate-400">{formatDate(doc.createdAt, "dd MMM")}</span>
                </div>
              </div>
            </div>
          );
        })}

        {filtered.length === 0 && (
          <div className="col-span-full py-16 text-center">
            <FolderOpen className="w-12 h-12 text-slate-200 mx-auto mb-3" />
            <p className="text-slate-400 font-semibold">No documents found</p>
            <p className="text-slate-300 text-sm mt-1">Upload files or adjust your search filters</p>
          </div>
        )}
      </div>
    </div>
  );
}
