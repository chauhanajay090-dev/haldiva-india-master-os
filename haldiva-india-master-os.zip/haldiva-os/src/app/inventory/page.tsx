"use client";

import { useState, useCallback } from "react";
import { useDropzone } from "react-dropzone";
import {
  Package, Plus, Search, Filter, Download, Upload, AlertTriangle,
  ChevronDown, Edit2, Trash2, BarChart3, ArrowLeftRight, QrCode,
  CheckCircle, XCircle, Clock, RefreshCw
} from "lucide-react";
import { formatCurrency, formatNumber, downloadCSV } from "@/lib/utils";

type StockType = "warehouse" | "office" | "online" | "offline" | "distributor" | "reseller" | "sample" | "damaged";

interface Product {
  id: string;
  sku: string;
  name: string;
  category: string;
  mrp: number;
  selling_price: number;
  gst_rate: number;
  unit: string;
  reorder_level: number;
  coa_status: string;
  stock: Record<StockType, number>;
  total_stock: number;
  image_url?: string;
}

const SAMPLE_PRODUCTS: Product[] = [
  { id: "1", sku: "HLD-H-001", name: "Phool Ras Honey — 100% Pure Raw", category: "Honey", mrp: 299, selling_price: 249, gst_rate: 0, unit: "jar", reorder_level: 60, coa_status: "approved", stock: { warehouse: 180, office: 40, online: 75, offline: 25, distributor: 60, reseller: 20, sample: 8, damaged: 2 }, total_stock: 410 },
  { id: "2", sku: "HLD-H-003", name: "Amrit Honey — Turmeric 150ml", category: "Honey", mrp: 299, selling_price: 249, gst_rate: 0, unit: "jar", reorder_level: 40, coa_status: "approved", stock: { warehouse: 10, office: 4, online: 8, offline: 2, distributor: 0, reseller: 0, sample: 2, damaged: 1 }, total_stock: 27 },
  { id: "3", sku: "HLD-G-001", name: "A2 Gir Cow Heritage Ghee", category: "Ghee", mrp: 499, selling_price: 399, gst_rate: 5, unit: "jar", reorder_level: 30, coa_status: "approved", stock: { warehouse: 60, office: 20, online: 45, offline: 15, distributor: 28, reseller: 12, sample: 5, damaged: 1 }, total_stock: 186 },
  { id: "4", sku: "HLD-G-002", name: "Sahiwal Desi Ghee A2 Bilona", category: "Ghee", mrp: 899, selling_price: 740, gst_rate: 5, unit: "jar", reorder_level: 20, coa_status: "pending", stock: { warehouse: 35, office: 12, online: 22, offline: 8, distributor: 15, reseller: 5, sample: 3, damaged: 0 }, total_stock: 100 },
  { id: "5", sku: "HLD-S-001", name: "Turmeric Powder 100g", category: "Spices", mrp: 449, selling_price: 365, gst_rate: 5, unit: "pkt", reorder_level: 60, coa_status: "approved", stock: { warehouse: 150, office: 30, online: 80, offline: 20, distributor: 40, reseller: 15, sample: 5, damaged: 0 }, total_stock: 340 },
  { id: "6", sku: "HLD-O-001", name: "Black Mustard Oil — Wood Pressed", category: "Oils", mrp: 149, selling_price: 115, gst_rate: 0, unit: "btl", reorder_level: 30, coa_status: "approved", stock: { warehouse: 4, office: 2, online: 3, offline: 1, distributor: 0, reseller: 0, sample: 0, damaged: 2 }, total_stock: 12 },
  { id: "7", sku: "HLD-CB-001", name: "Royal Festive Gift Duo", category: "Combos", mrp: 1999, selling_price: 1629, gst_rate: 5, unit: "set", reorder_level: 15, coa_status: "approved", stock: { warehouse: 20, office: 8, online: 15, offline: 5, distributor: 10, reseller: 4, sample: 2, damaged: 0 }, total_stock: 64 },
  { id: "8", sku: "HLD-HMP-001", name: "Premium Ghee Lover Box", category: "Hampers", mrp: 1999, selling_price: 1649, gst_rate: 5, unit: "box", reorder_level: 10, coa_status: "approved", stock: { warehouse: 15, office: 5, online: 12, offline: 3, distributor: 8, reseller: 2, sample: 1, damaged: 0 }, total_stock: 46 },
];

const STOCK_TYPES: { key: StockType; label: string; color: string }[] = [
  { key: "warehouse", label: "Warehouse", color: "#1B5FD4" },
  { key: "office", label: "Office", color: "#7C3AED" },
  { key: "online", label: "Online", color: "#059669" },
  { key: "offline", label: "Offline", color: "#D97706" },
  { key: "distributor", label: "Distributor", color: "#BE185D" },
  { key: "reseller", label: "Reseller", color: "#0891B2" },
  { key: "sample", label: "Sample", color: "#6B7280" },
  { key: "damaged", label: "Damaged", color: "#DC2626" },
];

export default function InventoryPage() {
  const [products] = useState<Product[]>(SAMPLE_PRODUCTS);
  const [search, setSearch] = useState("");
  const [categoryFilter, setCategoryFilter] = useState("all");
  const [view, setView] = useState<"list" | "grid">("list");
  const [activeTab, setActiveTab] = useState<"products" | "stock" | "movements" | "import">("products");
  const [importPreview, setImportPreview] = useState<Record<string, unknown>[]>([]);
  const [importing, setImporting] = useState(false);

  const onDrop = useCallback((acceptedFiles: File[]) => {
    const file = acceptedFiles[0];
    if (!file) return;
    // Simulate CSV parsing
    setImportPreview([
      { sku: "HLD-NEW-001", name: "New Product", category: "Honey", mrp: 299, qty: 100 },
      { sku: "HLD-NEW-002", name: "Another Product", category: "Ghee", mrp: 499, qty: 50 },
    ]);
  }, []);

  const { getRootProps, getInputProps, isDragActive } = useDropzone({
    onDrop,
    accept: {
      "text/csv": [".csv"],
      "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet": [".xlsx"],
      "application/vnd.ms-excel": [".xls"],
    },
  });

  const filteredProducts = products.filter((p) => {
    const matchSearch = p.name.toLowerCase().includes(search.toLowerCase()) ||
      p.sku.toLowerCase().includes(search.toLowerCase());
    const matchCat = categoryFilter === "all" || p.category.toLowerCase() === categoryFilter.toLowerCase();
    return matchSearch && matchCat;
  });

  const lowStockProducts = products.filter((p) => p.stock.warehouse <= p.reorder_level);
  const totalValue = products.reduce((sum, p) => sum + p.total_stock * p.selling_price, 0);
  const categories = ["all", ...new Set(products.map((p) => p.category))];

  const COA_BADGE: Record<string, { label: string; icon: React.ReactNode; color: string; bg: string }> = {
    approved: { label: "COA Approved", icon: <CheckCircle className="w-3 h-3" />, color: "#059669", bg: "#ECFDF5" },
    pending: { label: "COA Pending", icon: <Clock className="w-3 h-3" />, color: "#D97706", bg: "#FFFBEB" },
    expired: { label: "COA Expired", icon: <XCircle className="w-3 h-3" />, color: "#DC2626", bg: "#FEF2F2" },
  };

  return (
    <div className="p-6 space-y-5 max-w-[1600px] mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between">
        <div>
          <h1 className="text-2xl font-display font-bold text-navy-950">Inventory Master</h1>
          <p className="text-slate-400 text-sm mt-1">
            {products.length} products · {formatCurrency(totalValue)} total value · {lowStockProducts.length} low stock alerts
          </p>
        </div>
        <div className="flex items-center gap-2">
          <button onClick={() => downloadCSV(products.map(p => ({ sku: p.sku, name: p.name, total: p.total_stock })), "inventory")}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 text-slate-600 text-xs font-medium hover:bg-slate-50 transition-colors">
            <Download className="w-3.5 h-3.5" /> Export
          </button>
          <button className="btn-navy text-xs py-2">
            <Plus className="w-3.5 h-3.5" /> Add Product
          </button>
          <button className="btn-gold text-xs py-2">
            <Upload className="w-3.5 h-3.5" /> Import CSV
          </button>
        </div>
      </div>

      {/* Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Products", value: products.length, sub: `${products.filter(p => p.total_stock > 0).length} in stock`, color: "#1B5FD4", bg: "#EFF6FF" },
          { label: "Inventory Value", value: formatCurrency(totalValue), sub: "Across all stock types", color: "#059669", bg: "#ECFDF5" },
          { label: "Low Stock", value: lowStockProducts.length, sub: "Below reorder level", color: "#DC2626", bg: "#FEF2F2" },
          { label: "Categories", value: categories.length - 1, sub: "Active product lines", color: "#7C3AED", bg: "#F5F3FF" },
        ].map((m) => (
          <div key={m.label} className="stat-card">
            <p className="stat-label">{m.label}</p>
            <p className="stat-value" style={{ color: m.color }}>{m.value}</p>
            <p className="stat-meta">{m.sub}</p>
          </div>
        ))}
      </div>

      {/* Low stock alerts */}
      {lowStockProducts.length > 0 && (
        <div className="alert-warning">
          <AlertTriangle className="w-4 h-4 flex-shrink-0 mt-0.5" />
          <div>
            <p className="text-sm font-semibold">Low Stock Alert</p>
            <p className="text-sm mt-1">
              {lowStockProducts.map(p => p.name).join(", ")} — need immediate reorder
            </p>
          </div>
        </div>
      )}

      {/* Tabs */}
      <div className="flex gap-1 p-1 bg-slate-100 rounded-xl w-fit">
        {[
          { key: "products", label: "Products", icon: Package },
          { key: "stock", label: "Stock Levels", icon: BarChart3 },
          { key: "movements", label: "Movements", icon: ArrowLeftRight },
          { key: "import", label: "Import / Scan", icon: Upload },
        ].map(({ key, label, icon: Icon }) => (
          <button key={key} onClick={() => setActiveTab(key as typeof activeTab)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all duration-150 ${
              activeTab === key ? "bg-white text-navy-950 shadow-sm" : "text-slate-500 hover:text-slate-700"
            }`}>
            <Icon className="w-4 h-4" />
            {label}
          </button>
        ))}
      </div>

      {/* Tab: Products */}
      {activeTab === "products" && (
        <div className="premium-card">
          {/* Filters */}
          <div className="p-4 border-b border-slate-100 flex flex-wrap gap-3 items-center">
            <div className="relative flex-1 min-w-[200px] max-w-sm">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input type="text" placeholder="Search by name or SKU..."
                value={search} onChange={(e) => setSearch(e.target.value)}
                className="form-input pl-9 py-2" />
            </div>
            <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}
              className="form-input w-auto py-2 text-sm">
              {categories.map(c => (
                <option key={c} value={c}>{c === "all" ? "All Categories" : c}</option>
              ))}
            </select>
            <div className="ml-auto text-sm text-slate-400">
              {filteredProducts.length} products
            </div>
          </div>

          {/* Table */}
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>SKU / Product</th>
                  <th>Category</th>
                  <th>MRP</th>
                  <th>Selling Price</th>
                  <th>GST</th>
                  <th>Total Stock</th>
                  <th>Warehouse</th>
                  <th>Online</th>
                  <th>Distributor</th>
                  <th>COA</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {filteredProducts.map((p) => {
                  const isLow = p.stock.warehouse <= p.reorder_level;
                  const coa = COA_BADGE[p.coa_status] || COA_BADGE.pending;
                  return (
                    <tr key={p.id}>
                      <td>
                        <div>
                          <p className="font-semibold text-sm text-navy-950">{p.name}</p>
                          <p className="font-mono text-xs text-slate-400">{p.sku}</p>
                        </div>
                      </td>
                      <td>
                        <span className="text-xs px-2 py-0.5 rounded-full bg-blue-50 text-blue-700 font-medium">{p.category}</span>
                      </td>
                      <td className="font-medium">{formatCurrency(p.mrp)}</td>
                      <td className="font-semibold text-green-700">{formatCurrency(p.selling_price)}</td>
                      <td className="text-sm text-slate-500">{p.gst_rate}%</td>
                      <td>
                        <span className={`font-bold text-sm ${isLow ? "text-red-600" : "text-navy-950"}`}>
                          {formatNumber(p.total_stock)}
                          {isLow && <AlertTriangle className="w-3 h-3 inline ml-1 text-amber-500" />}
                        </span>
                      </td>
                      <td className="font-medium">
                        <span className={p.stock.warehouse <= p.reorder_level ? "text-red-600 font-bold" : ""}>
                          {p.stock.warehouse}
                        </span>
                      </td>
                      <td>{p.stock.online}</td>
                      <td>{p.stock.distributor}</td>
                      <td>
                        <span className="flex items-center gap-1 text-xs font-semibold px-2 py-0.5 rounded-full w-fit"
                          style={{ color: coa.color, background: coa.bg }}>
                          {coa.icon} {coa.label}
                        </span>
                      </td>
                      <td>
                        <div className="flex items-center gap-1">
                          <button className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-blue-600 transition-colors">
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                          <button className="p-1.5 rounded-lg hover:bg-slate-100 text-slate-500 hover:text-slate-700 transition-colors">
                            <QrCode className="w-3.5 h-3.5" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Stock Levels */}
      {activeTab === "stock" && (
        <div className="premium-card p-5">
          <h3 className="section-title mb-4">Stock by Type — All Products</h3>
          <div className="overflow-x-auto">
            <table className="data-table">
              <thead>
                <tr>
                  <th>Product</th>
                  {STOCK_TYPES.map(st => <th key={st.key}>{st.label}</th>)}
                  <th>Total</th>
                  <th>Value</th>
                </tr>
              </thead>
              <tbody>
                {products.map((p) => (
                  <tr key={p.id}>
                    <td>
                      <div>
                        <p className="font-semibold text-sm">{p.name}</p>
                        <p className="font-mono text-xs text-slate-400">{p.sku}</p>
                      </div>
                    </td>
                    {STOCK_TYPES.map(st => (
                      <td key={st.key}>
                        <span className={st.key === "damaged" && p.stock[st.key] > 0 ? "text-red-600 font-bold" : ""}>
                          {p.stock[st.key]}
                        </span>
                      </td>
                    ))}
                    <td className="font-bold">{formatNumber(p.total_stock)}</td>
                    <td className="font-semibold text-green-700">{formatCurrency(p.total_stock * p.selling_price)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab: Import */}
      {activeTab === "import" && (
        <div className="space-y-5">
          <div className="premium-card p-5">
            <h3 className="section-title mb-2">Smart Import System</h3>
            <p className="text-sm text-slate-400 mb-5">
              Upload Excel/CSV files to bulk import products and stock. Supports automatic duplicate detection and preview before saving.
            </p>
            <div {...getRootProps()}
              className={`border-2 border-dashed rounded-xl p-10 text-center cursor-pointer transition-all duration-150 ${
                isDragActive ? "border-blue-500 bg-blue-50" : "border-slate-200 hover:border-blue-400 hover:bg-slate-50"
              }`}>
              <input {...getInputProps()} />
              <Upload className="w-10 h-10 text-slate-300 mx-auto mb-3" />
              <p className="text-sm font-semibold text-slate-600">
                {isDragActive ? "Drop your file here..." : "Drop Excel / CSV here or click to browse"}
              </p>
              <p className="text-xs text-slate-400 mt-1">Supports .xlsx, .xls, .csv · Max 10MB</p>
            </div>

            {/* Supported fields */}
            <div className="mt-5 p-4 bg-slate-50 rounded-xl">
              <p className="text-xs font-semibold text-slate-600 mb-2 uppercase tracking-wider">Auto-detected fields</p>
              <div className="flex flex-wrap gap-1.5">
                {["Product Name", "SKU", "Barcode", "Category", "MRP", "Selling Price", "Cost Price", "GST %", "HSN Code", "Quantity", "Warehouse", "Batch Number", "MFG Date", "EXP Date", "Supplier", "Invoice Number"].map(f => (
                  <span key={f} className="text-xs px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 font-medium">{f}</span>
                ))}
              </div>
            </div>
          </div>

          {/* Preview */}
          {importPreview.length > 0 && (
            <div className="premium-card p-5">
              <div className="flex items-center justify-between mb-4">
                <div>
                  <h3 className="section-title">Import Preview</h3>
                  <p className="section-sub">{importPreview.length} rows detected · Review before importing</p>
                </div>
                <div className="flex gap-2">
                  <button onClick={() => setImportPreview([])}
                    className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 text-slate-600 text-xs font-medium">
                    <XCircle className="w-3.5 h-3.5" /> Discard
                  </button>
                  <button className="btn-navy text-xs py-2">
                    <CheckCircle className="w-3.5 h-3.5" /> Confirm Import
                  </button>
                </div>
              </div>
              <div className="overflow-x-auto">
                <table className="data-table">
                  <thead>
                    <tr>
                      {Object.keys(importPreview[0]).map(k => <th key={k}>{k}</th>)}
                      <th>Status</th>
                    </tr>
                  </thead>
                  <tbody>
                    {importPreview.map((row, i) => (
                      <tr key={i}>
                        {Object.values(row).map((v, j) => <td key={j}>{String(v)}</td>)}
                        <td><span className="badge-status text-xs" style={{ background: "#ECFDF5", color: "#059669" }}>Ready</span></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
