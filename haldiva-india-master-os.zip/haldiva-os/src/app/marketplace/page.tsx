"use client";

import { useState } from "react";
import { ShoppingBag, TrendingUp, Package, AlertTriangle, RefreshCw, Plus, ExternalLink, BarChart2 } from "lucide-react";
import { formatCurrency } from "@/lib/utils";

const PLATFORMS = [
  { id: "amazon", name: "Amazon.in", color: "#FF9900", bg: "#FFF7E6", logo: "🛒", status: "active", gmv: 86000, orders: 42, returns: 3, listing: 14, pendingListing: 4 },
  { id: "flipkart", name: "Flipkart", color: "#2874F0", bg: "#EFF6FF", logo: "🏪", status: "active", gmv: 42000, orders: 28, returns: 2, listing: 12, pendingListing: 2 },
  { id: "jiomart", name: "JioMart", color: "#059669", bg: "#ECFDF5", logo: "🛍", status: "setup", gmv: 0, orders: 0, returns: 0, listing: 0, pendingListing: 8 },
];

const LISTINGS = [
  { id: "l1", sku: "HLD-H-001", product: "Phool Ras Honey 100% Pure Raw", amazon: "live", flipkart: "live", jiomart: "pending", amazonASIN: "B0CXL8P9Z1", price: 249, stock: 75 },
  { id: "l2", sku: "HLD-G-001", product: "A2 Gir Cow Heritage Ghee", amazon: "live", flipkart: "live", jiomart: "not_listed", amazonASIN: "B0CXL8GHEE", price: 399, stock: 45 },
  { id: "l3", sku: "HLD-H-004", product: "Shilajit Honey 150g", amazon: "live", flipkart: "pending", jiomart: "pending", amazonASIN: "B0CXSHLJT1", price: 380, stock: 30 },
  { id: "l4", sku: "HLD-S-001", product: "Turmeric Powder 100g", amazon: "live", flipkart: "live", jiomart: "pending", amazonASIN: "B0CXTUR100", price: 365, stock: 80 },
  { id: "l5", sku: "HLD-O-001", product: "Black Mustard Oil — Wood Pressed", amazon: "low_stock", flipkart: "low_stock", jiomart: "not_listed", amazonASIN: "B0CXMUST01", price: 115, stock: 4 },
  { id: "l6", sku: "HLD-CB-001", product: "Royal Festive Gift Duo", amazon: "pending", flipkart: "not_listed", jiomart: "not_listed", amazonASIN: "", price: 1629, stock: 15 },
];

const MARKETPLACE_ORDERS = [
  { id: "AMZ-124-9841234", platform: "amazon", product: "A2 Gir Cow Heritage Ghee", qty: 2, amount: 798, status: "dispatched", date: "2025-05-04" },
  { id: "FK-OD-128741234", platform: "flipkart", product: "Phool Ras Honey", qty: 3, amount: 747, status: "delivered", date: "2025-05-03" },
  { id: "AMZ-124-9838921", platform: "amazon", product: "Shilajit Honey 150g", qty: 1, amount: 380, status: "packed", date: "2025-05-04" },
  { id: "FK-OD-128735678", platform: "flipkart", product: "Turmeric Powder 100g", qty: 2, amount: 730, status: "confirmed", date: "2025-05-04" },
];

const STATUS_BADGE: Record<string, { label: string; color: string; bg: string }> = {
  live: { label: "Live", color: "#059669", bg: "#DCFCE7" },
  pending: { label: "Pending Review", color: "#D97706", bg: "#FEF3C7" },
  not_listed: { label: "Not Listed", color: "#94a3b8", bg: "#F1F5F9" },
  low_stock: { label: "Low Stock", color: "#DC2626", bg: "#FEE2E2" },
  suspended: { label: "Suspended", color: "#DC2626", bg: "#FEE2E2" },
};

const ORDER_STATUS: Record<string, { label: string; color: string; bg: string }> = {
  confirmed: { label: "Confirmed", color: "#7C3AED", bg: "#F5F3FF" },
  packed: { label: "Packed", color: "#0891B2", bg: "#CFFAFE" },
  dispatched: { label: "Dispatched", color: "#D97706", bg: "#FEF3C7" },
  delivered: { label: "Delivered", color: "#059669", bg: "#DCFCE7" },
  returned: { label: "Returned", color: "#DC2626", bg: "#FEE2E2" },
};

export default function MarketplacePage() {
  const [activePlatform, setActivePlatform] = useState<string>("all");

  const totalGMV = PLATFORMS.reduce((s, p) => s + p.gmv, 0);
  const totalOrders = PLATFORMS.reduce((s, p) => s + p.orders, 0);

  return (
    <div className="p-6 space-y-5 max-w-[1400px] mx-auto">
      {/* Header */}
      <div className="flex items-start justify-between flex-wrap gap-4">
        <div>
          <h1 className="text-2xl font-display font-bold text-navy-950">Marketplace Management</h1>
          <p className="text-slate-400 text-sm mt-1">Amazon · Flipkart · JioMart · ONDC</p>
        </div>
        <button className="btn-gold text-xs py-2"><Plus className="w-3.5 h-3.5" /> Add Listing</button>
      </div>

      {/* Platform Cards */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {PLATFORMS.map((p) => (
          <div key={p.id}
            onClick={() => setActivePlatform(activePlatform === p.id ? "all" : p.id)}
            className={`premium-card p-5 cursor-pointer transition-all duration-150 ${activePlatform === p.id ? "ring-2 shadow-md" : "hover:shadow-md"}`}
            style={activePlatform === p.id ? { ringColor: p.color } : {}}>
            <div className="flex items-start justify-between mb-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl flex items-center justify-center text-2xl" style={{ background: p.bg }}>
                  {p.logo}
                </div>
                <div>
                  <p className="font-bold text-navy-950">{p.name}</p>
                  <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded-full ${p.status === "active" ? "bg-green-100 text-green-700" : "bg-amber-100 text-amber-700"}`}>
                    {p.status === "active" ? "LIVE" : "SETUP"}
                  </span>
                </div>
              </div>
              <a href="#" className="text-slate-400 hover:text-slate-600 transition-colors">
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="p-2.5 rounded-lg bg-slate-50 text-center">
                <p className="text-lg font-display font-bold" style={{ color: p.color }}>{formatCurrency(p.gmv)}</p>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">GMV</p>
              </div>
              <div className="p-2.5 rounded-lg bg-slate-50 text-center">
                <p className="text-lg font-display font-bold text-navy-950">{p.orders}</p>
                <p className="text-[10px] text-slate-400 uppercase tracking-wider">Orders</p>
              </div>
            </div>
            <div className="flex items-center justify-between mt-3 text-xs">
              <span className="text-slate-400">{p.listing} live listings</span>
              {p.pendingListing > 0 && (
                <span className="text-amber-600 font-semibold">{p.pendingListing} pending</span>
              )}
              {p.returns > 0 && <span className="text-red-500">{p.returns} returns</span>}
            </div>
          </div>
        ))}
      </div>

      {/* Summary */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {[
          { label: "Total Marketplace GMV", value: formatCurrency(totalGMV), color: "#059669", bg: "#DCFCE7" },
          { label: "Total Orders", value: totalOrders, color: "#1B5FD4", bg: "#EFF6FF" },
          { label: "Live Listings", value: LISTINGS.filter(l => l.amazon === "live").length, color: "#059669", bg: "#DCFCE7" },
          { label: "Pending Actions", value: LISTINGS.filter(l => Object.values(l).includes("pending")).length, color: "#D97706", bg: "#FEF3C7" },
        ].map((m) => (
          <div key={m.label} className="stat-card">
            <p className="stat-label">{m.label}</p>
            <p className="stat-value text-xl" style={{ color: m.color }}>{m.value}</p>
          </div>
        ))}
      </div>

      {/* Listings Table */}
      <div className="premium-card overflow-hidden">
        <div className="p-4 border-b border-slate-100 flex items-center justify-between">
          <h3 className="text-sm font-semibold text-navy-950">Product Listings Status</h3>
          <button className="flex items-center gap-1.5 text-xs text-blue-600 font-medium hover:text-blue-700">
            <RefreshCw className="w-3.5 h-3.5" /> Sync Listings
          </button>
        </div>
        <div className="overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr>
                <th>SKU / Product</th>
                <th>Price</th>
                <th>Online Stock</th>
                <th>Amazon</th>
                <th>Flipkart</th>
                <th>JioMart</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {LISTINGS.map((l) => (
                <tr key={l.id}>
                  <td>
                    <p className="font-semibold text-sm">{l.product}</p>
                    <p className="font-mono text-xs text-slate-400">{l.sku}</p>
                    {l.amazonASIN && <p className="font-mono text-[10px] text-slate-300">ASIN: {l.amazonASIN}</p>}
                  </td>
                  <td className="font-semibold">{formatCurrency(l.price)}</td>
                  <td>
                    <span className={`font-bold text-sm ${l.stock < 10 ? "text-red-600" : l.stock < 30 ? "text-amber-600" : "text-green-700"}`}>
                      {l.stock} {l.stock < 10 && <AlertTriangle className="w-3 h-3 inline ml-1" />}
                    </span>
                  </td>
                  {(["amazon", "flipkart", "jiomart"] as const).map((platform) => {
                    const statusKey = l[platform] as keyof typeof STATUS_BADGE;
                    const sc = STATUS_BADGE[statusKey] || STATUS_BADGE.not_listed;
                    return (
                      <td key={platform}>
                        <span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ color: sc.color, background: sc.bg }}>
                          {sc.label}
                        </span>
                      </td>
                    );
                  })}
                  <td>
                    <button className="text-xs px-3 py-1 rounded-lg bg-navy-950 text-white hover:bg-navy-900 transition-colors font-medium">
                      Manage
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Recent Marketplace Orders */}
      <div className="premium-card overflow-hidden">
        <div className="p-4 border-b border-slate-100">
          <h3 className="text-sm font-semibold text-navy-950">Recent Marketplace Orders</h3>
        </div>
        <div className="overflow-x-auto">
          <table className="data-table">
            <thead>
              <tr><th>Order ID</th><th>Platform</th><th>Product</th><th>Qty</th><th>Amount</th><th>Status</th><th>Date</th></tr>
            </thead>
            <tbody>
              {MARKETPLACE_ORDERS.map((o) => {
                const sc = ORDER_STATUS[o.status];
                const p = PLATFORMS.find(pl => pl.id === o.platform);
                return (
                  <tr key={o.id}>
                    <td className="font-mono text-xs text-slate-500">{o.id}</td>
                    <td>
                      <span className="flex items-center gap-1 text-xs font-semibold">
                        {p?.logo} {p?.name}
                      </span>
                    </td>
                    <td className="font-medium text-sm">{o.product}</td>
                    <td>{o.qty}</td>
                    <td className="font-semibold">{formatCurrency(o.amount)}</td>
                    <td>
                      <span className="text-xs font-semibold px-2 py-0.5 rounded-full" style={{ color: sc.color, background: sc.bg }}>
                        {sc.label}
                      </span>
                    </td>
                    <td className="text-xs text-slate-400">{o.date}</td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
