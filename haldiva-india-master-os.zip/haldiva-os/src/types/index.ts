// ============================================================
// HALDIVA INDIA MASTER OS — Complete Type System
// ============================================================

// ── USER & AUTH ──────────────────────────────────────────────

export type UserRole =
  | "ceo"
  | "senior_executive"
  | "data_executive"
  | "digital_marketing"
  | "marketplace_agency"
  | "distributor"
  | "reseller";

export interface User {
  id: string;
  email: string;
  name: string;
  role: UserRole;
  department?: string;
  phone?: string;
  avatar_url?: string;
  is_active: boolean;
  two_fa_enabled: boolean;
  last_login?: string;
  created_at: string;
  updated_at: string;
}

export interface Role {
  id: string;
  name: UserRole;
  label: string;
  permissions: Permission[];
  created_at: string;
}

export interface Permission {
  module: ModuleKey;
  can_view: boolean;
  can_create: boolean;
  can_edit: boolean;
  can_delete: boolean;
  can_export: boolean;
}

export type ModuleKey =
  | "dashboard"
  | "inventory"
  | "orders"
  | "finance"
  | "hr"
  | "marketing"
  | "partners"
  | "documents"
  | "settings"
  | "reports"
  | "marketplace"
  | "seo"
  | "social_media"
  | "users";

// ── PRODUCTS & INVENTORY ─────────────────────────────────────

export type StockType =
  | "warehouse"
  | "office"
  | "online"
  | "offline"
  | "distributor"
  | "reseller"
  | "sample"
  | "gifting"
  | "damaged"
  | "expired"
  | "returned";

export type Channel =
  | "shopify"
  | "shopdeck"
  | "amazon"
  | "flipkart"
  | "jiomart"
  | "ondc"
  | "direct"
  | "walkin"
  | "society"
  | "event"
  | "reference"
  | "distributor"
  | "reseller"
  | "corporate"
  | "bulk"
  | "horeca";

export interface Category {
  id: string;
  name: string;
  parent_id?: string;
  slug: string;
  created_at: string;
}

export interface Supplier {
  id: string;
  name: string;
  contact_person?: string;
  phone?: string;
  email?: string;
  address?: string;
  gstin?: string;
  created_at: string;
}

export interface Product {
  id: string;
  name: string;
  sku: string;
  barcode?: string;
  category_id: string;
  category?: Category;
  supplier_id?: string;
  supplier?: Supplier;
  description?: string;
  mrp: number;
  cost_price: number;
  selling_price: number;
  gst_rate: number;
  hsn_code?: string;
  unit: string;
  reorder_level: number;
  storage_location?: string;
  coa_status: "pending" | "approved" | "expired";
  lab_report_status: "pending" | "approved" | "expired";
  image_url?: string;
  is_active: boolean;
  created_at: string;
  updated_at: string;
  // Computed
  total_stock?: number;
  stock_by_type?: Partial<Record<StockType, number>>;
}

export interface ProductBatch {
  id: string;
  product_id: string;
  product?: Product;
  batch_number: string;
  mfg_date: string;
  exp_date: string;
  quantity: number;
  remaining_quantity: number;
  cost_price: number;
  supplier_id?: string;
  notes?: string;
  created_at: string;
}

export interface InventoryMovement {
  id: string;
  product_id: string;
  product?: Product;
  batch_id?: string;
  batch?: ProductBatch;
  movement_type: "in" | "out" | "transfer" | "adjustment";
  from_type?: StockType;
  to_type?: StockType;
  quantity: number;
  reference_id?: string;
  reference_type?: "order" | "purchase" | "transfer" | "adjustment";
  notes?: string;
  created_by: string;
  created_at: string;
}

export interface StockSummary {
  product_id: string;
  product?: Product;
  warehouse: number;
  office: number;
  online: number;
  offline: number;
  distributor: number;
  reseller: number;
  sample: number;
  gifting: number;
  damaged: number;
  expired: number;
  returned: number;
  total: number;
}

export interface ChannelStock {
  product_id: string;
  channel: Channel;
  opening_stock: number;
  allocated_stock: number;
  sold_stock: number;
  returned_stock: number;
  pending_dispatch: number;
  available_stock: number;
}

// ── ORDERS ───────────────────────────────────────────────────

export type OrderType =
  | "b2c_online"
  | "b2c_offline"
  | "distributor"
  | "reseller"
  | "corporate_gifting"
  | "bulk"
  | "event"
  | "marketplace";

export type OrderStatus =
  | "new"
  | "confirmed"
  | "packed"
  | "dispatched"
  | "delivered"
  | "pending_payment"
  | "cancelled"
  | "returned";

export type PaymentStatus = "pending" | "partial" | "paid" | "refunded";

export interface Customer {
  id: string;
  name: string;
  phone: string;
  email?: string;
  address?: string;
  city?: string;
  state?: string;
  pincode?: string;
  gstin?: string;
  created_at: string;
}

export interface OrderItem {
  id: string;
  order_id: string;
  product_id: string;
  product?: Product;
  batch_id?: string;
  quantity: number;
  mrp: number;
  selling_price: number;
  discount: number;
  gst_rate: number;
  gst_amount: number;
  total: number;
}

export interface Order {
  id: string;
  order_number: string;
  order_type: OrderType;
  channel: Channel;
  customer_id?: string;
  customer?: Customer;
  partner_id?: string;
  status: OrderStatus;
  payment_status: PaymentStatus;
  items: OrderItem[];
  subtotal: number;
  discount_total: number;
  gst_total: number;
  shipping_charge: number;
  total: number;
  amount_paid: number;
  amount_due: number;
  courier_name?: string;
  tracking_id?: string;
  dispatch_date?: string;
  delivery_date?: string;
  expected_delivery?: string;
  invoice_number?: string;
  notes?: string;
  created_by: string;
  created_at: string;
  updated_at: string;
}

export interface Payment {
  id: string;
  order_id: string;
  amount: number;
  payment_method: "cash" | "upi" | "bank_transfer" | "cheque" | "online";
  transaction_id?: string;
  payment_date: string;
  notes?: string;
  created_at: string;
}

// ── FINANCE ──────────────────────────────────────────────────

export type ExpenseCategory =
  | "purchase"
  | "packaging"
  | "courier"
  | "ads"
  | "salary"
  | "rent"
  | "events"
  | "legal"
  | "lab_testing"
  | "misc";

export interface Expense {
  id: string;
  category: ExpenseCategory;
  description: string;
  amount: number;
  gst_amount?: number;
  vendor?: string;
  invoice_number?: string;
  expense_date: string;
  document_url?: string;
  created_by: string;
  created_at: string;
}

export interface IncomeEntry {
  id: string;
  source: string;
  description: string;
  amount: number;
  date: string;
  reference?: string;
  created_at: string;
}

export interface FinanceSummary {
  period: string;
  total_revenue: number;
  total_expenses: number;
  gross_profit: number;
  gross_margin: number;
  pending_payments: number;
  by_channel: Record<Channel, number>;
  by_expense: Record<ExpenseCategory, number>;
}

// ── HR ────────────────────────────────────────────────────────

export type AttendanceStatus =
  | "present"
  | "absent"
  | "late"
  | "leave"
  | "half_day"
  | "wfh"
  | "overtime";

export interface AttendanceRecord {
  id: string;
  user_id: string;
  user?: User;
  date: string;
  check_in?: string;
  check_out?: string;
  status: AttendanceStatus;
  late_by_minutes?: number;
  overtime_minutes?: number;
  notes?: string;
  created_at: string;
}

export type TaskPriority = "low" | "medium" | "high" | "urgent";
export type TaskStatus = "todo" | "in_progress" | "review" | "done" | "cancelled";

export interface Task {
  id: string;
  title: string;
  description?: string;
  assigned_to: string;
  assigned_user?: User;
  assigned_by: string;
  priority: TaskPriority;
  status: TaskStatus;
  progress: number;
  deadline?: string;
  completed_at?: string;
  comments?: TaskComment[];
  created_at: string;
  updated_at: string;
}

export interface TaskComment {
  id: string;
  task_id: string;
  user_id: string;
  user?: User;
  comment: string;
  progress_update?: number;
  created_at: string;
}

// ── MARKETING ────────────────────────────────────────────────

export interface SEOKeyword {
  id: string;
  keyword: string;
  target_url: string;
  current_rank?: number;
  previous_rank?: number;
  search_volume?: number;
  difficulty?: "low" | "medium" | "high";
  status: "tracking" | "improving" | "dropped" | "achieved";
  notes?: string;
  updated_at: string;
  created_at: string;
}

export interface SocialPost {
  id: string;
  platform: "instagram" | "facebook" | "linkedin" | "twitter" | "youtube";
  caption: string;
  hashtags?: string;
  media_urls?: string[];
  scheduled_at: string;
  published_at?: string;
  status: "draft" | "scheduled" | "published" | "failed";
  reach?: number;
  likes?: number;
  comments?: number;
  shares?: number;
  leads?: number;
  created_by: string;
  created_at: string;
}

export interface Campaign {
  id: string;
  name: string;
  platform: string;
  start_date: string;
  end_date?: string;
  budget: number;
  spend: number;
  leads: number;
  sales: number;
  roi?: number;
  status: "active" | "paused" | "completed";
  created_at: string;
}

// ── PARTNERS ─────────────────────────────────────────────────

export type PartnerType = "distributor" | "reseller";

export interface Partner {
  id: string;
  type: PartnerType;
  company_name: string;
  contact_person: string;
  phone: string;
  email?: string;
  address?: string;
  city?: string;
  state?: string;
  gstin?: string;
  pan?: string;
  credit_limit?: number;
  credit_days?: number;
  outstanding_amount?: number;
  user_ids: string[];
  is_active: boolean;
  created_at: string;
}

// ── DOCUMENTS ────────────────────────────────────────────────

export type DocumentType =
  | "invoice"
  | "coa"
  | "lab_report"
  | "courier_slip"
  | "product_image"
  | "agreement"
  | "expense_receipt"
  | "import_file"
  | "other";

export interface Document {
  id: string;
  name: string;
  type: DocumentType;
  file_url: string;
  file_size: number;
  mime_type: string;
  related_to_type?: "product" | "batch" | "order" | "payment" | "partner" | "expense";
  related_to_id?: string;
  uploaded_by: string;
  created_at: string;
}

// ── NOTIFICATIONS ────────────────────────────────────────────

export interface Notification {
  id: string;
  user_id: string;
  title: string;
  message: string;
  type: "info" | "warning" | "error" | "success";
  read: boolean;
  link?: string;
  created_at: string;
}

// ── ACTIVITY LOG ─────────────────────────────────────────────

export interface ActivityLog {
  id: string;
  user_id: string;
  user?: User;
  action: string;
  entity_type: string;
  entity_id?: string;
  old_values?: Record<string, unknown>;
  new_values?: Record<string, unknown>;
  ip_address?: string;
  user_agent?: string;
  created_at: string;
}

// ── DASHBOARD ────────────────────────────────────────────────

export interface DashboardMetrics {
  today_sales: number;
  month_sales: number;
  pending_orders: number;
  pending_payments: number;
  low_stock_products: number;
  expiring_soon: number;
  top_product: string;
  distributor_sales: number;
  website_leads: number;
  today_attendance: number;
  total_team: number;
  ad_roi: number;
}

export interface SalesChartData {
  date: string;
  online: number;
  offline: number;
  distributor: number;
  marketplace: number;
  total: number;
}

// ── API RESPONSES ────────────────────────────────────────────

export interface ApiResponse<T> {
  data?: T;
  error?: string;
  message?: string;
  count?: number;
}

export interface PaginatedResponse<T> {
  data: T[];
  count: number;
  page: number;
  per_page: number;
  total_pages: number;
}

export interface ImportResult {
  success: number;
  failed: number;
  duplicates: number;
  errors: Array<{ row: number; field: string; message: string }>;
  preview: Record<string, unknown>[];
}
