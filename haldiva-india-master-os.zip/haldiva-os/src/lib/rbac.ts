import type { UserRole, ModuleKey, Permission } from "@/types";

// ============================================================
// HALDIVA INDIA — Role-Based Access Control Matrix
// ============================================================

export const ROLE_PERMISSIONS: Record<UserRole, Permission[]> = {
  // ── CEO — Full unrestricted access ──────────────────────────
  ceo: [
    "dashboard", "inventory", "orders", "finance", "hr",
    "marketing", "partners", "documents", "settings",
    "reports", "marketplace", "seo", "social_media", "users",
  ].map((module) => ({
    module: module as ModuleKey,
    can_view: true,
    can_create: true,
    can_edit: true,
    can_delete: true,
    can_export: true,
  })),

  // ── Mrs. Kriti Gupta — Senior Executive – Office Operations ──
  senior_executive: [
    { module: "dashboard", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: true },
    { module: "inventory", can_view: true, can_create: true, can_edit: true, can_delete: false, can_export: true },
    { module: "orders", can_view: true, can_create: true, can_edit: true, can_delete: false, can_export: true },
    { module: "hr", can_view: true, can_create: true, can_edit: true, can_delete: false, can_export: true },
    { module: "documents", can_view: true, can_create: true, can_edit: true, can_delete: false, can_export: false },
    { module: "reports", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: true },
  ],

  // ── Mr. Deepender Jaiswal — Executive – Data & Support ───────
  data_executive: [
    { module: "dashboard", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: false },
    { module: "inventory", can_view: true, can_create: true, can_edit: true, can_delete: false, can_export: true },
    { module: "orders", can_view: true, can_create: false, can_edit: true, can_delete: false, can_export: true },
    { module: "documents", can_view: true, can_create: true, can_edit: false, can_delete: false, can_export: false },
    { module: "reports", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: true },
  ],

  // ── Mr. Sayan — Digital Marketing Lead ───────────────────────
  digital_marketing: [
    { module: "dashboard", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: false },
    { module: "marketing", can_view: true, can_create: true, can_edit: true, can_delete: true, can_export: true },
    { module: "seo", can_view: true, can_create: true, can_edit: true, can_delete: true, can_export: true },
    { module: "social_media", can_view: true, can_create: true, can_edit: true, can_delete: true, can_export: true },
    { module: "reports", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: true },
  ],

  // ── External Marketplace Agency ───────────────────────────────
  marketplace_agency: [
    { module: "marketplace", can_view: true, can_create: true, can_edit: true, can_delete: false, can_export: true },
    { module: "inventory", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: false },
    { module: "orders", can_view: true, can_create: false, can_edit: true, can_delete: false, can_export: true },
    { module: "reports", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: false },
  ],

  // ── Distributor — S.S. Enterprises ───────────────────────────
  distributor: [
    { module: "partners", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: false },
    { module: "orders", can_view: true, can_create: true, can_edit: false, can_delete: false, can_export: true },
    { module: "inventory", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: false },
    { module: "documents", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: false },
  ],

  // ── Reseller — Nutrition Mantra 360 ──────────────────────────
  reseller: [
    { module: "partners", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: false },
    { module: "orders", can_view: true, can_create: true, can_edit: false, can_delete: false, can_export: true },
    { module: "inventory", can_view: true, can_create: false, can_edit: false, can_delete: false, can_export: false },
  ],
};

export const ROLE_LABELS: Record<UserRole, string> = {
  ceo: "CEO / Founder",
  senior_executive: "Senior Executive",
  data_executive: "Data Executive",
  digital_marketing: "Digital Marketing Lead",
  marketplace_agency: "Marketplace Agency",
  distributor: "Distributor",
  reseller: "Reseller",
};

export function hasPermission(
  role: UserRole,
  module: ModuleKey,
  action: "can_view" | "can_create" | "can_edit" | "can_delete" | "can_export"
): boolean {
  const rolePerms = ROLE_PERMISSIONS[role] || [];
  const modulePerm = rolePerms.find((p) => p.module === module);
  return modulePerm?.[action] ?? false;
}

export function getAccessibleModules(role: UserRole): ModuleKey[] {
  const rolePerms = ROLE_PERMISSIONS[role] || [];
  return rolePerms
    .filter((p) => p.can_view)
    .map((p) => p.module);
}

// Navigation items per role
export interface NavItem {
  label: string;
  href: string;
  icon: string;
  module: ModuleKey;
  badge?: string;
  children?: NavItem[];
}

export const ALL_NAV_ITEMS: NavItem[] = [
  { label: "Dashboard", href: "/dashboard", icon: "LayoutDashboard", module: "dashboard" },
  { label: "Inventory", href: "/inventory", icon: "Package", module: "inventory",
    children: [
      { label: "Products", href: "/inventory/products", icon: "Box", module: "inventory" },
      { label: "Stock Levels", href: "/inventory/stock", icon: "BarChart3", module: "inventory" },
      { label: "Batches", href: "/inventory/batches", icon: "Layers", module: "inventory" },
      { label: "Movements", href: "/inventory/movements", icon: "ArrowLeftRight", module: "inventory" },
      { label: "Import Stock", href: "/inventory/import", icon: "Upload", module: "inventory" },
    ]
  },
  { label: "Orders", href: "/orders", icon: "ShoppingCart", module: "orders",
    children: [
      { label: "All Orders", href: "/orders", icon: "List", module: "orders" },
      { label: "New Order", href: "/orders/new", icon: "Plus", module: "orders" },
      { label: "Dispatch", href: "/orders/dispatch", icon: "Truck", module: "orders" },
      { label: "Returns", href: "/orders/returns", icon: "RotateCcw", module: "orders" },
    ]
  },
  { label: "Finance", href: "/finance", icon: "IndianRupee", module: "finance",
    children: [
      { label: "Overview", href: "/finance", icon: "PieChart", module: "finance" },
      { label: "Income", href: "/finance/income", icon: "TrendingUp", module: "finance" },
      { label: "Expenses", href: "/finance/expenses", icon: "TrendingDown", module: "finance" },
      { label: "Payments", href: "/finance/payments", icon: "CreditCard", module: "finance" },
    ]
  },
  { label: "HR & Team", href: "/hr", icon: "Users", module: "hr",
    children: [
      { label: "Attendance", href: "/hr/attendance", icon: "Clock", module: "hr" },
      { label: "Tasks", href: "/hr/tasks", icon: "CheckSquare", module: "hr" },
      { label: "Team", href: "/hr/team", icon: "UserCheck", module: "hr" },
      { label: "Performance", href: "/hr/performance", icon: "Award", module: "hr" },
    ]
  },
  { label: "Marketing", href: "/marketing", icon: "Megaphone", module: "marketing",
    children: [
      { label: "Overview", href: "/marketing", icon: "BarChart2", module: "marketing" },
      { label: "SEO", href: "/marketing/seo", icon: "Search", module: "seo" },
      { label: "Social Media", href: "/marketing/social", icon: "Share2", module: "social_media" },
      { label: "Campaigns", href: "/marketing/campaigns", icon: "Target", module: "marketing" },
    ]
  },
  { label: "Marketplace", href: "/marketplace", icon: "Store", module: "marketplace",
    children: [
      { label: "Amazon", href: "/marketplace/amazon", icon: "ShoppingBag", module: "marketplace" },
      { label: "Flipkart", href: "/marketplace/flipkart", icon: "ShoppingBag", module: "marketplace" },
      { label: "JioMart", href: "/marketplace/jiomart", icon: "ShoppingBag", module: "marketplace" },
    ]
  },
  { label: "Partners", href: "/partners", icon: "Handshake", module: "partners",
    children: [
      { label: "Distributors", href: "/partners/distributors", icon: "Truck", module: "partners" },
      { label: "Resellers", href: "/partners/resellers", icon: "Store", module: "partners" },
    ]
  },
  { label: "Documents", href: "/documents", icon: "FolderOpen", module: "documents" },
  { label: "Reports", href: "/reports", icon: "FileBarChart", module: "reports" },
  { label: "Settings", href: "/settings", icon: "Settings", module: "settings" },
  { label: "Users", href: "/settings/users", icon: "UserCog", module: "users" },
];
