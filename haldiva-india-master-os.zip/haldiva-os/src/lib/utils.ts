import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, formatDistanceToNow, parseISO, isAfter, isBefore, addDays } from "date-fns";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// ── FORMATTING ───────────────────────────────────────────────

export function formatCurrency(amount: number): string {
  return new Intl.NumberFormat("en-IN", {
    style: "currency",
    currency: "INR",
    minimumFractionDigits: 0,
    maximumFractionDigits: 0,
  }).format(amount);
}

export function formatNumber(num: number): string {
  return new Intl.NumberFormat("en-IN").format(num);
}

export function formatDate(date: string | Date, fmt = "dd MMM yyyy"): string {
  const d = typeof date === "string" ? parseISO(date) : date;
  return format(d, fmt);
}

export function formatDateTime(date: string | Date): string {
  const d = typeof date === "string" ? parseISO(date) : date;
  return format(d, "dd MMM yyyy, hh:mm a");
}

export function timeAgo(date: string | Date): string {
  const d = typeof date === "string" ? parseISO(date) : date;
  return formatDistanceToNow(d, { addSuffix: true });
}

export function formatPercentage(value: number, decimals = 1): string {
  return `${value.toFixed(decimals)}%`;
}

export function formatFileSize(bytes: number): string {
  if (bytes === 0) return "0 Bytes";
  const k = 1024;
  const sizes = ["Bytes", "KB", "MB", "GB"];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
}

// ── STOCK & ALERTS ───────────────────────────────────────────

export function isLowStock(current: number, reorderLevel: number): boolean {
  return current <= reorderLevel;
}

export function isExpiringWithin(expDate: string, days = 30): boolean {
  const exp = parseISO(expDate);
  const threshold = addDays(new Date(), days);
  return isBefore(exp, threshold) && isAfter(exp, new Date());
}

export function isExpired(expDate: string): boolean {
  return isBefore(parseISO(expDate), new Date());
}

// ── ORDER HELPERS ────────────────────────────────────────────

export function generateOrderNumber(): string {
  const date = format(new Date(), "yyyyMMdd");
  const random = Math.floor(Math.random() * 9000) + 1000;
  return `HLD-${date}-${random}`;
}

export function calculateOrderTotal(
  items: Array<{ selling_price: number; quantity: number; discount: number; gst_rate: number }>
) {
  const subtotal = items.reduce((sum, item) => sum + item.selling_price * item.quantity, 0);
  const discount_total = items.reduce((sum, item) => sum + item.discount * item.quantity, 0);
  const taxable = subtotal - discount_total;
  const gst_total = items.reduce(
    (sum, item) =>
      sum +
      ((item.selling_price - item.discount) * item.quantity * item.gst_rate) / 100,
    0
  );
  return { subtotal, discount_total, gst_total, total: taxable + gst_total };
}

// ── GST ──────────────────────────────────────────────────────

export function calculateGST(
  amount: number,
  gstRate: number,
  inclusive = false
): { baseAmount: number; gstAmount: number; total: number } {
  if (inclusive) {
    const baseAmount = (amount * 100) / (100 + gstRate);
    const gstAmount = amount - baseAmount;
    return { baseAmount, gstAmount, total: amount };
  } else {
    const gstAmount = (amount * gstRate) / 100;
    return { baseAmount: amount, gstAmount, total: amount + gstAmount };
  }
}

// ── EXPORT HELPERS ───────────────────────────────────────────

export function downloadCSV(data: Record<string, unknown>[], filename: string) {
  if (!data.length) return;
  const headers = Object.keys(data[0]);
  const csvContent = [
    headers.join(","),
    ...data.map((row) =>
      headers
        .map((h) => {
          const val = row[h];
          const str = val === null || val === undefined ? "" : String(val);
          return str.includes(",") ? `"${str}"` : str;
        })
        .join(",")
    ),
  ].join("\n");

  const blob = new Blob([csvContent], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.href = url;
  link.download = `${filename}-${format(new Date(), "yyyy-MM-dd")}.csv`;
  link.click();
  URL.revokeObjectURL(url);
}

// ── VALIDATION ───────────────────────────────────────────────

export function isValidGSTIN(gstin: string): boolean {
  const pattern = /^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$/;
  return pattern.test(gstin);
}

export function isValidPhone(phone: string): boolean {
  return /^[6-9]\d{9}$/.test(phone.replace(/\s/g, ""));
}

export function isValidPAN(pan: string): boolean {
  return /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/.test(pan);
}

// ── MISC ─────────────────────────────────────────────────────

export function generateSKU(productName: string, category: string): string {
  const prefix = category.substring(0, 3).toUpperCase();
  const name = productName.replace(/\s+/g, "").substring(0, 3).toUpperCase();
  const num = Math.floor(Math.random() * 900) + 100;
  return `HLD-${prefix}-${name}-${num}`;
}

export function slugify(text: string): string {
  return text.toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-]/g, "");
}

export function truncate(text: string, length = 50): string {
  return text.length > length ? text.substring(0, length) + "..." : text;
}

export function getInitials(name: string): string {
  return name
    .split(" ")
    .map((w) => w[0])
    .join("")
    .toUpperCase()
    .substring(0, 2);
}

export const CHANNELS = {
  online: ["shopify", "shopdeck", "amazon", "flipkart", "jiomart", "ondc"],
  offline: ["direct", "walkin", "society", "event", "reference"],
  b2b: ["distributor", "reseller", "corporate", "bulk", "horeca"],
};

export const STATUS_COLORS: Record<string, string> = {
  new: "bg-blue-100 text-blue-800",
  confirmed: "bg-indigo-100 text-indigo-800",
  packed: "bg-purple-100 text-purple-800",
  dispatched: "bg-orange-100 text-orange-800",
  delivered: "bg-green-100 text-green-800",
  pending_payment: "bg-yellow-100 text-yellow-800",
  cancelled: "bg-red-100 text-red-800",
  returned: "bg-gray-100 text-gray-800",
  paid: "bg-green-100 text-green-800",
  pending: "bg-yellow-100 text-yellow-800",
  partial: "bg-orange-100 text-orange-800",
  active: "bg-green-100 text-green-800",
  paused: "bg-yellow-100 text-yellow-800",
  completed: "bg-blue-100 text-blue-800",
};
