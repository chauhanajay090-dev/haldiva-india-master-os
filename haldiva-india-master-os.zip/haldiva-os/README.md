# 🌟 HALDIVA INDIA — Master Business OS

> **Premium Enterprise ERP + CRM + Inventory + HR + Marketing Platform**  
> Custom-built for HALDIVA INDIA — A Golden Touch to a Healthy Life

---

## 🏢 Company Details

| Field | Value |
|-------|-------|
| **Company** | HALDIVA INDIA |
| **Website** | [haldivaindia.com](https://haldivaindia.com) |
| **FSSAI** | 22725441001672 |
| **Address** | Gaur City Center, Greater Noida West — 201306 |
| **Phone** | 0120 516 3005 |
| **Email** | care@haldivaindia.in |

---

## 🚀 What's Inside

### Modules

| Module | Description | Access |
|--------|-------------|--------|
| **CEO Dashboard** | Real-time KPIs, charts, team overview | CEO Only |
| **Inventory Master** | 18 SKUs, all stock types, batch tracking | CEO + Executives |
| **Orders & Dispatch** | B2C, B2B, Marketplace, Distributor orders | CEO + Executives |
| **Finance** | P&L, expenses, payment recovery | CEO + Kriti |
| **HR & Team** | Attendance, tasks, performance | CEO + All team |
| **Marketing** | SEO, Social, Campaigns, ROI | CEO + Sayan |
| **Partner Portal** | Distributor + Reseller dashboards | Partners only see own data |
| **Marketplace** | Amazon, Flipkart, JioMart management | CEO + Agency |
| **Documents** | File management with upload | CEO + Staff |
| **Reports** | 9 report types, CSV/PDF export | Role-based |
| **User Management** | RBAC, 2FA, audit logs | CEO Only |

### Tech Stack

- **Frontend**: Next.js 14 + TypeScript + Tailwind CSS
- **Backend**: Supabase (PostgreSQL + Auth + Storage)
- **Charts**: Recharts
- **Tables**: TanStack Table
- **Fonts**: Cormorant Garamond (display) + Sora (body) + JetBrains Mono (code)
- **Deployment**: Vercel

---

## 👥 User Roles & Demo Credentials

| Role | Email | Password | Access |
|------|-------|----------|--------|
| **CEO** | ceo@haldiva.com | HALDIVA@CEO2026 | Everything — Full control |
| **Senior Executive (Kriti)** | kriti@haldiva.com | Kriti@2026 | Dashboard, Inventory, Orders, HR, Documents, Reports |
| **Data Executive (Deepender)** | deepender@haldiva.com | Deep@2026 | Dashboard, Inventory, Orders, Documents, Reports |
| **Digital Marketing (Sayan)** | sayan@haldiva.com | Sayan@2026 | Dashboard, Marketing, SEO, Social, Reports |
| **Marketplace Agency** | agency@haldiva.com | Agency@2026 | Marketplace, Inventory View, Orders View |
| **Distributor (S.S. Ent.)** | dist@sse.com | Dist@2026 | Partner portal, own orders only |
| **Reseller (NM360)** | reseller@nm360.com | Resell@2026 | Catalog, own orders only |

---

## 📦 Project Structure

```
haldiva-os/
├── src/
│   ├── app/
│   │   ├── auth/login/          # Secure login page
│   │   ├── dashboard/           # CEO dashboard
│   │   ├── inventory/           # Inventory management
│   │   ├── orders/              # Order management
│   │   ├── finance/             # Finance & P&L
│   │   ├── hr/                  # Attendance & Tasks
│   │   ├── marketing/           # SEO, Social, Campaigns
│   │   ├── partners/            # Distributor/Reseller portal
│   │   ├── marketplace/         # Amazon, Flipkart, JioMart
│   │   ├── documents/           # File management
│   │   ├── reports/             # Reports & exports
│   │   └── settings/users/      # User management (CEO only)
│   ├── components/
│   │   ├── ui/                  # Reusable UI components
│   │   ├── layout/              # Sidebar, topbar, navigation
│   │   └── modules/             # Feature-specific components
│   ├── lib/
│   │   ├── supabase.ts          # Database clients
│   │   ├── rbac.ts              # Role permissions
│   │   └── utils.ts             # Utility functions
│   ├── types/index.ts           # Complete TypeScript types
│   └── middleware.ts            # Auth middleware
├── supabase/migrations/         # Database schema
├── public/manifest.json         # PWA manifest
├── package.json
├── next.config.ts
├── tailwind.config.ts
├── tsconfig.json
├── vercel.json
└── .env.example
```

---

## ⚙️ Setup & Deployment

### Prerequisites
- Node.js 18+
- npm or yarn
- Supabase account
- Vercel account

### Step 1: Clone and Install
```bash
git clone <your-repo>
cd haldiva-os
npm install
```

### Step 2: Setup Supabase

1. Go to [supabase.com](https://supabase.com) and create a new project
2. Go to **SQL Editor** and run the migration file:
   ```
   supabase/migrations/001_initial_schema.sql
   ```
3. Go to **Authentication > Settings** and configure:
   - Email auth enabled
   - Disable email confirmation for internal use
4. Create users in **Authentication > Users**:
   - ceo@haldiva.com
   - kriti@haldiva.com
   - deepender@haldiva.com
   - sayan@haldiva.com
   - dist@sse.com
   - reseller@nm360.com
5. After creating auth users, uncomment and run the INSERT block at the bottom of the SQL file

### Step 3: Environment Variables
```bash
cp .env.example .env.local
```
Fill in your Supabase URL and keys from Project Settings > API.

### Step 4: Run Locally
```bash
npm run dev
```
Visit [http://localhost:3000](http://localhost:3000)

### Step 5: Deploy to Vercel
```bash
# Install Vercel CLI
npm i -g vercel

# Deploy
vercel

# Set environment variables on Vercel dashboard or via CLI:
vercel env add NEXT_PUBLIC_SUPABASE_URL
vercel env add NEXT_PUBLIC_SUPABASE_ANON_KEY
vercel env add SUPABASE_SERVICE_ROLE_KEY
```

---

## 🔒 Security Features

- **Row Level Security (RLS)** — Database-level access isolation per role
- **Supabase Auth** — Secure JWT-based authentication
- **CEO 2FA** — Two-factor authentication for CEO account
- **Session Management** — Auto-timeout after 30 minutes
- **Rate Limiting** — 5 failed attempts = 15-minute lockout
- **Audit Logs** — All actions logged with timestamp and user
- **RBAC** — Hidden modules + protected API routes
- **HTTPS** — Enforced on Vercel

---

## 📱 PWA Installation

The app works as an installable Progressive Web App:

**On iPhone/iPad:**
1. Open in Safari
2. Tap Share → Add to Home Screen

**On Android:**
1. Open in Chrome
2. Tap ⋮ → Install App

**On Windows/Mac:**
1. Open in Chrome/Edge
2. Click install icon in address bar

---

## 🗂 Stock Types Tracked

| Type | Description |
|------|-------------|
| Warehouse | Main warehouse / storage |
| Office | At office premises |
| Online | Allocated for online orders |
| Offline | For walk-in / offline sales |
| Distributor | At distributor location |
| Reseller | With reseller partners |
| Sample | Sample stock for trials |
| Gifting | Corporate gifting stock |
| Damaged | Damaged / unusable |
| Expired | Past expiry date |
| Returned | Returned by customers |

## 📊 Sales Channels

**Online:** Shopify, Shopdeck, Amazon, Flipkart, JioMart, ONDC  
**Offline:** Direct, Walk-in, Society Sale, Events, Reference  
**B2B:** Distributor, Reseller, Corporate Gifting, Bulk, HoReCa

---

## 🏷 Product SKUs

| SKU | Product |
|-----|---------|
| HLD-H-001 | Phool Ras Honey — 100% Pure Raw |
| HLD-H-002 | Amrit Honey — Ashwagandha 150ml |
| HLD-H-003 | Amrit Honey — Turmeric 150ml |
| HLD-H-004 | Shilajit Honey 150g |
| HLD-H-005 | Ginger Honey 150g |
| HLD-G-001 | A2 Gir Cow Heritage Ghee |
| HLD-G-002 | Sahiwal Desi Ghee A2 Bilona |
| HLD-S-001 | Turmeric Powder 100g |
| HLD-S-002 | Haldi Doodh Masala 100g |
| HLD-S-003 | Masala Tea — Authentic Chai 80g |
| HLD-O-001 | Black Mustard Oil — Wood Pressed |
| HLD-C-001 | Millet Coconut Cookies |
| HLD-SN-001 | Fox Nut Snacks (Makhana) |
| HLD-CB-001 | Royal Festive Gift Duo |
| HLD-CB-002 | Heart-Healthy Kitchen Duo |
| HLD-HMP-001 | Premium Ghee Lover Box |
| HLD-HMP-002 | Complete Mini Wellness Box |
| HLD-HMP-003 | Daily Wellness Duo |

---

## 📞 Support

**HALDIVA INDIA**  
📞 0120 516 3005  
✉ care@haldivaindia.in  
🌐 [haldivaindia.com](https://haldivaindia.com)  
📍 Gaur City Center, Greater Noida West — 201306

---

*HALDIVA INDIA Master Business OS v1.0 — "A Golden Touch to a Healthy Life"*
