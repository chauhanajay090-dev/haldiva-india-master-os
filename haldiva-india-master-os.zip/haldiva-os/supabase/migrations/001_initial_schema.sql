-- ============================================================
-- HALDIVA INDIA MASTER OS — Complete Database Schema
-- Run in Supabase SQL Editor
-- ============================================================

-- Enable necessary extensions
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pg_trgm";

-- ── ENUMS ────────────────────────────────────────────────────

CREATE TYPE user_role AS ENUM (
  'ceo', 'senior_executive', 'data_executive',
  'digital_marketing', 'marketplace_agency', 'distributor', 'reseller'
);

CREATE TYPE stock_type AS ENUM (
  'warehouse', 'office', 'online', 'offline', 'distributor',
  'reseller', 'sample', 'gifting', 'damaged', 'expired', 'returned'
);

CREATE TYPE order_type AS ENUM (
  'b2c_online', 'b2c_offline', 'distributor', 'reseller',
  'corporate_gifting', 'bulk', 'event', 'marketplace'
);

CREATE TYPE order_status AS ENUM (
  'new', 'confirmed', 'packed', 'dispatched', 'delivered',
  'pending_payment', 'cancelled', 'returned'
);

CREATE TYPE payment_status AS ENUM (
  'pending', 'partial', 'paid', 'refunded'
);

CREATE TYPE channel AS ENUM (
  'shopify', 'shopdeck', 'amazon', 'flipkart', 'jiomart', 'ondc',
  'direct', 'walkin', 'society', 'event', 'reference',
  'distributor', 'reseller', 'corporate', 'bulk', 'horeca'
);

CREATE TYPE attendance_status AS ENUM (
  'present', 'absent', 'late', 'leave', 'half_day', 'wfh', 'overtime'
);

CREATE TYPE task_priority AS ENUM ('low', 'medium', 'high', 'urgent');
CREATE TYPE task_status AS ENUM ('todo', 'in_progress', 'review', 'done', 'cancelled');
CREATE TYPE partner_type AS ENUM ('distributor', 'reseller');
CREATE TYPE document_type AS ENUM (
  'invoice', 'coa', 'lab_report', 'courier_slip', 'product_image',
  'agreement', 'expense_receipt', 'import_file', 'other'
);

-- ── USERS ─────────────────────────────────────────────────────

CREATE TABLE public.users (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  role user_role NOT NULL DEFAULT 'data_executive',
  department TEXT,
  phone TEXT,
  avatar_url TEXT,
  partner_id UUID, -- For distributors/resellers, links to their partner record
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  two_fa_enabled BOOLEAN NOT NULL DEFAULT FALSE,
  last_login TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── ACTIVITY LOGS ─────────────────────────────────────────────

CREATE TABLE public.activity_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id),
  action TEXT NOT NULL,
  entity_type TEXT NOT NULL,
  entity_id UUID,
  old_values JSONB,
  new_values JSONB,
  ip_address INET,
  user_agent TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_activity_logs_user ON public.activity_logs(user_id);
CREATE INDEX idx_activity_logs_entity ON public.activity_logs(entity_type, entity_id);
CREATE INDEX idx_activity_logs_created ON public.activity_logs(created_at DESC);

-- ── NOTIFICATIONS ─────────────────────────────────────────────

CREATE TABLE public.notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.users(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'info',
  read BOOLEAN NOT NULL DEFAULT FALSE,
  link TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_notifications_user ON public.notifications(user_id, read);

-- ── CATEGORIES ────────────────────────────────────────────────

CREATE TABLE public.categories (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  parent_id UUID REFERENCES public.categories(id),
  slug TEXT UNIQUE NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

INSERT INTO public.categories (name, slug) VALUES
  ('Honey', 'honey'),
  ('Ghee', 'ghee'),
  ('Spices', 'spices'),
  ('Oils', 'oils'),
  ('Cookies', 'cookies'),
  ('Snacks', 'snacks'),
  ('Combos', 'combos'),
  ('Hampers', 'hampers');

-- ── SUPPLIERS ─────────────────────────────────────────────────

CREATE TABLE public.suppliers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  contact_person TEXT,
  phone TEXT,
  email TEXT,
  address TEXT,
  gstin TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── PRODUCTS ─────────────────────────────────────────────────

CREATE TABLE public.products (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  sku TEXT UNIQUE NOT NULL,
  barcode TEXT,
  category_id UUID REFERENCES public.categories(id),
  supplier_id UUID REFERENCES public.suppliers(id),
  description TEXT,
  mrp NUMERIC(10,2) NOT NULL DEFAULT 0,
  cost_price NUMERIC(10,2) NOT NULL DEFAULT 0,
  selling_price NUMERIC(10,2) NOT NULL DEFAULT 0,
  gst_rate NUMERIC(5,2) NOT NULL DEFAULT 0,
  hsn_code TEXT,
  unit TEXT NOT NULL DEFAULT 'pcs',
  reorder_level INT NOT NULL DEFAULT 10,
  storage_location TEXT,
  coa_status TEXT NOT NULL DEFAULT 'pending',
  lab_report_status TEXT NOT NULL DEFAULT 'pending',
  image_url TEXT,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_products_sku ON public.products(sku);
CREATE INDEX idx_products_category ON public.products(category_id);
CREATE INDEX idx_products_active ON public.products(is_active);
CREATE INDEX idx_products_name_search ON public.products USING gin(name gin_trgm_ops);

-- Insert real HALDIVA INDIA products
INSERT INTO public.products (name, sku, category_id, mrp, cost_price, selling_price, gst_rate, unit, reorder_level, image_url, is_active) VALUES
  ('Phool Ras Honey — 100% Pure Raw', 'HLD-H-001', (SELECT id FROM categories WHERE slug='honey'), 299, 120, 249, 0, 'jar', 60, 'https://haldivaindia.com/cdn/shop/files/honey.jpg', true),
  ('Amrit Honey — Ashwagandha 150ml', 'HLD-H-002', (SELECT id FROM categories WHERE slug='honey'), 349, 140, 280, 0, 'jar', 50, null, true),
  ('Amrit Honey — Turmeric 150ml', 'HLD-H-003', (SELECT id FROM categories WHERE slug='honey'), 299, 120, 249, 0, 'jar', 40, null, true),
  ('Shilajit Honey 150g', 'HLD-H-004', (SELECT id FROM categories WHERE slug='honey'), 449, 160, 380, 0, 'jar', 35, null, true),
  ('Ginger Honey 150g', 'HLD-H-005', (SELECT id FROM categories WHERE slug='honey'), 349, 130, 280, 0, 'jar', 35, null, true),
  ('A2 Gir Cow Heritage Ghee', 'HLD-G-001', (SELECT id FROM categories WHERE slug='ghee'), 499, 200, 399, 5, 'jar', 30, null, true),
  ('Sahiwal Desi Ghee A2 Bilona', 'HLD-G-002', (SELECT id FROM categories WHERE slug='ghee'), 899, 380, 740, 5, 'jar', 20, null, true),
  ('Turmeric Powder 100g', 'HLD-S-001', (SELECT id FROM categories WHERE slug='spices'), 449, 150, 365, 5, 'pkt', 60, null, true),
  ('Haldi Doodh Masala 100g', 'HLD-S-002', (SELECT id FROM categories WHERE slug='spices'), 449, 160, 385, 5, 'pkt', 50, null, true),
  ('Masala Tea — Authentic Chai 80g', 'HLD-S-003', (SELECT id FROM categories WHERE slug='spices'), 449, 155, 385, 5, 'box', 40, null, true),
  ('Black Mustard Oil — Wood Pressed', 'HLD-O-001', (SELECT id FROM categories WHERE slug='oils'), 149, 60, 115, 0, 'btl', 30, null, true),
  ('Millet Coconut Cookies', 'HLD-C-001', (SELECT id FROM categories WHERE slug='cookies'), 220, 80, 180, 12, 'pkt', 50, null, true),
  ('Fox Nut Snacks (Makhana)', 'HLD-SN-001', (SELECT id FROM categories WHERE slug='snacks'), 280, 100, 220, 12, 'pkt', 40, null, true),
  ('Royal Festive Gift Duo', 'HLD-CB-001', (SELECT id FROM categories WHERE slug='combos'), 1999, 700, 1629, 5, 'set', 15, null, true),
  ('Heart-Healthy Kitchen Duo', 'HLD-CB-002', (SELECT id FROM categories WHERE slug='combos'), 1199, 450, 979, 5, 'set', 15, null, true),
  ('Premium Ghee Lover Box', 'HLD-HMP-001', (SELECT id FROM categories WHERE slug='hampers'), 1999, 800, 1649, 5, 'box', 10, null, true),
  ('Complete Mini Wellness Box', 'HLD-HMP-002', (SELECT id FROM categories WHERE slug='hampers'), 899, 380, 763, 5, 'box', 10, null, true),
  ('Daily Wellness Duo', 'HLD-HMP-003', (SELECT id FROM categories WHERE slug='hampers'), 799, 320, 648, 5, 'set', 15, null, true);

-- ── PRODUCT BATCHES ───────────────────────────────────────────

CREATE TABLE public.product_batches (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID NOT NULL REFERENCES public.products(id),
  batch_number TEXT NOT NULL,
  mfg_date DATE NOT NULL,
  exp_date DATE NOT NULL,
  quantity INT NOT NULL DEFAULT 0,
  remaining_quantity INT NOT NULL DEFAULT 0,
  cost_price NUMERIC(10,2) NOT NULL DEFAULT 0,
  supplier_id UUID REFERENCES public.suppliers(id),
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(product_id, batch_number)
);

CREATE INDEX idx_batches_product ON public.product_batches(product_id);
CREATE INDEX idx_batches_expiry ON public.product_batches(exp_date);

-- ── INVENTORY / STOCK ─────────────────────────────────────────

CREATE TABLE public.inventory (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID NOT NULL REFERENCES public.products(id),
  stock_type stock_type NOT NULL,
  quantity INT NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(product_id, stock_type)
);

-- Initialize inventory for all products with sample data
INSERT INTO public.inventory (product_id, stock_type, quantity)
SELECT p.id, st.stock_type, st.qty
FROM public.products p
CROSS JOIN (VALUES
  ('warehouse'::stock_type, 100),
  ('office'::stock_type, 50),
  ('online'::stock_type, 80),
  ('offline'::stock_type, 30),
  ('distributor'::stock_type, 40),
  ('reseller'::stock_type, 20),
  ('sample'::stock_type, 10),
  ('gifting'::stock_type, 5),
  ('damaged'::stock_type, 2),
  ('returned'::stock_type, 3)
) AS st(stock_type, qty);

-- ── INVENTORY MOVEMENTS ───────────────────────────────────────

CREATE TABLE public.inventory_movements (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID NOT NULL REFERENCES public.products(id),
  batch_id UUID REFERENCES public.product_batches(id),
  movement_type TEXT NOT NULL, -- 'in', 'out', 'transfer', 'adjustment'
  from_type stock_type,
  to_type stock_type,
  quantity INT NOT NULL,
  reference_id UUID,
  reference_type TEXT,
  notes TEXT,
  created_by UUID REFERENCES public.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_movements_product ON public.inventory_movements(product_id);
CREATE INDEX idx_movements_created ON public.inventory_movements(created_at DESC);

-- ── CHANNEL STOCK ALLOCATION ──────────────────────────────────

CREATE TABLE public.channel_stock (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  product_id UUID NOT NULL REFERENCES public.products(id),
  channel channel NOT NULL,
  opening_stock INT NOT NULL DEFAULT 0,
  allocated_stock INT NOT NULL DEFAULT 0,
  sold_stock INT NOT NULL DEFAULT 0,
  returned_stock INT NOT NULL DEFAULT 0,
  pending_dispatch INT NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(product_id, channel)
);

-- ── CUSTOMERS ─────────────────────────────────────────────────

CREATE TABLE public.customers (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  pincode TEXT,
  gstin TEXT,
  total_orders INT DEFAULT 0,
  total_spent NUMERIC(12,2) DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_customers_phone ON public.customers(phone);

-- ── PARTNERS ─────────────────────────────────────────────────

CREATE TABLE public.partners (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  type partner_type NOT NULL,
  company_name TEXT NOT NULL,
  contact_person TEXT NOT NULL,
  phone TEXT NOT NULL,
  email TEXT,
  address TEXT,
  city TEXT,
  state TEXT,
  gstin TEXT,
  pan TEXT,
  credit_limit NUMERIC(12,2) DEFAULT 0,
  credit_days INT DEFAULT 30,
  outstanding_amount NUMERIC(12,2) DEFAULT 0,
  is_active BOOLEAN NOT NULL DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Insert real partners
INSERT INTO public.partners (type, company_name, contact_person, phone, city, state) VALUES
  ('distributor', 'S.S. Enterprises', 'Mr. Sudeep Dubey', '9876543210', 'Lucknow', 'Uttar Pradesh'),
  ('reseller', 'Nutrition Mantra 360', 'Dt. Parul Tripathi', '9123456789', 'Delhi', 'Delhi');

-- ── ORDERS ────────────────────────────────────────────────────

CREATE TABLE public.orders (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_number TEXT UNIQUE NOT NULL,
  order_type order_type NOT NULL,
  channel channel NOT NULL,
  customer_id UUID REFERENCES public.customers(id),
  partner_id UUID REFERENCES public.partners(id),
  status order_status NOT NULL DEFAULT 'new',
  payment_status payment_status NOT NULL DEFAULT 'pending',
  subtotal NUMERIC(12,2) NOT NULL DEFAULT 0,
  discount_total NUMERIC(12,2) NOT NULL DEFAULT 0,
  gst_total NUMERIC(12,2) NOT NULL DEFAULT 0,
  shipping_charge NUMERIC(10,2) NOT NULL DEFAULT 0,
  total NUMERIC(12,2) NOT NULL DEFAULT 0,
  amount_paid NUMERIC(12,2) NOT NULL DEFAULT 0,
  amount_due NUMERIC(12,2) NOT NULL DEFAULT 0,
  courier_name TEXT,
  tracking_id TEXT,
  dispatch_date DATE,
  delivery_date DATE,
  expected_delivery DATE,
  invoice_number TEXT,
  marketplace_order_id TEXT,
  notes TEXT,
  created_by UUID REFERENCES public.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_orders_number ON public.orders(order_number);
CREATE INDEX idx_orders_status ON public.orders(status);
CREATE INDEX idx_orders_channel ON public.orders(channel);
CREATE INDEX idx_orders_created ON public.orders(created_at DESC);
CREATE INDEX idx_orders_customer ON public.orders(customer_id);
CREATE INDEX idx_orders_partner ON public.orders(partner_id);

-- ── ORDER ITEMS ───────────────────────────────────────────────

CREATE TABLE public.order_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID NOT NULL REFERENCES public.orders(id) ON DELETE CASCADE,
  product_id UUID NOT NULL REFERENCES public.products(id),
  batch_id UUID REFERENCES public.product_batches(id),
  quantity INT NOT NULL,
  mrp NUMERIC(10,2) NOT NULL,
  selling_price NUMERIC(10,2) NOT NULL,
  discount NUMERIC(10,2) NOT NULL DEFAULT 0,
  gst_rate NUMERIC(5,2) NOT NULL DEFAULT 0,
  gst_amount NUMERIC(10,2) NOT NULL DEFAULT 0,
  total NUMERIC(12,2) NOT NULL
);

CREATE INDEX idx_order_items_order ON public.order_items(order_id);
CREATE INDEX idx_order_items_product ON public.order_items(product_id);

-- ── PAYMENTS ─────────────────────────────────────────────────

CREATE TABLE public.payments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  order_id UUID REFERENCES public.orders(id),
  partner_id UUID REFERENCES public.partners(id),
  amount NUMERIC(12,2) NOT NULL,
  payment_method TEXT NOT NULL,
  transaction_id TEXT,
  payment_date DATE NOT NULL,
  notes TEXT,
  created_by UUID REFERENCES public.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── EXPENSES ─────────────────────────────────────────────────

CREATE TABLE public.expenses (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  category TEXT NOT NULL,
  description TEXT NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  gst_amount NUMERIC(10,2),
  vendor TEXT,
  invoice_number TEXT,
  expense_date DATE NOT NULL,
  document_url TEXT,
  created_by UUID REFERENCES public.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_expenses_date ON public.expenses(expense_date DESC);
CREATE INDEX idx_expenses_category ON public.expenses(category);

-- ── INCOME ENTRIES ────────────────────────────────────────────

CREATE TABLE public.income_entries (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  source TEXT NOT NULL,
  description TEXT NOT NULL,
  amount NUMERIC(12,2) NOT NULL,
  date DATE NOT NULL,
  reference TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── ATTENDANCE ────────────────────────────────────────────────

CREATE TABLE public.attendance (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES public.users(id),
  date DATE NOT NULL,
  check_in TIME,
  check_out TIME,
  status attendance_status NOT NULL DEFAULT 'present',
  late_by_minutes INT,
  overtime_minutes INT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  UNIQUE(user_id, date)
);

CREATE INDEX idx_attendance_user_date ON public.attendance(user_id, date DESC);
CREATE INDEX idx_attendance_date ON public.attendance(date DESC);

-- ── TASKS ─────────────────────────────────────────────────────

CREATE TABLE public.tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title TEXT NOT NULL,
  description TEXT,
  assigned_to UUID NOT NULL REFERENCES public.users(id),
  assigned_by UUID NOT NULL REFERENCES public.users(id),
  priority task_priority NOT NULL DEFAULT 'medium',
  status task_status NOT NULL DEFAULT 'todo',
  progress INT NOT NULL DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
  deadline TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_tasks_assigned_to ON public.tasks(assigned_to);
CREATE INDEX idx_tasks_status ON public.tasks(status);
CREATE INDEX idx_tasks_deadline ON public.tasks(deadline);

CREATE TABLE public.task_comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  task_id UUID NOT NULL REFERENCES public.tasks(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES public.users(id),
  comment TEXT NOT NULL,
  progress_update INT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── SEO KEYWORDS ──────────────────────────────────────────────

CREATE TABLE public.seo_keywords (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  keyword TEXT NOT NULL,
  target_url TEXT,
  current_rank INT,
  previous_rank INT,
  search_volume INT,
  difficulty TEXT,
  status TEXT NOT NULL DEFAULT 'tracking',
  notes TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Insert real keywords
INSERT INTO public.seo_keywords (keyword, target_url, current_rank, previous_rank, search_volume, difficulty, status) VALUES
  ('pure raw honey India buy online', '/products/honey', 4, 7, 18000, 'medium', 'improving'),
  ('haldiva india', '/', 1, 1, 2100, 'low', 'achieved'),
  ('a2 gir cow ghee online', '/products/ghee', 6, 10, 28000, 'high', 'improving'),
  ('ashwagandha honey benefits', '/products/honey', 3, 5, 9400, 'medium', 'improving'),
  ('haldi doodh masala powder', '/products/spices', 2, 3, 6800, 'low', 'achieved'),
  ('cold pressed mustard oil buy', '/products/oils', 9, 14, 34000, 'high', 'improving'),
  ('shilajit honey online India', '/products/honey', 5, 8, 7200, 'medium', 'improving'),
  ('bilona ghee sahiwal cow', '/products/ghee', 2, 4, 4500, 'low', 'achieved');

-- ── SOCIAL POSTS ──────────────────────────────────────────────

CREATE TABLE public.social_posts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  platform TEXT NOT NULL,
  caption TEXT NOT NULL,
  hashtags TEXT,
  media_urls TEXT[],
  scheduled_at TIMESTAMPTZ NOT NULL,
  published_at TIMESTAMPTZ,
  status TEXT NOT NULL DEFAULT 'draft',
  reach INT,
  likes INT,
  comments INT,
  shares INT,
  leads INT,
  created_by UUID REFERENCES public.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── CAMPAIGNS ─────────────────────────────────────────────────

CREATE TABLE public.campaigns (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  platform TEXT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE,
  budget NUMERIC(12,2) NOT NULL DEFAULT 0,
  spend NUMERIC(12,2) NOT NULL DEFAULT 0,
  leads INT NOT NULL DEFAULT 0,
  sales NUMERIC(12,2) NOT NULL DEFAULT 0,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ── DOCUMENTS ─────────────────────────────────────────────────

CREATE TABLE public.documents (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name TEXT NOT NULL,
  type document_type NOT NULL DEFAULT 'other',
  file_url TEXT NOT NULL,
  file_size BIGINT NOT NULL DEFAULT 0,
  mime_type TEXT NOT NULL,
  related_to_type TEXT,
  related_to_id UUID,
  uploaded_by UUID REFERENCES public.users(id),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_documents_related ON public.documents(related_to_type, related_to_id);

-- ── VIEWS ─────────────────────────────────────────────────────

-- Stock summary view
CREATE OR REPLACE VIEW public.stock_summary AS
SELECT
  p.id as product_id,
  p.name,
  p.sku,
  p.reorder_level,
  COALESCE(SUM(CASE WHEN i.stock_type = 'warehouse' THEN i.quantity ELSE 0 END), 0) as warehouse,
  COALESCE(SUM(CASE WHEN i.stock_type = 'office' THEN i.quantity ELSE 0 END), 0) as office,
  COALESCE(SUM(CASE WHEN i.stock_type = 'online' THEN i.quantity ELSE 0 END), 0) as online,
  COALESCE(SUM(CASE WHEN i.stock_type = 'offline' THEN i.quantity ELSE 0 END), 0) as offline,
  COALESCE(SUM(CASE WHEN i.stock_type = 'distributor' THEN i.quantity ELSE 0 END), 0) as distributor,
  COALESCE(SUM(CASE WHEN i.stock_type = 'reseller' THEN i.quantity ELSE 0 END), 0) as reseller,
  COALESCE(SUM(CASE WHEN i.stock_type = 'sample' THEN i.quantity ELSE 0 END), 0) as sample,
  COALESCE(SUM(CASE WHEN i.stock_type = 'gifting' THEN i.quantity ELSE 0 END), 0) as gifting,
  COALESCE(SUM(CASE WHEN i.stock_type = 'damaged' THEN i.quantity ELSE 0 END), 0) as damaged,
  COALESCE(SUM(CASE WHEN i.stock_type = 'expired' THEN i.quantity ELSE 0 END), 0) as expired,
  COALESCE(SUM(CASE WHEN i.stock_type = 'returned' THEN i.quantity ELSE 0 END), 0) as returned,
  COALESCE(SUM(i.quantity), 0) as total
FROM public.products p
LEFT JOIN public.inventory i ON p.id = i.product_id
GROUP BY p.id, p.name, p.sku, p.reorder_level;

-- Expiring batches view (next 90 days)
CREATE OR REPLACE VIEW public.expiring_batches AS
SELECT
  pb.*,
  p.name as product_name,
  p.sku,
  (pb.exp_date - CURRENT_DATE) as days_to_expiry
FROM public.product_batches pb
JOIN public.products p ON pb.product_id = p.id
WHERE pb.exp_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '90 days'
  AND pb.remaining_quantity > 0
ORDER BY pb.exp_date ASC;

-- Dashboard metrics view
CREATE OR REPLACE VIEW public.dashboard_metrics AS
SELECT
  (SELECT COUNT(*) FROM public.orders WHERE DATE(created_at) = CURRENT_DATE) as today_orders,
  (SELECT COALESCE(SUM(total), 0) FROM public.orders WHERE DATE(created_at) = CURRENT_DATE AND payment_status = 'paid') as today_sales,
  (SELECT COALESCE(SUM(total), 0) FROM public.orders WHERE DATE_TRUNC('month', created_at) = DATE_TRUNC('month', NOW()) AND payment_status = 'paid') as month_sales,
  (SELECT COUNT(*) FROM public.orders WHERE status IN ('new', 'confirmed', 'packed')) as pending_orders,
  (SELECT COALESCE(SUM(amount_due), 0) FROM public.orders WHERE amount_due > 0) as pending_payments,
  (SELECT COUNT(*) FROM public.inventory i JOIN public.products p ON i.product_id = p.id WHERE i.quantity <= p.reorder_level AND i.stock_type = 'warehouse') as low_stock_count,
  (SELECT COUNT(*) FROM public.product_batches WHERE exp_date BETWEEN CURRENT_DATE AND CURRENT_DATE + INTERVAL '30 days' AND remaining_quantity > 0) as expiring_soon;

-- ── ROW LEVEL SECURITY ────────────────────────────────────────

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.products ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.partners ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.attendance ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.tasks ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Helper function to get current user role
CREATE OR REPLACE FUNCTION get_user_role()
RETURNS user_role AS $$
  SELECT role FROM public.users WHERE id = auth.uid();
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Helper function to get current user's partner_id
CREATE OR REPLACE FUNCTION get_user_partner_id()
RETURNS UUID AS $$
  SELECT partner_id FROM public.users WHERE id = auth.uid();
$$ LANGUAGE SQL SECURITY DEFINER STABLE;

-- Users: can read own record, CEO can read all
CREATE POLICY users_select ON public.users FOR SELECT
  USING (id = auth.uid() OR get_user_role() = 'ceo');

CREATE POLICY users_update ON public.users FOR UPDATE
  USING (id = auth.uid() OR get_user_role() = 'ceo');

-- Products: everyone with auth can view active products
CREATE POLICY products_select ON public.products FOR SELECT
  USING (auth.uid() IS NOT NULL AND is_active = true);

CREATE POLICY products_modify ON public.products FOR ALL
  USING (get_user_role() IN ('ceo', 'senior_executive', 'data_executive'));

-- Inventory: everyone can view, restricted roles can modify
CREATE POLICY inventory_select ON public.inventory FOR SELECT
  USING (auth.uid() IS NOT NULL);

CREATE POLICY inventory_modify ON public.inventory FOR ALL
  USING (get_user_role() IN ('ceo', 'senior_executive', 'data_executive'));

-- Orders: CEO/staff see all, partners see own
CREATE POLICY orders_select ON public.orders FOR SELECT
  USING (
    get_user_role() IN ('ceo', 'senior_executive', 'data_executive', 'digital_marketing', 'marketplace_agency')
    OR partner_id = get_user_partner_id()
  );

CREATE POLICY orders_insert ON public.orders FOR INSERT
  WITH CHECK (
    get_user_role() IN ('ceo', 'senior_executive', 'data_executive')
    OR (get_user_role() IN ('distributor', 'reseller') AND partner_id = get_user_partner_id())
  );

-- Partners: CEO/staff see all, partner users see own
CREATE POLICY partners_select ON public.partners FOR SELECT
  USING (
    get_user_role() IN ('ceo', 'senior_executive', 'data_executive')
    OR id = get_user_partner_id()
  );

-- Attendance: CEO/HR see all, users see own
CREATE POLICY attendance_select ON public.attendance FOR SELECT
  USING (user_id = auth.uid() OR get_user_role() IN ('ceo', 'senior_executive'));

CREATE POLICY attendance_insert ON public.attendance FOR INSERT
  WITH CHECK (user_id = auth.uid() OR get_user_role() IN ('ceo', 'senior_executive'));

-- Tasks: CEO sees all, users see assigned to them
CREATE POLICY tasks_select ON public.tasks FOR SELECT
  USING (
    assigned_to = auth.uid()
    OR assigned_by = auth.uid()
    OR get_user_role() IN ('ceo', 'senior_executive')
  );

-- Expenses: CEO and senior executive only
CREATE POLICY expenses_select ON public.expenses FOR SELECT
  USING (get_user_role() IN ('ceo', 'senior_executive'));

CREATE POLICY expenses_insert ON public.expenses FOR INSERT
  WITH CHECK (get_user_role() IN ('ceo', 'senior_executive'));

-- Documents: Role based
CREATE POLICY documents_select ON public.documents FOR SELECT
  USING (
    get_user_role() IN ('ceo', 'senior_executive', 'data_executive')
    OR (get_user_role() IN ('distributor', 'reseller') AND related_to_id = get_user_partner_id())
  );

-- Notifications: own only
CREATE POLICY notifications_select ON public.notifications FOR SELECT
  USING (user_id = auth.uid());

-- ── TRIGGERS ──────────────────────────────────────────────────

-- Auto-update updated_at
CREATE OR REPLACE FUNCTION update_updated_at()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = NOW();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER products_updated_at BEFORE UPDATE ON public.products
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER orders_updated_at BEFORE UPDATE ON public.orders
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

CREATE TRIGGER tasks_updated_at BEFORE UPDATE ON public.tasks
  FOR EACH ROW EXECUTE FUNCTION update_updated_at();

-- Auto-update order amount_due
CREATE OR REPLACE FUNCTION update_order_amount_due()
RETURNS TRIGGER AS $$
BEGIN
  UPDATE public.orders
  SET amount_due = total - COALESCE((SELECT SUM(amount) FROM public.payments WHERE order_id = NEW.order_id), 0),
      payment_status = CASE
        WHEN total <= COALESCE((SELECT SUM(amount) FROM public.payments WHERE order_id = NEW.order_id), 0) THEN 'paid'
        WHEN COALESCE((SELECT SUM(amount) FROM public.payments WHERE order_id = NEW.order_id), 0) > 0 THEN 'partial'
        ELSE 'pending'
      END
  WHERE id = NEW.order_id;
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER payments_update_order AFTER INSERT OR UPDATE ON public.payments
  FOR EACH ROW EXECUTE FUNCTION update_order_amount_due();

-- ── DEMO USERS SETUP ──────────────────────────────────────────
-- Run after creating auth users in Supabase dashboard

-- INSERT INTO public.users (id, email, name, role, department) VALUES
--   ('<ceo_auth_uuid>', 'ceo@haldiva.com', 'Vikram Sharma', 'ceo', 'Executive'),
--   ('<kriti_auth_uuid>', 'kriti@haldiva.com', 'Mrs. Kriti Gupta', 'senior_executive', 'Office Operations'),
--   ('<deep_auth_uuid>', 'deepender@haldiva.com', 'Mr. Deepender Jaiswal', 'data_executive', 'Data & Support'),
--   ('<sayan_auth_uuid>', 'sayan@haldiva.com', 'Mr. Sayan', 'digital_marketing', 'Digital Marketing'),
--   ('<agency_auth_uuid>', 'agency@haldiva.com', 'Marketplace Agency', 'marketplace_agency', 'E-Commerce'),
--   ('<dist_auth_uuid>', 'dist@sse.com', 'Sudeep Dubey', 'distributor', 'Distribution'),
--   ('<reseller_auth_uuid>', 'reseller@nm360.com', 'Dt. Parul Tripathi', 'reseller', 'Reseller');
