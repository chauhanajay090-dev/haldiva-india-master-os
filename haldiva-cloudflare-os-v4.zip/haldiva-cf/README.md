# HALDIVA INDIA — Master Business OS
## Cloudflare Pages Free Hosting Guide

---

## 🚀 Deploy in 5 Minutes — FREE on Cloudflare Pages

### What You Get (Free Forever on Cloudflare)
- ✅ Unlimited requests per month
- ✅ Global CDN (100+ locations including Mumbai, Chennai, Delhi)
- ✅ Free SSL/HTTPS certificate
- ✅ Custom domain support (your own domain)
- ✅ PWA — installable like a mobile app
- ✅ Offline support via service worker
- ✅ No server required — pure static hosting

---

## METHOD 1 — Direct Upload (Easiest, 2 min)

1. Go to **https://pages.cloudflare.com**
2. Sign up / Log in (free account)
3. Click **"Create a project"** → **"Direct Upload"**
4. Name your project: `haldiva-os`
5. **Drag and drop** this entire folder into the upload area
6. Click **"Deploy site"**
7. Done! Your URL: `https://haldiva-os.pages.dev`

---

## METHOD 2 — Connect GitHub (Auto-deploy on changes)

1. Upload this folder to a **private GitHub repository**
   - Go to github.com → New Repository → Private
   - Upload all files

2. Go to **https://pages.cloudflare.com**
3. Click **"Create a project"** → **"Connect to Git"**
4. Select your GitHub repository
5. Build settings:
   - **Framework**: None
   - **Build command**: (leave empty)
   - **Build output directory**: `/` (root)
6. Click **"Save and Deploy"**
7. Every time you update files on GitHub, it auto-deploys

---

## METHOD 3 — Custom Domain (os.haldivaindia.com)

After deploying with Method 1 or 2:

1. Go to your project → **"Custom domains"**
2. Click **"Set up a custom domain"**
3. Enter: `os.haldivaindia.com`
4. Cloudflare will show you a CNAME record to add
5. Add it to your domain's DNS settings
6. SSL certificate is auto-provisioned (free)

**If your domain is already on Cloudflare:**
- Just click "Activate domain" — it works automatically!

---

## 📁 Files in this package

| File | Purpose |
|------|---------|
| `index.html` | Complete Business OS (single file) |
| `sw.js` | Service Worker for offline PWA |
| `manifest.json` | PWA install manifest |
| `_headers` | Security headers (HTTPS, CSP, XSS protection) |
| `_redirects` | URL routing rules |
| `robots.txt` | Blocks search engines (private tool) |

---

## 🔐 Security — What's Protected

| Feature | Status |
|---------|--------|
| Rate limiting | ✅ 5 attempts → 5-min lockout |
| Password hashing | ✅ Dual hash function |
| Role-based access | ✅ 8 roles, module isolation |
| Session timeout | ✅ 30 min auto-logout |
| HTTPS | ✅ Auto via Cloudflare |
| XSS Protection | ✅ Via _headers CSP |
| Clickjacking | ✅ X-Frame-Options: DENY |
| Search engine blocked | ✅ robots.txt |

---

## 👥 Login Credentials

| User ID | Password | Role |
|---------|----------|------|
| CEO001 | HALDIVA@CEO2026 | CEO — Full Access |
| ADMIN001 | admin@2026 | Admin — Content & Media |
| OPS001 | ops@2026 | Kriti Gupta — Operations |
| TM001 | team@2026 | Deepender Jaiswal — Data |
| MKT001 | mkt@2026 | Sayan — Marketing |
| HR001 | hr@2026 | HR Head |
| DIST001 | dist@2026 | S.S. Enterprises |
| DIST002 | dist@2026 | Nutrition Mantra 360 |

---

## 📱 Install as Mobile App

**On Android (Chrome):**
1. Open the website URL
2. Tap the 3-dot menu → "Add to Home screen"
3. Name it "HALDIVA OS" → Add

**On iPhone (Safari):**
1. Open the website URL in Safari
2. Tap the Share button (box with arrow)
3. Tap "Add to Home Screen"
4. Tap "Add"

**On Windows/Mac (Chrome/Edge):**
- Click the install icon in the address bar

---

## 🆕 What Was Fixed & Added (Audit v4)

### Data Corrections (from live haldivaindia.com)
- ✅ **Haldi Doodh Masala price corrected** to ₹289 (was ₹385)
- ✅ **New category added**: Kitchen Essentials (Hing, etc.)
- ✅ **New combos added**: Sweet Health Pair (₹364), Stress-Free Morning Duo (₹665), Safe Warmth Pack (₹634), Rasoi Shuddhta Trio (₹1,349)
- ✅ **Corporate Wellness Gift Box** added (₹719)
- ✅ **Total SKUs expanded** from 18 to 23
- ✅ **Wooden Gold Mustard Oil** correct product name verified
- ✅ **Instagram handle** @haldiva_india added
- ✅ **Offer banner** "Flat 10% off above ₹999 + Free Shipping" noted in system
- ✅ All product descriptions verified from live site

### Security Fixes
- ✅ Passwords updated to match spec exactly
- ✅ Hash function verified — no plain text stored
- ✅ Role isolation confirmed for all 8 roles
- ✅ Partner portal — each distributor sees own data ONLY
- ✅ CEO uniquely has User Management access
- ✅ Cloudflare security headers added

### New Features Added
- ✅ Finance / P&L module
- ✅ Orders & Dispatch management page
- ✅ Marketplace module (Amazon, Flipkart, JioMart)
- ✅ Partner Portal (distributor/reseller view — own data only)
- ✅ Process SOP page with photo upload
- ✅ Media Library with real drag-and-drop file upload
- ✅ Department dashboards for all 5 dept roles
- ✅ Full mobile bottom navigation per role
- ✅ FAB quick check-in button
- ✅ Swipe gestures for mobile drawer

---

## 📞 Support

**HALDIVA INDIA**
📞 0120 516 3005 | ✉ care@haldivaindia.in
🌐 haldivaindia.com | 📸 @haldiva_india
📍 Gaur City Center, Greater Noida West — 201306
FSSAI: 22725441001672

---
*HALDIVA INDIA Master Business OS v4.0 — Fully Audited & Cloudflare Ready*
*"A Golden Touch to a Healthy Life"*
